#!/usr/bin/env bash
set -euo pipefail

MAILPIT_BIN="${FIXNEAR_MAILPIT_BIN:-$HOME/tools/mailpit/mailpit}"
SMTP_ADDR="${FIXNEAR_MAILPIT_SMTP:-127.0.0.1:1025}"
UI_ADDR="${FIXNEAR_MAILPIT_UI:-127.0.0.1:8025}"
LOG_FILE="${FIXNEAR_MAILPIT_LOG:-$HOME/tools/mailpit/mailpit.log}"

if [ ! -x "$MAILPIT_BIN" ]; then
  echo "Mailpit not found at $MAILPIT_BIN"
  echo "Install from https://github.com/axllent/mailpit/releases"
  exit 1
fi

if ss -ltn | grep -q ":1025 "; then
  echo "Mailpit SMTP already listening on :1025"
else
  nohup "$MAILPIT_BIN" --smtp "$SMTP_ADDR" --listen "$UI_ADDR" >"$LOG_FILE" 2>&1 &
  sleep 1
  echo "Mailpit started (SMTP $SMTP_ADDR, UI http://$UI_ADDR)"
fi

echo "Open http://$UI_ADDR to view FixNear system emails."
