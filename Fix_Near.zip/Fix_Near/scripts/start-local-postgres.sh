#!/usr/bin/env bash
set -euo pipefail

PG_BIN="${FIXNEAR_PG_BIN:-$HOME/tools/mamba/envs/fixnear-pg/bin}"
PGDATA="${FIXNEAR_PGDATA:-$HOME/tools/pgdata-fixnear}"
PG_RUN="${FIXNEAR_PG_RUN:-$HOME/tools/pg-run}"

export PATH="$PG_BIN:$PATH"

mkdir -p "$PG_RUN"

if [ ! -f "$PGDATA/PG_VERSION" ]; then
  echo "PostgreSQL data directory not initialized: $PGDATA"
  echo "Run Phase 1 setup first (initdb)."
  exit 1
fi

if pg_ctl -D "$PGDATA" status >/dev/null 2>&1; then
  echo "PostgreSQL already running."
else
  pg_ctl -D "$PGDATA" -l "$PG_RUN/postgres.log" -o "-k $PG_RUN" start
  echo "PostgreSQL started."
fi
