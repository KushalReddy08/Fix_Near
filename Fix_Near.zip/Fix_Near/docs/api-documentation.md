# API documentation

Base path: `/api/v1`

## Health & auth

| Method | Path | Auth |
|--------|------|------|
| GET | `/api/v1/health` | Public |
| POST | `/api/v1/auth/register` | Public |
| POST | `/api/v1/auth/resend-verification` | Public |
| POST | `/api/v1/auth/verify-email` | Public |
| POST | `/api/v1/auth/login` | Public |
| POST | `/api/v1/auth/refresh` | Cookie |
| POST | `/api/v1/auth/logout` | Cookie |
| GET/PUT | `/api/v1/users/me` | Bearer |
| PUT | `/api/v1/users/me/password` | Bearer |

## Organizations

| Method | Path | Auth |
|--------|------|------|
| POST | `/api/v1/organizations/requests` | User |
| GET | `/api/v1/organizations/requests/mine` | User |
| GET | `/api/v1/platform/organization-requests` | Platform admin |
| POST | `/api/v1/platform/organization-requests/{id}/approve` | Platform admin |
| POST | `/api/v1/platform/organization-requests/{id}/reject` | Platform admin |
| GET | `/api/v1/organizations` | Member list for me |
| GET/PUT | `/api/v1/organizations/{id}` | Member / leadership |
| POST | `/api/v1/organizations/{id}/invitations` | Head/Co-admin |
| POST | `/api/v1/organizations/join` | User |
| GET | `/api/v1/organizations/{id}/members` | Member |
| PUT/DELETE | `/api/v1/organizations/{id}/members/{userId}` | Leadership |
| POST/GET | `/api/v1/organizations/{id}/departments` | Leadership / member |

## Locations

| Method | Path | Auth |
|--------|------|------|
| GET | `/api/v1/locations/countries` | User |
| GET | `/api/v1/locations/states?country=` | User |
| GET | `/api/v1/locations/cities?country=&state=` | User |

## Complaints

| Method | Path | Auth |
|--------|------|------|
| POST/GET | `/api/v1/organizations/{orgId}/complaints` | Member |
| GET | `/api/v1/organizations/{orgId}/complaints/{id}` | Member |
| POST | `.../acknowledge` | Complaint handler |
| POST | `.../assign` | Complaint handler |
| POST | `.../start` | Complaint handler |
| POST | `.../resolve` | Complaint handler |
| POST | `.../reject` | Complaint handler |
| POST | `.../reporter-ack` | Reporter |
| POST | `.../admin-close` | Leadership |
| GET | `.../events` | Member |
| GET/POST | `.../comments` | Member |
| POST | `.../support` | Member |
| GET/POST | `.../attachments` | Member |
| GET | `.../attachments/{id}/download` | Member |

## SLA / dashboard / commitments / notifications / civic

| Method | Path | Auth |
|--------|------|------|
| GET/PUT | `/api/v1/organizations/{orgId}/sla-policies` | Member / leadership |
| GET | `/api/v1/organizations/{orgId}/dashboard` | Member |
| GET/POST | `/api/v1/organizations/{orgId}/commitments` | Member / handler |
| POST | `/api/v1/organizations/{orgId}/commitments/{id}/complete` | Handler |
| GET | `/api/v1/notifications` | User |
| POST | `/api/v1/notifications/{id}/read` | User |
| GET | `/api/v1/civic/map/complaints` | User |

System operator (local): username alias `system` (platform admin). Use a strong password; never commit production credentials.
