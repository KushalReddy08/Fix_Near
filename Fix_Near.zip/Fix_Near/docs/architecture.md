# FixNear architecture

## System shape

```text
React (Vite)  --Axios-->  Spring Boot 3  --JDBC/Flyway-->  PostgreSQL
                               |
                          Actuator health
                          OpenAPI (dev)
                          Local file attachments
                          Scheduled SLA overdue scan
```

## Layers (backend)

Controller → Service → Repository → Database

Feature packages under `com.fixnear.*`: `auth`, `user`, `organization`, `complaint`, `location`, `sla`, `commitment`, `notification`, `civic`.

## Frontend

Feature folders under `frontend/src/features`. HTTP via `services/api/axiosInstance.ts`.

## Multi-tenant security

Private rows are scoped by `organization_id`. Authorization is enforced in services (`OrganizationAccessService`), not only in the UI.

## Accountability loop

Complaints move through workflow statuses with immutable `complaint_events`. SLA deadlines are set from org policies; a scheduler flips `is_overdue` independently of status. Attachments are stored on disk and served only through authenticated download endpoints.
