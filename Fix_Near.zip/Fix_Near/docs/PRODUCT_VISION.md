# FixNear product vision (reference)

The long-form master specification (participation lifecycle, anonymity modes, civic maps, commitments, etc.) remains the **product rulebook**.

## Stack note

This repository currently implements the **React + Spring Boot + PostgreSQL** stack approved in earlier phases.

A later specification draft mentioned Go + Neon. That is **not** the active implementation stack unless explicitly approved as a rewrite. Continue feature work on the existing Java backend unless a stack migration is approved.

## System operator (local)

- Username alias: `system` → `system@fixnear.local`
- Role: `PLATFORM_ADMIN` — only this account can approve/reject organization creation requests.
- Do **not** publish the seed password. Set a strong password for local/production use and rotate it before any shared deploy.
