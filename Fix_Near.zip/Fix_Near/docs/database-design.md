# Database design

Flyway migrations live in `backend/src/main/resources/db/migration/`.

| Version | Scope |
|---------|--------|
| V1 | Baseline |
| V2 | Auth users / tokens |
| V3 | Organizations, members, invites, departments |
| V4 | System admin seed, complaints |
| V5 | Organization address fields |
| V6 | Complaint workflow fields, events, comments, attachments, supports, SLA policies, commitments, notifications |

Storage remains UTC. Organization timezone is used for SLA presentation; overdue is stored as `is_overdue` and updated by a scheduled scan independently of workflow status.

Attachments are metadata in PostgreSQL; file bytes are on local disk (`FIXNEAR_STORAGE_DIR`).
