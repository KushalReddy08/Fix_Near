# Security notes

## Secrets

- Never commit `.env`. Only `.env.example` (placeholders) belongs in git.
- Set a unique `FIXNEAR_JWT_SECRET` (32+ random bytes) for every environment.
- Use real SMTP credentials only via host secrets (Render/Vercel/etc.), not source.

## Platform admin seed

Local Flyway seed creates a `PLATFORM_ADMIN` user with login alias `system`.

- Change that password before sharing a database or deploying publicly.
- Prefer creating a new admin and disabling the seed account for production.

## Production checklist

- `SPRING_PROFILES_ACTIVE=prod` (disables swagger, verification-token exposure defaults)
- `FIXNEAR_EXPOSE_VERIFICATION_TOKEN=false`
- `FIXNEAR_REFRESH_COOKIE_SECURE=true` (HTTPS only)
- Restrict `FIXNEAR_CORS_ORIGINS` to your real frontend origin(s)
- Attachments on ephemeral disks are not durable; use object storage for production

## Reporting

If you find a vulnerability, open a private security advisory on the GitHub repo rather than a public issue when possible.
