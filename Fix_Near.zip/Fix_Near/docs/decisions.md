# FixNear locked product decisions

Captured during Phase 0 / start of Phase 1. These override informal earlier notes.

## Authentication

- Email verification is required before login.
- Access tokens: short-lived JWT in the `Authorization` header.
- Refresh tokens: httpOnly, Secure, SameSite cookies with rotation and revocation.
- Passwords: BCrypt (Phase 2). Never returned in API responses.

## Organizations

- Users submit an organization creation request; only `PLATFORM_ADMIN` can approve.
- Exactly one **HEAD** per organization.
- Up to **4 co-admins** (`ORGANIZATION_ADMIN`) in addition to the head leadership model (1 head + up to 4 co-admins).
- Invitations: single-use, expiring, hashed at rest.
- Organization timezone drives SLA / overdue calculations; storage remains UTC.
- Organization address is collected step-by-step: Country → State/Province → City (API-backed dropdowns) → free-text street address.

## Visibility and identity

- Login required for civic complaint access (no anonymous public API).
- Reporter identity mode for v1: **Named only**.

## Complaints

- Workflow statuses follow the master prompt (`SUBMITTED` … `CLOSED` / `REOPENED` / `REJECTED`).
- Reporter verification: `RESOLVED` (official claim) → reporter acknowledge → `CLOSED`, or reject → `REOPENED`.
- `is_overdue` is independent of workflow status.
- Priority is system-assigned from category / SLA policy.

## Files

- Max 10 MB per file.
- Allowlist: `image/jpeg`, `image/png`, `image/webp`, `application/pdf`.
- Max 5 attachments per complaint (v1 default).

## Delivery

- Package: `com.fixnear`
- Database name: `fixnear`
- Dev seed data allowed (no real PII).
- Do not push to a remote until the user has tested and explicitly asks.
