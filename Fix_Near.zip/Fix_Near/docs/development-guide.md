# Development guide

## Prerequisites

- Node.js 24+ / npm
- Java 21 (this machine uses `~/tools/jdk-21.0.13.1+2`)
- Maven 3.10+ (`~/tools/apache-maven-3.10.1`)
- PostgreSQL 16 (local micromamba install or Docker Compose PostGIS)

Optional: Docker Engine for `docker compose up` (PostGIS + Mailpit).

## Start PostgreSQL (user-local, no Docker)

```bash
bash scripts/start-local-postgres.sh
```

## Start Mailpit (system email inbox for local/dev)

```bash
bash scripts/start-mailpit.sh
```

Open http://127.0.0.1:8025 — verification emails appear there (not in Gmail, unless you configure real SMTP).

Defaults (local only — override in `.env` for anything shared):

- host `127.0.0.1:5432`
- database / user `fixnear`
- password: see `.env.example` / your `.env`

## Start backend

```bash
export JAVA_HOME=$HOME/tools/jdk-21.0.13.1+2
export PATH=$JAVA_HOME/bin:$HOME/tools/apache-maven-3.10.1/bin:$PATH
cd backend
mvn spring-boot:run
```

Health: `http://localhost:8080/api/v1/health`  
Actuator: `http://localhost:8080/actuator/health`  
Swagger: `http://localhost:8080/swagger-ui.html`

## Start frontend

```bash
cd frontend
npm install
npm run dev
```

Open `http://localhost:5173`.

## Phase 2 auth smoke test

1. Open http://localhost:5173/register and create an account.
2. Copy the verification link from the backend log line `Email verification link for ...`.
3. Open `/verify-email` (or the logged URL) and confirm.
4. Sign in at `/login`, then open `/app` and `/profile`.

Without Mailpit, verification links are always printed in the Spring Boot console.

## Tests

```bash
cd backend && mvn test
cd frontend && npm run build
```

## Docker Compose (when Docker is installed)

```bash
docker compose up -d
```

Brings up PostGIS and Mailpit. Do not expose Postgres publicly.

## Git

Work locally. Do not push until explicitly requested after testing.
