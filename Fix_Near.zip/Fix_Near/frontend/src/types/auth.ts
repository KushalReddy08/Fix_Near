export type PlatformRole = 'USER' | 'PLATFORM_ADMIN'
export type AccountStatus = 'PENDING_VERIFICATION' | 'ACTIVE' | 'DISABLED'

export interface User {
  id: string
  email: string
  fullName: string
  platformRole: PlatformRole
  accountStatus: AccountStatus
  createdAt: string
  updatedAt: string
}

export interface AuthTokens {
  accessToken: string
  tokenType: string
  expiresInSeconds: number
  user: User
}

export interface ApiMeta {
  requestId: string
  timestamp: string
}

export interface ApiResponse<T> {
  success: boolean
  data: T
  error: { code: string; message: string } | null
  meta: ApiMeta
}
