import { useQuery } from '@tanstack/react-query'
import { getBackendHealth } from '../../services/api/healthApi'

export function useBackendHealth() {
  return useQuery({
    queryKey: ['health', 'backend'],
    queryFn: getBackendHealth,
    retry: 1,
    refetchInterval: 30_000,
  })
}
