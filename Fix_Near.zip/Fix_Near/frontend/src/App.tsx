import { Navigate, Route, Routes } from 'react-router-dom'
import { AuthProvider } from './features/auth/AuthContext'
import { LoginPage } from './features/auth/LoginPage'
import { ProfilePage } from './features/auth/ProfilePage'
import { RegisterPage } from './features/auth/RegisterPage'
import { VerifyEmailPage } from './features/auth/VerifyEmailPage'
import { CivicMapPage } from './features/civic/CivicMapPage'
import { ComplaintDetailPage } from './features/complaints/ComplaintDetailPage'
import { UserHomePage } from './features/dashboard/UserHomePage'
import { LandingPage } from './features/landing/LandingPage'
import { NotificationsPage } from './features/notifications/NotificationsPage'
import { CommitmentsPage } from './features/organizations/CommitmentsPage'
import { OrganizationDetailPage } from './features/organizations/OrganizationDetailPage'
import { OrganizationsPage } from './features/organizations/OrganizationsPage'
import { OrgDashboardPage } from './features/organizations/OrgDashboardPage'
import { PlatformOrgRequestsPage } from './features/organizations/PlatformOrgRequestsPage'
import { ProtectedRoute } from './routes/ProtectedRoute'

function App() {
  return (
    <AuthProvider>
      <Routes>
        <Route path="/" element={<LandingPage />} />
        <Route path="/login" element={<LoginPage />} />
        <Route path="/register" element={<RegisterPage />} />
        <Route path="/verify-email" element={<VerifyEmailPage />} />
        <Route element={<ProtectedRoute />}>
          <Route path="/app" element={<UserHomePage />} />
          <Route path="/profile" element={<ProfilePage />} />
          <Route path="/notifications" element={<NotificationsPage />} />
          <Route path="/civic/map" element={<CivicMapPage />} />
          <Route path="/organizations" element={<OrganizationsPage />} />
          <Route path="/organizations/:organizationId" element={<OrganizationDetailPage />} />
          <Route path="/organizations/:organizationId/dashboard" element={<OrgDashboardPage />} />
          <Route path="/organizations/:organizationId/commitments" element={<CommitmentsPage />} />
          <Route
            path="/organizations/:organizationId/complaints/:complaintId"
            element={<ComplaintDetailPage />}
          />
          <Route path="/platform/org-requests" element={<PlatformOrgRequestsPage />} />
        </Route>
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </AuthProvider>
  )
}

export default App
