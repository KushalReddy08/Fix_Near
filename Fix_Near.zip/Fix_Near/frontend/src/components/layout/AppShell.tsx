import { Link, NavLink } from 'react-router-dom'
import type { ReactNode } from 'react'
import { useAuth } from '../../features/auth/AuthContext'

export function AppShell({
  title,
  subtitle,
  children,
}: {
  title: string
  subtitle?: string
  children: ReactNode
}) {
  const { user, logout } = useAuth()

  return (
    <div className="min-h-screen">
      <header className="sticky top-0 z-20 border-b border-[var(--fn-line)]/80 bg-white/75 backdrop-blur-md">
        <div className="mx-auto flex max-w-6xl items-center justify-between gap-4 px-6 py-3">
          <Link to={user ? '/app' : '/'} className="flex items-center gap-2">
            <span className="fn-brand-mark text-sm">✓</span>
            <span className="fn-display text-lg font-bold tracking-tight">FixNear</span>
          </Link>
          {user && (
            <nav className="hidden items-center gap-1 md:flex">
              <ShellLink to="/app">Dashboard</ShellLink>
              <ShellLink to="/organizations">Organizations</ShellLink>
              <ShellLink to="/civic/map">Civic map</ShellLink>
              <ShellLink to="/notifications">Notifications</ShellLink>
              {user.platformRole === 'PLATFORM_ADMIN' && (
                <ShellLink to="/platform/org-requests">Approvals</ShellLink>
              )}
              <ShellLink to="/profile">Profile</ShellLink>
            </nav>
          )}
          <div className="flex items-center gap-2">
            {user ? (
              <>
                <span className="hidden text-sm text-[var(--fn-mute)] sm:inline">{user.fullName}</span>
                <button type="button" className="fn-btn fn-btn-ghost text-sm" onClick={() => void logout()}>
                  Log out
                </button>
              </>
            ) : (
              <>
                <Link to="/login" className="fn-btn fn-btn-ghost text-sm">
                  Sign in
                </Link>
                <Link to="/register" className="fn-btn fn-btn-primary text-sm">
                  Get started
                </Link>
              </>
            )}
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-6xl px-6 py-10">
        <div className="fn-enter mb-8">
          <p className="text-xs font-semibold tracking-[0.2em] text-[var(--fn-acc)] uppercase">FixNear</p>
          <h1 className="fn-display mt-2 text-3xl font-bold md:text-4xl">{title}</h1>
          {subtitle && <p className="mt-2 max-w-2xl text-[var(--fn-mute)]">{subtitle}</p>}
        </div>
        {children}
      </main>
    </div>
  )
}

function ShellLink({ to, children }: { to: string; children: ReactNode }) {
  return (
    <NavLink
      to={to}
      className={({ isActive }) =>
        `rounded-lg px-3 py-2 text-sm font-semibold transition ${
          isActive ? 'bg-[var(--fn-acc)]/10 text-[var(--fn-acc)]' : 'text-[var(--fn-mute)] hover:text-[var(--fn-ink)]'
        }`
      }
    >
      {children}
    </NavLink>
  )
}
