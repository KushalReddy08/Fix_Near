import { Link } from 'react-router-dom'
import { AppShell } from '../../components/layout/AppShell'
import { useAuth } from '../auth/AuthContext'
import { useBackendHealth } from '../../hooks/health/useBackendHealth'

export function UserHomePage() {
  const { user } = useAuth()
  const health = useBackendHealth()
  const isAdmin = user?.platformRole === 'PLATFORM_ADMIN'

  return (
    <AppShell
      title={`Welcome, ${user?.fullName}`}
      subtitle="Track organizations, complaints, and accountability from one place."
    >
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        <Link to="/organizations" className="fn-card fn-enter p-5 no-underline">
          <p className="text-xs font-semibold tracking-wide text-[var(--fn-acc)] uppercase">Workspace</p>
          <h2 className="fn-display mt-2 text-xl font-semibold text-[var(--fn-ink)]">Organizations</h2>
          <p className="mt-2 text-sm text-[var(--fn-mute)]">Request, join, and manage memberships.</p>
        </Link>
        <Link to="/notifications" className="fn-card fn-enter fn-enter-delay-1 p-5 no-underline">
          <p className="text-xs font-semibold tracking-wide text-[var(--fn-acc)] uppercase">Inbox</p>
          <h2 className="fn-display mt-2 text-xl font-semibold text-[var(--fn-ink)]">Notifications</h2>
          <p className="mt-2 text-sm text-[var(--fn-mute)]">Workflow updates and acknowledgements.</p>
        </Link>
        <Link to="/civic/map" className="fn-card fn-enter fn-enter-delay-2 p-5 no-underline">
          <p className="text-xs font-semibold tracking-wide text-[var(--fn-acc)] uppercase">Public</p>
          <h2 className="fn-display mt-2 text-xl font-semibold text-[var(--fn-ink)]">Civic map</h2>
          <p className="mt-2 text-sm text-[var(--fn-mute)]">Browse civic complaints with map links.</p>
        </Link>
        {isAdmin ? (
          <Link to="/platform/org-requests" className="fn-card fn-enter fn-enter-delay-3 p-5 no-underline">
            <p className="text-xs font-semibold tracking-wide text-[var(--fn-warn)] uppercase">System</p>
            <h2 className="fn-display mt-2 text-xl font-semibold text-[var(--fn-ink)]">Approvals</h2>
            <p className="mt-2 text-sm text-[var(--fn-mute)]">Only you can approve or reject org requests.</p>
          </Link>
        ) : (
          <div className="fn-card fn-enter fn-enter-delay-3 p-5">
            <p className="text-xs font-semibold tracking-wide text-[var(--fn-mute)] uppercase">Status</p>
            <h2 className="fn-display mt-2 text-xl font-semibold">Platform health</h2>
            <p className="mt-2 text-sm text-[var(--fn-mute)]">
              {health.data?.success ? `${health.data.data.status} · ${health.data.data.phase}` : 'Checking…'}
            </p>
          </div>
        )}
      </div>
    </AppShell>
  )
}
