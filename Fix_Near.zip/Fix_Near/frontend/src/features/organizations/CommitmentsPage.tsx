import { useEffect, useState, type FormEvent } from 'react'
import { Link, useParams } from 'react-router-dom'
import { isAxiosError } from 'axios'
import { AppShell } from '../../components/layout/AppShell'
import {
  completeCommitment,
  createCommitment,
  listCommitments,
  type Commitment,
} from '../../services/api/commitmentApi'
import { getOrganization, type Organization } from '../../services/api/organizationApi'

function apiError(err: unknown, fallback: string) {
  return isAxiosError(err) ? err.response?.data?.error?.message ?? fallback : fallback
}

export function CommitmentsPage() {
  const { organizationId = '' } = useParams()
  const [org, setOrg] = useState<Organization | null>(null)
  const [items, setItems] = useState<Commitment[]>([])
  const [title, setTitle] = useState('')
  const [description, setDescription] = useState('')
  const [dueAt, setDueAt] = useState('')
  const [completeNote, setCompleteNote] = useState<Record<string, string>>({})
  const [error, setError] = useState<string | null>(null)
  const [message, setMessage] = useState<string | null>(null)

  const canCreate = org?.myRole === 'HEAD' || org?.myRole === 'CO_ADMIN' || org?.myRole === 'OFFICIAL'

  async function reload() {
    const [o, c] = await Promise.all([getOrganization(organizationId), listCommitments(organizationId)])
    setOrg(o.data)
    setItems(c.data)
  }

  useEffect(() => {
    void reload().catch((err) => setError(apiError(err, 'Failed to load commitments')))
  }, [organizationId])

  async function onCreate(event: FormEvent) {
    event.preventDefault()
    setError(null)
    setMessage(null)
    try {
      await createCommitment(organizationId, {
        title,
        description: description || undefined,
        dueAt: dueAt ? new Date(dueAt).toISOString() : undefined,
      })
      setTitle('')
      setDescription('')
      setDueAt('')
      setMessage('Commitment created.')
      await reload()
    } catch (err) {
      setError(apiError(err, 'Create failed'))
    }
  }

  async function onComplete(id: string) {
    setError(null)
    setMessage(null)
    try {
      await completeCommitment(organizationId, id, {
        note: completeNote[id] || undefined,
      })
      setMessage('Commitment completed.')
      await reload()
    } catch (err) {
      setError(apiError(err, 'Complete failed'))
    }
  }

  if (!org) {
    return (
      <AppShell title="Commitments">
        <p className="text-[var(--fn-mute)]">{error ?? 'Loading…'}</p>
      </AppShell>
    )
  }

  return (
    <AppShell title="Commitments" subtitle={`Public accountability for ${org.name}`}>
      <div className="mb-4 flex flex-wrap gap-3 text-sm">
        <Link to={`/organizations/${organizationId}`} className="font-semibold text-[var(--fn-acc)]">
          ← Organization
        </Link>
        <Link
          to={`/organizations/${organizationId}/dashboard`}
          className="font-semibold text-[var(--fn-acc)]"
        >
          Dashboard
        </Link>
      </div>
      {error && <p className="mb-3 text-sm text-[var(--fn-danger)]">{error}</p>}
      {message && <p className="mb-3 text-sm text-[var(--fn-ok)]">{message}</p>}

      {canCreate && (
        <section className="fn-card fn-enter mb-5 p-6">
          <h2 className="fn-display text-lg font-semibold">New commitment</h2>
          <form className="mt-3 grid gap-3" onSubmit={onCreate}>
            <input
              className="fn-input"
              placeholder="Title"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              required
            />
            <textarea
              className="fn-input min-h-20"
              placeholder="Description (optional)"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
            />
            <input
              className="fn-input"
              type="datetime-local"
              value={dueAt}
              onChange={(e) => setDueAt(e.target.value)}
            />
            <button type="submit" className="fn-btn fn-btn-primary">
              Create
            </button>
          </form>
        </section>
      )}

      <section className="fn-card fn-enter fn-enter-delay-1 p-6">
        <div className="mb-4 flex items-center justify-between gap-3">
          <h2 className="fn-display text-lg font-semibold">All commitments</h2>
          <span className="fn-badge">{items.length}</span>
        </div>
        <ul className="space-y-3">
          {items.map((c) => (
            <li key={c.id} className="rounded-xl border border-[var(--fn-line)] bg-[var(--fn-bg)] p-4">
              <div className="flex flex-wrap items-center gap-2">
                <p className="font-semibold">{c.title}</p>
                <span className="fn-badge">{c.status}</span>
              </div>
              {c.description && <p className="mt-1 text-sm text-[var(--fn-mute)]">{c.description}</p>}
              <p className="mt-2 text-xs text-[var(--fn-mute)]">
                {c.ownerName ? `Owner: ${c.ownerName}` : 'No owner'}
                {c.dueAt ? ` · Due ${new Date(c.dueAt).toLocaleString()}` : ''}
                {c.completedAt ? ` · Done ${new Date(c.completedAt).toLocaleString()}` : ''}
              </p>
              {c.completionNote && (
                <p className="mt-1 text-sm">Note: {c.completionNote}</p>
              )}
              {c.status === 'OPEN' && (
                <div className="mt-3 flex flex-col gap-2 md:flex-row">
                  <input
                    className="fn-input"
                    placeholder="Completion note (optional)"
                    value={completeNote[c.id] ?? ''}
                    onChange={(e) =>
                      setCompleteNote((prev) => ({ ...prev, [c.id]: e.target.value }))
                    }
                  />
                  <button
                    type="button"
                    className="fn-btn fn-btn-primary shrink-0"
                    onClick={() => void onComplete(c.id)}
                  >
                    Mark complete
                  </button>
                </div>
              )}
            </li>
          ))}
          {items.length === 0 && (
            <p className="text-sm text-[var(--fn-mute)]">No commitments yet.</p>
          )}
        </ul>
      </section>
    </AppShell>
  )
}
