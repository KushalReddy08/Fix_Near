import { useEffect, useState } from 'react'
import { isAxiosError } from 'axios'
import { AppShell } from '../../components/layout/AppShell'
import { approveOrgRequest, pendingOrgRequests, rejectOrgRequest, type OrgRequest } from '../../services/api/organizationApi'

export function PlatformOrgRequestsPage() {
  const [requests, setRequests] = useState<OrgRequest[]>([])
  const [error, setError] = useState<string | null>(null)
  const [message, setMessage] = useState<string | null>(null)

  async function reload() {
    const res = await pendingOrgRequests()
    setRequests(res.data)
  }

  useEffect(() => {
    void reload().catch((err) => {
      setError(isAxiosError(err) ? err.response?.data?.error?.message ?? 'Failed to load' : 'Failed to load')
    })
  }, [])

  async function approve(id: string) {
    try {
      const res = await approveOrgRequest(id, 'Approved by system')
      setMessage(`Approved — created ${res.data.name}`)
      await reload()
    } catch (err) {
      setError(isAxiosError(err) ? err.response?.data?.error?.message ?? 'Approve failed' : 'Approve failed')
    }
  }

  async function reject(id: string) {
    try {
      await rejectOrgRequest(id, 'Rejected by system')
      setMessage('Request rejected')
      await reload()
    } catch (err) {
      setError(isAxiosError(err) ? err.response?.data?.error?.message ?? 'Reject failed' : 'Reject failed')
    }
  }

  return (
    <AppShell
      title="System approvals"
      subtitle="Only the system operator can approve or reject organization creation requests."
    >
      {error && <p className="mb-3 text-sm text-[var(--fn-danger)]">{error}</p>}
      {message && <p className="mb-3 text-sm text-[var(--fn-ok)]">{message}</p>}
      <ul className="space-y-3">
        {requests.map((r, index) => (
          <li
            key={r.id}
            className={`fn-card p-5 fn-enter ${index === 1 ? 'fn-enter-delay-1' : index === 2 ? 'fn-enter-delay-2' : ''}`}
          >
            <p className="fn-display text-lg font-semibold">{r.name}</p>
            <p className="mt-1 text-sm text-[var(--fn-mute)]">
              {r.organizationType} · {r.timezone} · requested by {r.requesterEmail}
            </p>
            {(r.addressLine || r.city) && (
              <p className="mt-2 text-sm text-[var(--fn-mute)]">
                {[r.addressLine, r.city, r.stateProvince, r.country].filter(Boolean).join(', ')}
              </p>
            )}
            <div className="mt-4 flex gap-2">
              <button type="button" className="fn-btn fn-btn-primary" onClick={() => void approve(r.id)}>
                Approve
              </button>
              <button type="button" className="fn-btn fn-btn-ghost" onClick={() => void reject(r.id)}>
                Reject
              </button>
            </div>
          </li>
        ))}
        {requests.length === 0 && (
          <p className="fn-card p-6 text-sm text-[var(--fn-mute)]">No pending requests.</p>
        )}
      </ul>
    </AppShell>
  )
}
