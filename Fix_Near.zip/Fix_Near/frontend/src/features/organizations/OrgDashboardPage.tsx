import { useEffect, useState, type FormEvent } from 'react'
import { Link, useParams } from 'react-router-dom'
import { isAxiosError } from 'axios'
import { AppShell } from '../../components/layout/AppShell'
import {
  getOrgDashboard,
  listSlaPolicies,
  upsertSlaPolicies,
  type OrgDashboard,
  type SlaPolicy,
} from '../../services/api/slaApi'
import { getOrganization, type Organization } from '../../services/api/organizationApi'
import type { ComplaintPriority } from '../../services/api/complaintApi'

const PRIORITIES: ComplaintPriority[] = ['LOW', 'MEDIUM', 'HIGH', 'CRITICAL']

function apiError(err: unknown, fallback: string) {
  return isAxiosError(err) ? err.response?.data?.error?.message ?? fallback : fallback
}

export function OrgDashboardPage() {
  const { organizationId = '' } = useParams()
  const [org, setOrg] = useState<Organization | null>(null)
  const [dashboard, setDashboard] = useState<OrgDashboard | null>(null)
  const [policies, setPolicies] = useState<SlaPolicy[]>([])
  const [error, setError] = useState<string | null>(null)
  const [message, setMessage] = useState<string | null>(null)
  const [draftCategory, setDraftCategory] = useState('General')
  const [draftPriority, setDraftPriority] = useState<ComplaintPriority>('MEDIUM')
  const [draftAck, setDraftAck] = useState(24)
  const [draftResolve, setDraftResolve] = useState(72)

  const canEditSla = org?.myRole === 'HEAD' || org?.myRole === 'CO_ADMIN'

  async function reload() {
    const [o, d, s] = await Promise.all([
      getOrganization(organizationId),
      getOrgDashboard(organizationId),
      listSlaPolicies(organizationId),
    ])
    setOrg(o.data)
    setDashboard(d.data)
    setPolicies(s.data)
  }

  useEffect(() => {
    void reload().catch((err) => setError(apiError(err, 'Failed to load dashboard')))
  }, [organizationId])

  async function onSavePolicies(event: FormEvent) {
    event.preventDefault()
    if (!canEditSla) return
    setError(null)
    setMessage(null)
    try {
      const next: SlaPolicy[] = [
        ...policies.filter((p) => !(p.category === draftCategory && p.priority === draftPriority)),
        {
          category: draftCategory,
          priority: draftPriority,
          acknowledgeHours: draftAck,
          resolveHours: draftResolve,
        },
      ]
      const res = await upsertSlaPolicies(organizationId, next)
      setPolicies(res.data)
      setMessage('SLA policies saved.')
    } catch (err) {
      setError(apiError(err, 'Failed to save SLA'))
    }
  }

  if (!org || !dashboard) {
    return (
      <AppShell title="Org dashboard">
        <p className="text-[var(--fn-mute)]">{error ?? 'Loading…'}</p>
      </AppShell>
    )
  }

  const statusEntries = Object.entries(dashboard.byStatus ?? {})

  return (
    <AppShell
      title={`${org.name} dashboard`}
      subtitle={`Open ${dashboard.openCount} · Overdue ${dashboard.overdueCount}`}
    >
      <div className="mb-4 flex flex-wrap gap-3 text-sm">
        <Link to={`/organizations/${organizationId}`} className="font-semibold text-[var(--fn-acc)]">
          ← Organization
        </Link>
        <Link
          to={`/organizations/${organizationId}/commitments`}
          className="font-semibold text-[var(--fn-acc)]"
        >
          Commitments
        </Link>
      </div>
      {error && <p className="mb-3 text-sm text-[var(--fn-danger)]">{error}</p>}
      {message && <p className="mb-3 text-sm text-[var(--fn-ok)]">{message}</p>}

      <div className="mb-5 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard label="Open" value={dashboard.openCount} />
        <StatCard label="Overdue" value={dashboard.overdueCount} danger={dashboard.overdueCount > 0} />
        <StatCard label="Statuses tracked" value={statusEntries.length} />
        <StatCard label="Hot (support)" value={dashboard.supportHot?.length ?? 0} />
      </div>

      <section className="fn-card fn-enter mb-5 p-6">
        <h2 className="fn-display text-lg font-semibold">By status</h2>
        <ul className="mt-3 flex flex-wrap gap-2">
          {statusEntries.map(([status, count]) => (
            <li key={status} className="fn-badge">
              {status}: {count}
            </li>
          ))}
          {statusEntries.length === 0 && (
            <p className="text-sm text-[var(--fn-mute)]">No status breakdown yet.</p>
          )}
        </ul>
      </section>

      <section className="fn-card fn-enter fn-enter-delay-1 mb-5 p-6">
        <h2 className="fn-display text-lg font-semibold">Support hot</h2>
        <ul className="mt-3 space-y-3">
          {(dashboard.supportHot ?? []).map((c) => (
            <li key={c.id}>
              <Link
                to={`/organizations/${organizationId}/complaints/${c.id}`}
                className="block rounded-xl border border-[var(--fn-line)] bg-[var(--fn-bg)] p-4 no-underline"
              >
                <div className="flex flex-wrap items-center gap-2">
                  <p className="font-semibold text-[var(--fn-ink)]">{c.title}</p>
                  <span className="fn-badge">{c.workflowStatus}</span>
                  <span className="fn-badge">{c.supportCount ?? 0} supports</span>
                </div>
              </Link>
            </li>
          ))}
          {(dashboard.supportHot ?? []).length === 0 && (
            <p className="text-sm text-[var(--fn-mute)]">No high-support complaints.</p>
          )}
        </ul>
      </section>

      <section className="fn-card fn-enter fn-enter-delay-2 p-6">
        <h2 className="fn-display text-lg font-semibold">SLA policies</h2>
        <ul className="mt-3 space-y-2 text-sm">
          {policies.map((p) => (
            <li
              key={`${p.category}-${p.priority}`}
              className="flex flex-wrap justify-between gap-2 rounded-xl border border-[var(--fn-line)] bg-[var(--fn-bg)] px-3 py-2"
            >
              <span>
                {p.category} · {p.priority}
              </span>
              <span className="text-[var(--fn-mute)]">
                ack {p.acknowledgeHours}h · resolve {p.resolveHours}h
              </span>
            </li>
          ))}
          {policies.length === 0 && (
            <p className="text-[var(--fn-mute)]">No SLA policies configured.</p>
          )}
        </ul>
        {canEditSla && (
          <form className="mt-4 grid gap-3 md:grid-cols-2" onSubmit={onSavePolicies}>
            <input
              className="fn-input"
              placeholder="Category"
              value={draftCategory}
              onChange={(e) => setDraftCategory(e.target.value)}
              required
            />
            <select
              className="fn-input"
              value={draftPriority}
              onChange={(e) => setDraftPriority(e.target.value as ComplaintPriority)}
            >
              {PRIORITIES.map((p) => (
                <option key={p} value={p}>
                  {p}
                </option>
              ))}
            </select>
            <input
              className="fn-input"
              type="number"
              min={1}
              placeholder="Acknowledge hours"
              value={draftAck}
              onChange={(e) => setDraftAck(Number(e.target.value))}
              required
            />
            <input
              className="fn-input"
              type="number"
              min={1}
              placeholder="Resolve hours"
              value={draftResolve}
              onChange={(e) => setDraftResolve(Number(e.target.value))}
              required
            />
            <button type="submit" className="fn-btn fn-btn-primary md:col-span-2">
              Upsert SLA row
            </button>
          </form>
        )}
        {!canEditSla && (
          <p className="mt-3 text-sm text-[var(--fn-mute)]">Only HEAD / CO_ADMIN can edit SLA.</p>
        )}
      </section>
    </AppShell>
  )
}

function StatCard({ label, value, danger }: { label: string; value: number; danger?: boolean }) {
  return (
    <div className="fn-card p-5">
      <p className="text-xs font-semibold uppercase tracking-wide text-[var(--fn-mute)]">{label}</p>
      <p
        className={`fn-display mt-2 text-3xl font-bold ${
          danger ? 'text-[var(--fn-danger)]' : 'text-[var(--fn-ink)]'
        }`}
      >
        {value}
      </p>
    </div>
  )
}
