import { useEffect, useState, type FormEvent } from 'react'
import { Link, useParams } from 'react-router-dom'
import { isAxiosError } from 'axios'
import { AppShell } from '../../components/layout/AppShell'
import { createComplaint, listComplaints, type Complaint } from '../../services/api/complaintApi'
import {
  createDepartment,
  createInvitation,
  getOrganization,
  listDepartments,
  listMembers,
  type Department,
  type InvitationCreated,
  type Member,
  type MemberRole,
  type Organization,
} from '../../services/api/organizationApi'

export function OrganizationDetailPage() {
  const { organizationId = '' } = useParams()
  const [org, setOrg] = useState<Organization | null>(null)
  const [members, setMembers] = useState<Member[]>([])
  const [departments, setDepartments] = useState<Department[]>([])
  const [complaints, setComplaints] = useState<Complaint[]>([])
  const [deptName, setDeptName] = useState('')
  const [inviteRole, setInviteRole] = useState<MemberRole>('MEMBER')
  const [inviteEmail, setInviteEmail] = useState('')
  const [createdInvite, setCreatedInvite] = useState<InvitationCreated | null>(null)
  const [title, setTitle] = useState('')
  const [description, setDescription] = useState('')
  const [category, setCategory] = useState('Facilities')
  const [locationText, setLocationText] = useState('')
  const [latitude, setLatitude] = useState('')
  const [longitude, setLongitude] = useState('')
  const [error, setError] = useState<string | null>(null)
  const [message, setMessage] = useState<string | null>(null)

  const canLead = org?.myRole === 'HEAD' || org?.myRole === 'CO_ADMIN'
  const isCivic = org?.organizationType === 'CIVIC'

  async function reload() {
    const [o, m, d, c] = await Promise.all([
      getOrganization(organizationId),
      listMembers(organizationId),
      listDepartments(organizationId),
      listComplaints(organizationId),
    ])
    setOrg(o.data)
    setMembers(m.data)
    setDepartments(d.data)
    setComplaints(c.data)
  }

  useEffect(() => {
    void reload().catch((err) => {
      setError(isAxiosError(err) ? err.response?.data?.error?.message ?? 'Failed to load' : 'Failed to load')
    })
  }, [organizationId])

  async function onCreateComplaint(event: FormEvent) {
    event.preventDefault()
    setError(null)
    setMessage(null)
    try {
      const lat = latitude.trim() === '' ? undefined : Number(latitude)
      const lng = longitude.trim() === '' ? undefined : Number(longitude)
      if ((lat != null && Number.isNaN(lat)) || (lng != null && Number.isNaN(lng))) {
        setError('Latitude and longitude must be valid numbers.')
        return
      }
      await createComplaint(organizationId, {
        title,
        description,
        category,
        locationText: locationText || undefined,
        latitude: lat,
        longitude: lng,
      })
      setTitle('')
      setDescription('')
      setLocationText('')
      setLatitude('')
      setLongitude('')
      setMessage('Complaint registered and visible to organization members.')
      await reload()
    } catch (err) {
      setError(isAxiosError(err) ? err.response?.data?.error?.message ?? 'Failed' : 'Failed')
    }
  }

  async function onCreateDept(event: FormEvent) {
    event.preventDefault()
    try {
      await createDepartment(organizationId, { name: deptName })
      setDeptName('')
      await reload()
    } catch (err) {
      setError(isAxiosError(err) ? err.response?.data?.error?.message ?? 'Failed' : 'Failed')
    }
  }

  async function onInvite(event: FormEvent) {
    event.preventDefault()
    try {
      const res = await createInvitation(organizationId, {
        memberRole: inviteRole,
        invitedEmail: inviteEmail || undefined,
      })
      setCreatedInvite(res.data)
    } catch (err) {
      setError(isAxiosError(err) ? err.response?.data?.error?.message ?? 'Invite failed' : 'Invite failed')
    }
  }

  if (!org) {
    return (
      <AppShell title="Organization">
        <p className="text-[var(--fn-mute)]">{error ?? 'Loading…'}</p>
      </AppShell>
    )
  }

  return (
    <AppShell title={org.name} subtitle={`${org.organizationType} · ${org.timezone} · you are ${org.myRole}`}>
      <div className="mb-4 flex flex-wrap gap-3 text-sm">
        <Link to="/organizations" className="font-semibold text-[var(--fn-acc)]">
          ← All organizations
        </Link>
        <Link to={`/organizations/${organizationId}/dashboard`} className="font-semibold text-[var(--fn-acc)]">
          Dashboard
        </Link>
        <Link to={`/organizations/${organizationId}/commitments`} className="font-semibold text-[var(--fn-acc)]">
          Commitments
        </Link>
      </div>
      {error && <p className="mb-3 text-sm text-[var(--fn-danger)]">{error}</p>}
      {message && <p className="mb-3 text-sm text-[var(--fn-ok)]">{message}</p>}

      {(org.addressLine || org.city) && (
        <section className="fn-card fn-enter mb-5 p-5">
          <h2 className="text-sm font-semibold uppercase tracking-wide text-[var(--fn-mute)]">Address</h2>
          <p className="mt-1 text-sm">
            {[org.addressLine, org.city, org.stateProvince, org.country].filter(Boolean).join(', ')}
          </p>
        </section>
      )}

      <section className="fn-card fn-enter mb-5 p-6">
        <div className="mb-4 flex items-center justify-between gap-3">
          <h2 className="fn-display text-lg font-semibold">Complaints</h2>
          <span className="fn-badge">{complaints.length} registered</span>
        </div>
        <form className="mb-5 grid gap-3 md:grid-cols-2" onSubmit={onCreateComplaint}>
          <input
            className="fn-input md:col-span-2"
            placeholder="Title"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            required
          />
          <input
            className="fn-input"
            placeholder="Category (e.g. Facilities)"
            value={category}
            onChange={(e) => setCategory(e.target.value)}
            required
          />
          <input
            className="fn-input"
            placeholder="Location (optional)"
            value={locationText}
            onChange={(e) => setLocationText(e.target.value)}
          />
          {isCivic && (
            <>
              <input
                className="fn-input"
                placeholder="Latitude (optional)"
                value={latitude}
                onChange={(e) => setLatitude(e.target.value)}
                inputMode="decimal"
              />
              <input
                className="fn-input"
                placeholder="Longitude (optional)"
                value={longitude}
                onChange={(e) => setLongitude(e.target.value)}
                inputMode="decimal"
              />
            </>
          )}
          <textarea
            className="fn-input min-h-24 md:col-span-2"
            placeholder="Describe the problem"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            required
          />
          <button type="submit" className="fn-btn fn-btn-primary md:col-span-2">
            Register complaint
          </button>
        </form>
        <ul className="space-y-3">
          {complaints.map((c) => (
            <li key={c.id}>
              <Link
                to={`/organizations/${organizationId}/complaints/${c.id}`}
                className="block rounded-xl border border-[var(--fn-line)] bg-[var(--fn-bg)] p-4 no-underline transition hover:border-[var(--fn-acc)]"
              >
                <div className="flex flex-wrap items-center gap-2">
                  <p className="font-semibold text-[var(--fn-ink)]">{c.title}</p>
                  <span className="fn-badge">{c.workflowStatus}</span>
                  <span className="fn-badge">{c.priority}</span>
                  {c.overdue && <span className="fn-badge-danger fn-badge">Overdue</span>}
                  {(c.supportCount ?? 0) > 0 && (
                    <span className="fn-badge">{c.supportCount} supports</span>
                  )}
                </div>
                <p className="mt-1 text-sm text-[var(--fn-mute)]">
                  {c.category} · by {c.reporterName}
                  {c.assigneeName ? ` · assigned ${c.assigneeName}` : ''}
                  {c.locationText ? ` · ${c.locationText}` : ''}
                </p>
                <p className="mt-2 text-sm text-[var(--fn-ink)]">{c.description}</p>
              </Link>
            </li>
          ))}
          {complaints.length === 0 && (
            <p className="text-sm text-[var(--fn-mute)]">No complaints yet. Register the first one above.</p>
          )}
        </ul>
      </section>

      <div className="grid gap-5 md:grid-cols-2">
        <section className="fn-card fn-enter fn-enter-delay-1 p-6">
          <h2 className="fn-display text-lg font-semibold">Members</h2>
          <ul className="mt-3 space-y-2 text-sm">
            {members.map((m) => (
              <li key={m.membershipId} className="flex justify-between gap-2">
                <span>{m.fullName}</span>
                <span className="fn-badge">{m.memberRole}</span>
              </li>
            ))}
          </ul>
        </section>

        <section className="fn-card fn-enter fn-enter-delay-2 p-6">
          <h2 className="fn-display text-lg font-semibold">Departments</h2>
          <ul className="mt-3 space-y-1 text-sm">
            {departments.map((d) => (
              <li key={d.id}>{d.name}</li>
            ))}
          </ul>
          {canLead && (
            <form className="mt-3 flex gap-2" onSubmit={onCreateDept}>
              <input className="fn-input" value={deptName} onChange={(e) => setDeptName(e.target.value)} required />
              <button type="submit" className="fn-btn fn-btn-primary shrink-0">
                Add
              </button>
            </form>
          )}
        </section>
      </div>

      {canLead && (
        <section className="fn-card fn-enter fn-enter-delay-3 mt-5 p-6">
          <h2 className="fn-display text-lg font-semibold">Create invitation</h2>
          <form className="mt-3 space-y-3" onSubmit={onInvite}>
            <select
              className="fn-input"
              value={inviteRole}
              onChange={(e) => setInviteRole(e.target.value as MemberRole)}
            >
              {(
                [
                  'CO_ADMIN',
                  'DEPARTMENT_MANAGER',
                  'OFFICIAL',
                  'INVESTIGATOR',
                  'COMMUNITY_MODERATOR',
                  'MEMBER',
                ] as MemberRole[]
              ).map((r) => (
                <option key={r} value={r}>
                  {r}
                </option>
              ))}
            </select>
            <input
              className="fn-input"
              placeholder="Optional email lock"
              value={inviteEmail}
              onChange={(e) => setInviteEmail(e.target.value)}
            />
            <button type="submit" className="fn-btn fn-btn-primary">
              Generate code
            </button>
          </form>
          {createdInvite && (
            <p className="mt-3 break-all rounded-xl bg-[var(--fn-bg)] p-3 text-sm">
              Code: <code>{createdInvite.invitationCode}</code>
            </p>
          )}
        </section>
      )}
    </AppShell>
  )
}
