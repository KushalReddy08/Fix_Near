import { useEffect, useState, type FormEvent } from 'react'
import { Link } from 'react-router-dom'
import { isAxiosError } from 'axios'
import { AppShell } from '../../components/layout/AppShell'
import { useAuth } from '../auth/AuthContext'
import { listCities, listCountries, listStates } from '../../services/api/locationApi'
import {
  joinOrganization,
  myOrganizations,
  myOrgRequests,
  submitOrgRequest,
  type Organization,
  type OrganizationType,
  type OrgRequest,
} from '../../services/api/organizationApi'

const TYPES: OrganizationType[] = ['COLLEGE', 'CORPORATE', 'RESIDENTIAL', 'CIVIC']
const ADDRESS_STEPS = ['Country', 'State', 'City', 'Address', 'Details'] as const
type AddressStep = (typeof ADDRESS_STEPS)[number]

const TIMEZONES = [
  'Asia/Kolkata',
  'Asia/Dubai',
  'Asia/Singapore',
  'Asia/Tokyo',
  'Asia/Shanghai',
  'Europe/London',
  'Europe/Berlin',
  'Europe/Paris',
  'America/New_York',
  'America/Chicago',
  'America/Denver',
  'America/Los_Angeles',
  'Australia/Sydney',
  'UTC',
] as const

function defaultTimezone() {
  try {
    const detected = Intl.DateTimeFormat().resolvedOptions().timeZone
    if (detected && (TIMEZONES as readonly string[]).includes(detected)) {
      return detected
    }
    if (detected) {
      return detected
    }
  } catch {
    // ignore
  }
  return 'Asia/Kolkata'
}

export function OrganizationsPage() {
  const { user } = useAuth()
  const [orgs, setOrgs] = useState<Organization[]>([])
  const [requests, setRequests] = useState<OrgRequest[]>([])
  const [step, setStep] = useState<AddressStep>('Country')
  const [name, setName] = useState('')
  const [organizationType, setOrganizationType] = useState<OrganizationType>('COLLEGE')
  const [timezone, setTimezone] = useState(defaultTimezone)
  const [description, setDescription] = useState('')
  const [country, setCountry] = useState('')
  const [stateProvince, setStateProvince] = useState('')
  const [city, setCity] = useState('')
  const [addressLine, setAddressLine] = useState('')
  const [countries, setCountries] = useState<string[]>([])
  const [states, setStates] = useState<string[]>([])
  const [cities, setCities] = useState<string[]>([])
  const [loadingLocations, setLoadingLocations] = useState(false)
  const [inviteCode, setInviteCode] = useState('')
  const [message, setMessage] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)

  async function reload() {
    const [orgRes, reqRes] = await Promise.all([myOrganizations(), myOrgRequests()])
    setOrgs(orgRes.data)
    setRequests(reqRes.data)
  }

  useEffect(() => {
    void reload().catch((err) => {
      setError(isAxiosError(err) ? err.response?.data?.error?.message ?? 'Failed to load' : 'Failed to load')
    })
  }, [])

  useEffect(() => {
    setLoadingLocations(true)
    void listCountries()
      .then(setCountries)
      .catch((err) => {
        setError(
          isAxiosError(err)
            ? err.response?.data?.error?.message ?? 'Could not load countries'
            : 'Could not load countries',
        )
      })
      .finally(() => setLoadingLocations(false))
  }, [])

  useEffect(() => {
    if (step !== 'State' || !country) return
    let cancelled = false
    setLoadingLocations(true)
    setError(null)
    void listStates(country)
      .then((items) => {
        if (!cancelled) setStates(items)
      })
      .catch((err) => {
        if (!cancelled) {
          setStates([])
          setError(
            isAxiosError(err)
              ? err.response?.data?.error?.message ?? 'Could not load states'
              : 'Could not load states',
          )
        }
      })
      .finally(() => {
        if (!cancelled) setLoadingLocations(false)
      })
    return () => {
      cancelled = true
    }
  }, [step, country])

  useEffect(() => {
    if (step !== 'City' || !country || !stateProvince) return
    let cancelled = false
    setLoadingLocations(true)
    setError(null)
    void listCities(country, stateProvince)
      .then((items) => {
        if (!cancelled) setCities(items)
      })
      .catch((err) => {
        if (!cancelled) {
          setCities([])
          setError(
            isAxiosError(err)
              ? err.response?.data?.error?.message ?? 'Could not load cities'
              : 'Could not load cities',
          )
        }
      })
      .finally(() => {
        if (!cancelled) setLoadingLocations(false)
      })
    return () => {
      cancelled = true
    }
  }, [step, country, stateProvince])

  function onCountryChange(value: string) {
    setCountry(value)
    setStateProvince('')
    setCity('')
    setStates([])
    setCities([])
  }

  function onStateChange(value: string) {
    setStateProvince(value)
    setCity('')
    setCities([])
  }

  function goNext() {
    setError(null)
    if (step === 'Country') {
      if (!country) {
        setError('Select a country to continue.')
        return
      }
      setStep('State')
      return
    }
    if (step === 'State') {
      if (!stateProvince.trim()) {
        setError('Select or enter a state / province to continue.')
        return
      }
      setStep('City')
      return
    }
    if (step === 'City') {
      if (!city.trim()) {
        setError('Select or enter a city to continue.')
        return
      }
      setStep('Address')
      return
    }
    if (step === 'Address') {
      if (!addressLine.trim()) {
        setError('Enter the organization street address to continue.')
        return
      }
      setStep('Details')
    }
  }

  function goBack() {
    setError(null)
    if (step === 'State') setStep('Country')
    else if (step === 'City') setStep('State')
    else if (step === 'Address') setStep('City')
    else if (step === 'Details') setStep('Address')
  }

  function resetRequestForm() {
    setStep('Country')
    setName('')
    setDescription('')
    setCountry('')
    setStateProvince('')
    setCity('')
    setAddressLine('')
    setStates([])
    setCities([])
  }

  async function onSubmitRequest(event: FormEvent) {
    event.preventDefault()
    setError(null)
    setMessage(null)
    try {
      await submitOrgRequest({
        name,
        organizationType,
        timezone,
        description,
        country,
        stateProvince,
        city,
        addressLine: addressLine.trim(),
      })
      setMessage('Request sent. Waiting for system admin approval.')
      resetRequestForm()
      await reload()
    } catch (err) {
      setError(isAxiosError(err) ? err.response?.data?.error?.message ?? 'Request failed' : 'Request failed')
    }
  }

  async function onJoin(event: FormEvent) {
    event.preventDefault()
    setError(null)
    setMessage(null)
    try {
      const joined = await joinOrganization(inviteCode)
      setMessage(`Joined ${joined.data.name} as ${joined.data.myRole}`)
      setInviteCode('')
      await reload()
    } catch (err) {
      setError(isAxiosError(err) ? err.response?.data?.error?.message ?? 'Join failed' : 'Join failed')
    }
  }

  const stepIndex = ADDRESS_STEPS.indexOf(step)

  return (
    <AppShell title="Organizations" subtitle="Private workspaces with membership, invites, and complaints.">
      {error && <p className="mb-4 text-sm text-[var(--fn-danger)]">{error}</p>}
      {message && <p className="mb-4 text-sm text-[var(--fn-ok)]">{message}</p>}

      <section className="fn-card fn-enter mb-5 p-6">
        <h2 className="fn-display text-lg font-semibold">My organizations</h2>
        {orgs.length === 0 && <p className="mt-2 text-sm text-[var(--fn-mute)]">No memberships yet.</p>}
        <ul className="mt-4 space-y-2">
          {orgs.map((org) => (
            <li key={org.id} className="flex items-center justify-between rounded-xl bg-[var(--fn-bg)] px-4 py-3">
              <div>
                <Link className="font-semibold text-[var(--fn-acc)]" to={`/organizations/${org.id}`}>
                  {org.name}
                </Link>
                <p className="text-sm text-[var(--fn-mute)]">
                  {org.organizationType} · {org.myRole}
                  {org.city ? ` · ${org.city}` : ''}
                </p>
              </div>
              <span className="fn-badge">Open</span>
            </li>
          ))}
        </ul>
      </section>

      <div className="grid gap-5 md:grid-cols-2">
        <section className="fn-card fn-enter fn-enter-delay-1 p-6">
          <h2 className="fn-display text-lg font-semibold">Request organization</h2>
          <p className="mt-1 text-sm text-[var(--fn-mute)]">
            Signed in as {user?.email}. Choose location step by step, then enter details.
          </p>

          <ol className="mt-4 flex flex-wrap gap-2 text-xs">
            {ADDRESS_STEPS.map((label, index) => (
              <li
                key={label}
                className={`rounded-full px-3 py-1 ${
                  index === stepIndex
                    ? 'bg-[var(--fn-acc)] text-white'
                    : index < stepIndex
                      ? 'bg-[var(--fn-ok)]/15 text-[var(--fn-ok)]'
                      : 'bg-[var(--fn-bg)] text-[var(--fn-mute)]'
                }`}
              >
                {index + 1}. {label}
              </li>
            ))}
          </ol>

          {step !== 'Details' ? (
            <div className="mt-4 space-y-3">
              {step === 'Country' && (
                <>
                  <label className="block text-sm font-medium">Country</label>
                  <select
                    className="fn-input"
                    value={country}
                    disabled={loadingLocations && countries.length === 0}
                    onChange={(e) => onCountryChange(e.target.value)}
                    required
                  >
                    <option value="">{loadingLocations ? 'Loading countries…' : 'Select country'}</option>
                    {countries.map((item) => (
                      <option key={item} value={item}>
                        {item}
                      </option>
                    ))}
                  </select>
                </>
              )}

              {step === 'State' && (
                <>
                  <p className="text-sm text-[var(--fn-mute)]">Country: {country}</p>
                  <label className="block text-sm font-medium">State / province</label>
                  {states.length > 0 ? (
                    <select
                      className="fn-input"
                      value={stateProvince}
                      disabled={loadingLocations}
                      onChange={(e) => onStateChange(e.target.value)}
                      required
                    >
                      <option value="">{loadingLocations ? 'Loading states…' : 'Select state / province'}</option>
                      {states.map((item) => (
                        <option key={item} value={item}>
                          {item}
                        </option>
                      ))}
                    </select>
                  ) : (
                    <input
                      className="fn-input"
                      placeholder={loadingLocations ? 'Loading states…' : 'Type state / province'}
                      value={stateProvince}
                      disabled={loadingLocations}
                      onChange={(e) => onStateChange(e.target.value)}
                      required
                    />
                  )}
                </>
              )}

              {step === 'City' && (
                <>
                  <p className="text-sm text-[var(--fn-mute)]">
                    {country} · {stateProvince}
                  </p>
                  <label className="block text-sm font-medium">City</label>
                  {cities.length > 0 ? (
                    <select
                      className="fn-input"
                      value={city}
                      disabled={loadingLocations}
                      onChange={(e) => setCity(e.target.value)}
                      required
                    >
                      <option value="">{loadingLocations ? 'Loading cities…' : 'Select city'}</option>
                      {cities.map((item) => (
                        <option key={item} value={item}>
                          {item}
                        </option>
                      ))}
                    </select>
                  ) : (
                    <input
                      className="fn-input"
                      placeholder={loadingLocations ? 'Loading cities…' : 'Type city'}
                      value={city}
                      disabled={loadingLocations}
                      onChange={(e) => setCity(e.target.value)}
                      required
                    />
                  )}
                </>
              )}

              {step === 'Address' && (
                <>
                  <p className="text-sm text-[var(--fn-mute)]">
                    {city}, {stateProvince}, {country}
                  </p>
                  <label className="block text-sm font-medium">Organization address</label>
                  <textarea
                    className="fn-input min-h-24"
                    placeholder="Street, building, landmark, postal code"
                    value={addressLine}
                    onChange={(e) => setAddressLine(e.target.value)}
                    required
                  />
                </>
              )}

              <div className="flex gap-2 pt-1">
                {step !== 'Country' && (
                  <button type="button" className="fn-btn fn-btn-ghost" onClick={goBack}>
                    Back
                  </button>
                )}
                <button type="button" className="fn-btn fn-btn-primary" onClick={goNext} disabled={loadingLocations}>
                  Continue
                </button>
              </div>
            </div>
          ) : (
            <form className="mt-4 space-y-3" onSubmit={onSubmitRequest}>
              <p className="rounded-xl bg-[var(--fn-bg)] px-3 py-2 text-sm text-[var(--fn-mute)]">
                {addressLine}
                <br />
                {city}, {stateProvince}, {country}
              </p>
              <label className="block text-sm font-medium">
                Organization name
                <input
                  className="fn-input mt-1"
                  placeholder="Organization name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  autoComplete="organization"
                  required
                />
              </label>
              <label className="block text-sm font-medium">
                Type
                <select
                  className="fn-input mt-1"
                  value={organizationType}
                  onChange={(e) => setOrganizationType(e.target.value as OrganizationType)}
                >
                  {TYPES.map((t) => (
                    <option key={t} value={t}>
                      {t}
                    </option>
                  ))}
                </select>
              </label>
              <label className="block text-sm font-medium">
                Timezone
                <select
                  className="fn-input mt-1"
                  value={timezone}
                  onChange={(e) => setTimezone(e.target.value)}
                  required
                >
                  {!TIMEZONES.includes(timezone as (typeof TIMEZONES)[number]) && (
                    <option value={timezone}>{timezone}</option>
                  )}
                  {TIMEZONES.map((tz) => (
                    <option key={tz} value={tz}>
                      {tz}
                    </option>
                  ))}
                </select>
              </label>
              <label className="block text-sm font-medium">
                Description
                <textarea
                  className="fn-input mt-1 min-h-20"
                  placeholder="Optional description"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                />
              </label>
              <div className="flex gap-2">
                <button type="button" className="fn-btn fn-btn-ghost" onClick={goBack}>
                  Back
                </button>
                <button type="submit" className="fn-btn fn-btn-primary">
                  Submit request
                </button>
              </div>
            </form>
          )}

          <ul className="mt-4 space-y-1 text-sm text-[var(--fn-mute)]">
            {requests.map((r) => (
              <li key={r.id}>
                {r.name} · <span className="fn-badge">{r.status}</span>
                {r.city ? ` · ${r.city}, ${r.country}` : ''}
              </li>
            ))}
          </ul>
        </section>

        <section className="fn-card fn-enter fn-enter-delay-2 p-6">
          <h2 className="fn-display text-lg font-semibold">Join with invite</h2>
          <form className="mt-4 flex gap-2" onSubmit={onJoin}>
            <input className="fn-input" value={inviteCode} onChange={(e) => setInviteCode(e.target.value)} required />
            <button type="submit" className="fn-btn fn-btn-primary shrink-0">
              Join
            </button>
          </form>
        </section>
      </div>
    </AppShell>
  )
}
