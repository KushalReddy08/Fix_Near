import { Link } from 'react-router-dom'
import { useBackendHealth } from '../../hooks/health/useBackendHealth'

export function LandingPage() {
  const { data, isLoading, isError, refetch, isFetching } = useBackendHealth()

  return (
    <div className="relative overflow-hidden">
      <div className="fn-hero-orb -top-10 left-10 opacity-80" />
      <div className="fn-hero-orb top-40 right-0 opacity-50" style={{ animationDelay: '1.2s' }} />

      <header className="mx-auto flex max-w-6xl items-center justify-between px-6 py-5">
        <div className="flex items-center gap-2">
          <span className="fn-brand-mark text-sm">✓</span>
          <span className="fn-display text-xl font-bold">FixNear</span>
        </div>
        <div className="flex gap-2">
          <Link to="/login" className="fn-btn fn-btn-ghost">
            Sign in
          </Link>
          <Link to="/register" className="fn-btn fn-btn-primary">
            Create account
          </Link>
        </div>
      </header>

      <section className="mx-auto grid max-w-6xl items-center gap-10 px-6 pb-20 pt-10 md:grid-cols-[1.15fr_0.85fr]">
        <div className="fn-enter relative z-10">
          <p className="text-xs font-semibold tracking-[0.22em] text-[var(--fn-acc)] uppercase">
            Accountability platform
          </p>
          <h1 className="fn-display mt-4 text-4xl font-extrabold leading-[1.08] text-[var(--fn-ink)] md:text-6xl">
            Report. Track.
            <span className="block text-[var(--fn-acc)]">Verify action.</span>
          </h1>
          <p className="mt-5 max-w-xl text-lg text-[var(--fn-mute)]">
            FixNear connects people with the organizations responsible for fixing problems — with
            evidence, deadlines, and verified completion.
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Link to="/register" className="fn-btn fn-btn-primary px-5 py-3">
              Start participating
            </Link>
            <Link to="/login" className="fn-btn fn-btn-ghost px-5 py-3">
              System admin sign-in
            </Link>
          </div>
        </div>

        <div className="fn-enter fn-enter-delay-2 fn-float relative z-10">
          <div className="fn-card p-6">
            <div className="mb-4 flex items-center justify-between">
              <h2 className="fn-display text-lg font-semibold">Live platform pulse</h2>
              <button
                type="button"
                className="fn-btn fn-btn-ghost text-sm"
                disabled={isFetching}
                onClick={() => refetch()}
              >
                Refresh
              </button>
            </div>
            {isLoading && <p className="text-[var(--fn-mute)]">Checking API…</p>}
            {isError && <p className="text-[var(--fn-danger)]">Backend unreachable</p>}
            {data?.success && (
              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <span className="fn-badge">API {data.data.status}</span>
                  <span className="fn-badge">{data.data.phase}</span>
                </div>
                <p className="text-sm text-[var(--fn-mute)]">
                  Service <strong className="text-[var(--fn-ink)]">{data.data.service}</strong> is
                  responding through the Axios client.
                </p>
                <div className="grid grid-cols-3 gap-2 text-center">
                  {['Report', 'Assign', 'Verify'].map((step, i) => (
                    <div
                      key={step}
                      className="rounded-xl bg-[var(--fn-bg)] p-3 text-sm font-semibold"
                      style={{ animationDelay: `${i * 0.1}s` }}
                    >
                      {step}
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </section>
    </div>
  )
}
