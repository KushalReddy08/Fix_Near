import { useState, type FormEvent } from 'react'
import { isAxiosError } from 'axios'
import { AppShell } from '../../components/layout/AppShell'
import { useAuth } from './AuthContext'
import { changePassword, updateMe } from '../../services/api/userApi'

export function ProfilePage() {
  const { user, setUser, logout } = useAuth()
  const [fullName, setFullName] = useState(user?.fullName ?? '')
  const [currentPassword, setCurrentPassword] = useState('')
  const [newPassword, setNewPassword] = useState('')
  const [profileMessage, setProfileMessage] = useState<string | null>(null)
  const [passwordMessage, setPasswordMessage] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)

  if (!user) return null

  async function onSaveProfile(event: FormEvent) {
    event.preventDefault()
    setError(null)
    try {
      const response = await updateMe(fullName)
      setUser(response.data)
      setProfileMessage('Profile updated')
    } catch (err) {
      setError(isAxiosError(err) ? err.response?.data?.error?.message ?? 'Update failed' : 'Update failed')
    }
  }

  async function onChangePassword(event: FormEvent) {
    event.preventDefault()
    setError(null)
    try {
      const response = await changePassword({ currentPassword, newPassword })
      setPasswordMessage(response.data.message)
      setCurrentPassword('')
      setNewPassword('')
      await logout()
    } catch (err) {
      setError(isAxiosError(err) ? err.response?.data?.error?.message ?? 'Password change failed' : 'Password change failed')
    }
  }

  return (
    <AppShell title="Your profile" subtitle={`${user.email} · ${user.platformRole}`}>
      <form onSubmit={onSaveProfile} className="fn-card fn-enter mb-5 space-y-3 p-6">
        <h2 className="fn-display font-semibold">Display name</h2>
        <input className="fn-input" value={fullName} onChange={(e) => setFullName(e.target.value)} required />
        <button type="submit" className="fn-btn fn-btn-primary">Save</button>
        {profileMessage && <p className="text-sm text-[var(--fn-ok)]">{profileMessage}</p>}
      </form>
      <form onSubmit={onChangePassword} className="fn-card fn-enter fn-enter-delay-1 space-y-3 p-6">
        <h2 className="fn-display font-semibold">Change password</h2>
        <input className="fn-input" type="password" placeholder="Current password" value={currentPassword} onChange={(e) => setCurrentPassword(e.target.value)} minLength={8} required />
        <input className="fn-input" type="password" placeholder="New password" value={newPassword} onChange={(e) => setNewPassword(e.target.value)} minLength={8} required />
        <button type="submit" className="fn-btn fn-btn-primary">Update password</button>
        {passwordMessage && <p className="text-sm text-[var(--fn-ok)]">{passwordMessage}</p>}
      </form>
      {error && <p className="mt-4 text-sm text-[var(--fn-danger)]">{error}</p>}
    </AppShell>
  )
}
