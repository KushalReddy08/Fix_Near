import { useState, type FormEvent, type ReactNode } from 'react'
import { Link } from 'react-router-dom'
import { isAxiosError } from 'axios'
import { register, resendVerification, type RegisterResult } from '../../services/api/authApi'

export function RegisterPage() {
  const [fullName, setFullName] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState<string | null>(null)
  const [result, setResult] = useState<RegisterResult | null>(null)
  const [submitting, setSubmitting] = useState(false)

  async function onSubmit(event: FormEvent) {
    event.preventDefault()
    setError(null)
    setResult(null)
    setSubmitting(true)
    try {
      const response = await register({ fullName, email, password })
      setResult(response.data)
    } catch (err) {
      if (isAxiosError(err)) {
        const code = err.response?.data?.error?.code
        const message = err.response?.data?.error?.message ?? 'Registration failed'
        if (code === 'EMAIL_ALREADY_REGISTERED') {
          setError(`${message} If you have not verified yet, use Resend below.`)
        } else {
          setError(message)
        }
      } else {
        setError('Registration failed')
      }
    } finally {
      setSubmitting(false)
    }
  }

  async function onResend() {
    setError(null)
    setSubmitting(true)
    try {
      const response = await resendVerification(email)
      setResult(response.data)
    } catch (err) {
      if (isAxiosError(err)) {
        setError(err.response?.data?.error?.message ?? 'Could not resend verification')
      } else {
        setError('Could not resend verification')
      }
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <AuthShell
      title="Create account"
      subtitle="A system email is sent via Mailpit (http://127.0.0.1:8025). Dev also shows the token on screen."
    >
      <form className="space-y-4" onSubmit={onSubmit}>
        <Field label="Full name" value={fullName} onChange={setFullName} />
        <Field label="Email" type="email" value={email} onChange={setEmail} />
        <Field label="Password" type="password" value={password} onChange={setPassword} minLength={8} />
        {error && <p className="text-sm text-red-600">{error}</p>}
        <button
          type="submit"
          disabled={submitting}
          className="w-full rounded-xl bg-[var(--fn-acc)] px-4 py-2.5 font-semibold text-white disabled:opacity-60"
        >
          {submitting ? 'Creating…' : 'Register'}
        </button>
      </form>

      {email && (
        <button
          type="button"
          onClick={() => void onResend()}
          disabled={submitting}
          className="mt-3 w-full rounded-xl border border-[var(--fn-line)] px-4 py-2.5 text-sm font-semibold disabled:opacity-60"
        >
          Resend verification token
        </button>
      )}

      {result && (
        <div className="mt-4 space-y-2 rounded-xl bg-[var(--fn-bg)] p-4 text-sm">
          <p className="font-semibold text-emerald-700">{result.message}</p>
          {result.verificationToken && (
            <>
              <p className="text-[var(--fn-mute)]">Verification token (copy or open link):</p>
              <code className="block break-all rounded-lg bg-white p-2 text-xs">{result.verificationToken}</code>
              {result.verificationUrl && (
                <Link className="inline-block font-semibold text-[var(--fn-acc)]" to={`/verify-email?token=${encodeURIComponent(result.verificationToken)}`}>
                  Verify email now →
                </Link>
              )}
            </>
          )}
          {!result.verificationToken && (
            <p className="text-[var(--fn-mute)]">Check your inbox (or backend logs if mail is unavailable).</p>
          )}
        </div>
      )}

      <p className="mt-4 text-sm text-[var(--fn-mute)]">
        Already have an account? <Link className="text-[var(--fn-acc)]" to="/login">Sign in</Link>
      </p>
    </AuthShell>
  )
}

function AuthShell({
  title,
  subtitle,
  children,
}: {
  title: string
  subtitle: string
  children: ReactNode
}) {
  return (
    <div className="mx-auto flex min-h-screen max-w-md flex-col justify-center px-6 py-12">
      <p className="text-sm font-semibold tracking-[0.18em] text-[var(--fn-acc)] uppercase">FixNear</p>
      <h1 className="mt-2 text-3xl font-bold tracking-tight">{title}</h1>
      <p className="mt-2 text-[var(--fn-mute)]">{subtitle}</p>
      <div className="mt-8 rounded-2xl border border-[var(--fn-line)] bg-white p-6 shadow-sm">{children}</div>
    </div>
  )
}

function Field({
  label,
  value,
  onChange,
  type = 'text',
  minLength,
}: {
  label: string
  value: string
  onChange: (value: string) => void
  type?: string
  minLength?: number
}) {
  return (
    <label className="block text-sm">
      <span className="mb-1 block font-medium text-[var(--fn-ink)]">{label}</span>
      <input
        className="w-full rounded-xl border border-[var(--fn-line)] px-3 py-2 outline-none focus:border-[var(--fn-acc)]"
        type={type}
        value={value}
        minLength={minLength}
        required
        onChange={(event) => onChange(event.target.value)}
      />
    </label>
  )
}

export { AuthShell, Field }
