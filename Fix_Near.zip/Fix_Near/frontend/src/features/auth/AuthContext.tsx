import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from 'react'
import * as authApi from '../../services/api/authApi'
import { setStoredAccessToken } from '../../services/api/axiosInstance'
import type { User } from '../../types/auth'

interface AuthContextValue {
  user: User | null
  bootstrapping: boolean
  login: (email: string, password: string) => Promise<void>
  logout: () => Promise<void>
  setUser: (user: User | null) => void
}

const AuthContext = createContext<AuthContextValue | undefined>(undefined)

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [bootstrapping, setBootstrapping] = useState(true)

  useEffect(() => {
    let cancelled = false
    ;(async () => {
      try {
        const refreshed = await authApi.refreshSession()
        setStoredAccessToken(refreshed.data.accessToken)
        if (!cancelled) {
          setUser(refreshed.data.user)
        }
      } catch {
        setStoredAccessToken(null)
        if (!cancelled) {
          setUser(null)
        }
      } finally {
        if (!cancelled) {
          setBootstrapping(false)
        }
      }
    })()
    return () => {
      cancelled = true
    }
  }, [])

  const login = useCallback(async (email: string, password: string) => {
    const response = await authApi.login({ email, password })
    setStoredAccessToken(response.data.accessToken)
    setUser(response.data.user)
  }, [])

  const logout = useCallback(async () => {
    try {
      await authApi.logout()
    } finally {
      setStoredAccessToken(null)
      setUser(null)
    }
  }, [])

  const value = useMemo(
    () => ({ user, bootstrapping, login, logout, setUser }),
    [user, bootstrapping, login, logout],
  )

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}

export function useAuth(): AuthContextValue {
  const ctx = useContext(AuthContext)
  if (!ctx) {
    throw new Error('useAuth must be used within AuthProvider')
  }
  return ctx
}
