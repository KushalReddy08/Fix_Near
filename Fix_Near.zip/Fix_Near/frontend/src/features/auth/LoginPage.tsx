import { useState, type FormEvent } from 'react'
import { Link, useLocation, useNavigate } from 'react-router-dom'
import { isAxiosError } from 'axios'
import { useAuth } from './AuthContext'

export function LoginPage() {
  const { login } = useAuth()
  const navigate = useNavigate()
  const location = useLocation()
  const from = (location.state as { from?: string } | null)?.from ?? '/app'

  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState<string | null>(null)
  const [submitting, setSubmitting] = useState(false)

  async function onSubmit(event: FormEvent) {
    event.preventDefault()
    setError(null)
    setSubmitting(true)
    try {
      await login(email, password)
      navigate(from, { replace: true })
    } catch (err) {
      setError(isAxiosError(err) ? err.response?.data?.error?.message ?? 'Login failed' : 'Login failed')
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <div className="relative mx-auto flex min-h-screen max-w-md flex-col justify-center px-6 py-12">
      <div className="fn-hero-orb -top-8 right-0 opacity-60" />
      <div className="fn-enter relative z-10">
        <Link to="/" className="flex items-center gap-2">
          <span className="fn-brand-mark text-sm">✓</span>
          <span className="fn-display text-lg font-bold">FixNear</span>
        </Link>
        <h1 className="fn-display mt-8 text-3xl font-bold">Sign in</h1>
        <p className="mt-2 text-[var(--fn-mute)]">Access your workspace or system approvals.</p>

        <form className="fn-card mt-8 space-y-4 p-6" onSubmit={onSubmit}>
          <label className="block text-sm font-medium">
            Email or username
            <input
              className="fn-input mt-1"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="you@email.com or system"
              required
            />
          </label>
          <label className="block text-sm font-medium">
            Password
            <input
              className="fn-input mt-1"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              minLength={8}
              required
            />
          </label>
          {error && <p className="text-sm text-[var(--fn-danger)]">{error}</p>}
          <button type="submit" className="fn-btn fn-btn-primary w-full" disabled={submitting}>
            {submitting ? 'Signing in…' : 'Sign in'}
          </button>
        </form>

        <p className="mt-4 text-sm text-[var(--fn-mute)]">
          New here? <Link className="font-semibold text-[var(--fn-acc)]" to="/register">Create an account</Link>
        </p>
      </div>
    </div>
  )
}
