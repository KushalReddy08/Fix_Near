import { useEffect, useState, type FormEvent } from 'react'
import { Link, useSearchParams } from 'react-router-dom'
import { isAxiosError } from 'axios'
import { verifyEmail } from '../../services/api/authApi'
import { AuthShell, Field } from './RegisterPage'

export function VerifyEmailPage() {
  const [params] = useSearchParams()
  const [token, setToken] = useState(params.get('token') ?? '')
  const [error, setError] = useState<string | null>(null)
  const [message, setMessage] = useState<string | null>(null)
  const [submitting, setSubmitting] = useState(false)

  useEffect(() => {
    const queryToken = params.get('token')
    if (queryToken) {
      void submitToken(queryToken)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  async function submitToken(value: string) {
    setError(null)
    setMessage(null)
    setSubmitting(true)
    try {
      const response = await verifyEmail(value)
      setMessage(response.data.message)
    } catch (err) {
      if (isAxiosError(err)) {
        setError(err.response?.data?.error?.message ?? 'Verification failed')
      } else {
        setError('Verification failed')
      }
    } finally {
      setSubmitting(false)
    }
  }

  async function onSubmit(event: FormEvent) {
    event.preventDefault()
    await submitToken(token)
  }

  return (
    <AuthShell
      title="Verify email"
      subtitle="Paste the token from your verification email (or backend logs in local dev)."
    >
      <form className="space-y-4" onSubmit={onSubmit}>
        <Field label="Verification token" value={token} onChange={setToken} />
        {error && <p className="text-sm text-red-600">{error}</p>}
        {message && <p className="text-sm text-emerald-700">{message}</p>}
        <button
          type="submit"
          disabled={submitting}
          className="w-full rounded-xl bg-[var(--fn-acc)] px-4 py-2.5 font-semibold text-white disabled:opacity-60"
        >
          {submitting ? 'Verifying…' : 'Verify email'}
        </button>
      </form>
      <p className="mt-4 text-sm text-[var(--fn-mute)]">
        Ready? <Link className="text-[var(--fn-acc)]" to="/login">Sign in</Link>
      </p>
    </AuthShell>
  )
}
