import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { isAxiosError } from 'axios'
import { AppShell } from '../../components/layout/AppShell'
import {
  listNotifications,
  markNotificationRead,
  type Notification,
} from '../../services/api/notificationApi'

function apiError(err: unknown, fallback: string) {
  return isAxiosError(err) ? err.response?.data?.error?.message ?? fallback : fallback
}

export function NotificationsPage() {
  const [items, setItems] = useState<Notification[]>([])
  const [error, setError] = useState<string | null>(null)
  const [busyId, setBusyId] = useState<string | null>(null)

  async function reload() {
    const res = await listNotifications()
    setItems(res.data)
  }

  useEffect(() => {
    void reload().catch((err) => setError(apiError(err, 'Failed to load notifications')))
  }, [])

  async function onMarkRead(id: string) {
    setBusyId(id)
    setError(null)
    try {
      await markNotificationRead(id)
      await reload()
    } catch (err) {
      setError(apiError(err, 'Failed to mark read'))
    } finally {
      setBusyId(null)
    }
  }

  const unread = items.filter((n) => !n.readAt).length

  return (
    <AppShell title="Notifications" subtitle={`${unread} unread · ${items.length} total`}>
      {error && <p className="mb-3 text-sm text-[var(--fn-danger)]">{error}</p>}

      <section className="fn-card fn-enter p-6">
        <ul className="space-y-3">
          {items.map((n) => {
            const complaintHref =
              n.organizationId && n.complaintId
                ? `/organizations/${n.organizationId}/complaints/${n.complaintId}`
                : n.organizationId
                  ? `/organizations/${n.organizationId}`
                  : null

            return (
              <li
                key={n.id}
                className={`rounded-xl border border-[var(--fn-line)] p-4 ${
                  n.readAt ? 'bg-[var(--fn-bg)]' : 'bg-white'
                }`}
              >
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div>
                    <div className="flex flex-wrap items-center gap-2">
                      <p className="font-semibold">{n.title}</p>
                      <span className="fn-badge">{n.type}</span>
                      {!n.readAt && <span className="fn-badge fn-badge-warn">Unread</span>}
                    </div>
                    <p className="mt-1 text-sm text-[var(--fn-mute)]">{n.body}</p>
                    <p className="mt-2 text-xs text-[var(--fn-mute)]">
                      {new Date(n.createdAt).toLocaleString()}
                      {n.readAt ? ` · read ${new Date(n.readAt).toLocaleString()}` : ''}
                    </p>
                    {complaintHref && (
                      <Link
                        to={complaintHref}
                        className="mt-2 inline-block text-sm font-semibold text-[var(--fn-acc)]"
                      >
                        Open related →
                      </Link>
                    )}
                  </div>
                  {!n.readAt && (
                    <button
                      type="button"
                      className="fn-btn fn-btn-ghost text-sm"
                      disabled={busyId === n.id}
                      onClick={() => void onMarkRead(n.id)}
                    >
                      Mark read
                    </button>
                  )}
                </div>
              </li>
            )
          })}
          {items.length === 0 && (
            <p className="text-sm text-[var(--fn-mute)]">You are all caught up.</p>
          )}
        </ul>
      </section>
    </AppShell>
  )
}
