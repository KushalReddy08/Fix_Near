import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { isAxiosError } from 'axios'
import { AppShell } from '../../components/layout/AppShell'
import {
  listCivicMapComplaints,
  openStreetMapUrl,
  type CivicMapComplaint,
} from '../../services/api/civicApi'

function apiError(err: unknown, fallback: string) {
  return isAxiosError(err) ? err.response?.data?.error?.message ?? fallback : fallback
}

export function CivicMapPage() {
  const [items, setItems] = useState<CivicMapComplaint[]>([])
  const [bbox, setBbox] = useState('')
  const [error, setError] = useState<string | null>(null)
  const [loading, setLoading] = useState(true)

  async function load(nextBbox?: string) {
    setLoading(true)
    setError(null)
    try {
      const res = await listCivicMapComplaints(nextBbox || undefined)
      setItems(res.data)
    } catch (err) {
      setError(apiError(err, 'Failed to load civic complaints'))
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    void load()
  }, [])

  return (
    <AppShell
      title="Civic map"
      subtitle="Public civic complaints with coordinates. Open pins in OpenStreetMap."
    >
      <section className="fn-card fn-enter mb-5 p-5">
        <form
          className="flex flex-col gap-2 md:flex-row"
          onSubmit={(e) => {
            e.preventDefault()
            void load(bbox.trim())
          }}
        >
          <input
            className="fn-input"
            placeholder="Optional bbox: minLon,minLat,maxLon,maxLat"
            value={bbox}
            onChange={(e) => setBbox(e.target.value)}
          />
          <button type="submit" className="fn-btn fn-btn-primary shrink-0">
            Refresh
          </button>
        </form>
      </section>

      {error && <p className="mb-3 text-sm text-[var(--fn-danger)]">{error}</p>}
      {loading && <p className="mb-3 text-sm text-[var(--fn-mute)]">Loading…</p>}

      <section className="fn-card fn-enter fn-enter-delay-1 p-6">
        <div className="mb-4 flex items-center justify-between gap-3">
          <h2 className="fn-display text-lg font-semibold">Mapped complaints</h2>
          <span className="fn-badge">{items.length}</span>
        </div>
        <ul className="space-y-3">
          {items.map((c) => (
            <li key={c.id} className="rounded-xl border border-[var(--fn-line)] bg-[var(--fn-bg)] p-4">
              <div className="flex flex-wrap items-center gap-2">
                <p className="font-semibold">{c.title}</p>
                <span className="fn-badge">{c.workflowStatus}</span>
                <span className="fn-badge">{c.priority}</span>
                {c.overdue && <span className="fn-badge fn-badge-danger">Overdue</span>}
              </div>
              <p className="mt-1 text-sm text-[var(--fn-mute)]">
                {c.organizationName ?? c.organizationId}
                {c.category ? ` · ${c.category}` : ''}
                {c.locationText ? ` · ${c.locationText}` : ''}
              </p>
              <div className="mt-3 flex flex-wrap gap-3 text-sm">
                <Link
                  to={`/organizations/${c.organizationId}/complaints/${c.id}`}
                  className="font-semibold text-[var(--fn-acc)]"
                >
                  Open complaint
                </Link>
                {c.latitude != null && c.longitude != null && (
                  <a
                    href={openStreetMapUrl(c.latitude, c.longitude)}
                    target="_blank"
                    rel="noreferrer"
                    className="font-semibold text-[var(--fn-acc)]"
                  >
                    OSM ({c.latitude.toFixed(4)}, {c.longitude.toFixed(4)}) ↗
                  </a>
                )}
              </div>
            </li>
          ))}
          {!loading && items.length === 0 && (
            <p className="text-sm text-[var(--fn-mute)]">
              No civic complaints with coordinates in this view.
            </p>
          )}
        </ul>
      </section>
    </AppShell>
  )
}
