import { useCallback, useEffect, useMemo, useState, type FormEvent } from 'react'
import { Link, useParams } from 'react-router-dom'
import { isAxiosError } from 'axios'
import { AppShell } from '../../components/layout/AppShell'
import { useAuth } from '../auth/AuthContext'
import {
  acknowledgeComplaint,
  addComplaintComment,
  adminCloseComplaint,
  assignComplaint,
  downloadComplaintAttachment,
  getComplaint,
  listComplaintAttachments,
  listComplaintComments,
  listComplaintEvents,
  rejectComplaint,
  reporterAckComplaint,
  resolveComplaint,
  startComplaint,
  toggleComplaintSupport,
  uploadComplaintAttachment,
  type CommentVisibility,
  type Complaint,
  type ComplaintAttachment,
  type ComplaintComment,
  type ComplaintEvent,
} from '../../services/api/complaintApi'
import {
  getOrganization,
  listDepartments,
  listMembers,
  type Department,
  type Member,
  type MemberRole,
  type Organization,
} from '../../services/api/organizationApi'
import { openStreetMapUrl } from '../../services/api/civicApi'

const STAFF_ROLES: MemberRole[] = [
  'HEAD',
  'CO_ADMIN',
  'DEPARTMENT_MANAGER',
  'OFFICIAL',
  'INVESTIGATOR',
]

function apiError(err: unknown, fallback: string) {
  return isAxiosError(err) ? err.response?.data?.error?.message ?? fallback : fallback
}

function formatWhen(value: string | null | undefined) {
  if (!value) return '—'
  try {
    return new Date(value).toLocaleString()
  } catch {
    return value
  }
}

export function ComplaintDetailPage() {
  const { organizationId = '', complaintId = '' } = useParams()
  const { user } = useAuth()

  const [org, setOrg] = useState<Organization | null>(null)
  const [complaint, setComplaint] = useState<Complaint | null>(null)
  const [events, setEvents] = useState<ComplaintEvent[]>([])
  const [comments, setComments] = useState<ComplaintComment[]>([])
  const [attachments, setAttachments] = useState<ComplaintAttachment[]>([])
  const [members, setMembers] = useState<Member[]>([])
  const [departments, setDepartments] = useState<Department[]>([])

  const [error, setError] = useState<string | null>(null)
  const [message, setMessage] = useState<string | null>(null)
  const [busy, setBusy] = useState(false)

  const [assigneeUserId, setAssigneeUserId] = useState('')
  const [departmentId, setDepartmentId] = useState('')
  const [resolutionNote, setResolutionNote] = useState('')
  const [rejectNote, setRejectNote] = useState('')
  const [reporterNote, setReporterNote] = useState('')
  const [adminCloseNote, setAdminCloseNote] = useState('')
  const [commentBody, setCommentBody] = useState('')
  const [commentVisibility, setCommentVisibility] = useState<CommentVisibility>('PUBLIC')
  const [uploadFile, setUploadFile] = useState<File | null>(null)

  const isReporter = Boolean(user && complaint && user.id === complaint.reporterId)
  const myRole = org?.myRole
  const isStaff = Boolean(myRole && STAFF_ROLES.includes(myRole))
  const isAdmin = myRole === 'HEAD' || myRole === 'CO_ADMIN'

  const reload = useCallback(async () => {
    const [o, c, e, commentsRes, a, m, d] = await Promise.all([
      getOrganization(organizationId),
      getComplaint(organizationId, complaintId),
      listComplaintEvents(organizationId, complaintId),
      listComplaintComments(organizationId, complaintId),
      listComplaintAttachments(organizationId, complaintId),
      listMembers(organizationId),
      listDepartments(organizationId),
    ])
    setOrg(o.data)
    setComplaint(c.data)
    setEvents(e.data)
    setComments(commentsRes.data)
    setAttachments(a.data)
    setMembers(m.data)
    setDepartments(d.data)
    if (c.data.assigneeId) setAssigneeUserId(c.data.assigneeId)
    if (c.data.departmentId) setDepartmentId(c.data.departmentId)
  }, [organizationId, complaintId])

  useEffect(() => {
    void reload().catch((err) => setError(apiError(err, 'Failed to load complaint')))
  }, [reload])

  async function runAction(label: string, action: () => Promise<unknown>) {
    setBusy(true)
    setError(null)
    setMessage(null)
    try {
      await action()
      setMessage(label)
      await reload()
    } catch (err) {
      setError(apiError(err, 'Action failed'))
    } finally {
      setBusy(false)
    }
  }

  const status = complaint?.workflowStatus
  const canAcknowledge = isStaff && (status === 'SUBMITTED' || status === 'REOPENED')
  const canAssign = isStaff && status != null && !['CLOSED', 'REJECTED'].includes(status)
  const canStart = isStaff && (status === 'ASSIGNED' || status === 'ACKNOWLEDGED')
  const canResolve = isStaff && (status === 'IN_PROGRESS' || status === 'ASSIGNED' || status === 'ACKNOWLEDGED')
  const canReject = isStaff && status != null && !['CLOSED', 'REJECTED', 'RESOLVED'].includes(status)
  const canReporterAck = isReporter && status === 'RESOLVED'
  const canAdminClose = isAdmin && status != null && status !== 'CLOSED'

  const staffMembers = useMemo(
    () => members.filter((m) => STAFF_ROLES.includes(m.memberRole) || m.memberRole === 'MEMBER'),
    [members],
  )

  if (!complaint || !org) {
    return (
      <AppShell title="Complaint">
        <p className="text-[var(--fn-mute)]">{error ?? 'Loading…'}</p>
      </AppShell>
    )
  }

  return (
    <AppShell
      title={complaint.title}
      subtitle={`${org.name} · ${complaint.category} · ${complaint.workflowStatus}`}
    >
      <Link
        to={`/organizations/${organizationId}`}
        className="mb-4 inline-block text-sm font-semibold text-[var(--fn-acc)]"
      >
        ← Back to organization
      </Link>
      {error && <p className="mb-3 text-sm text-[var(--fn-danger)]">{error}</p>}
      {message && <p className="mb-3 text-sm text-[var(--fn-ok)]">{message}</p>}

      <section className="fn-card fn-enter mb-5 p-6">
        <div className="flex flex-wrap items-center gap-2">
          <span className="fn-badge">{complaint.workflowStatus}</span>
          <span className="fn-badge">{complaint.priority}</span>
          <span className="fn-badge">{complaint.identityMode ?? 'NAMED'}</span>
          {complaint.overdue && <span className="fn-badge fn-badge-danger">Overdue</span>}
          <span className="fn-badge">{complaint.supportCount ?? 0} supports</span>
        </div>
        <p className="mt-3 text-sm text-[var(--fn-mute)]">
          Reported by {complaint.reporterName}
          {complaint.locationText ? ` · ${complaint.locationText}` : ''}
        </p>
        <p className="mt-3 whitespace-pre-wrap">{complaint.description}</p>

        <dl className="mt-4 grid gap-3 text-sm md:grid-cols-2">
          <Meta label="Assignee" value={complaint.assigneeName ?? 'Unassigned'} />
          <Meta label="Reopens" value={String(complaint.reopenCount ?? 0)} />
          <Meta label="Acknowledged" value={formatWhen(complaint.acknowledgedAt)} />
          <Meta label="Resolved" value={formatWhen(complaint.resolvedAt)} />
          <Meta label="Closed" value={formatWhen(complaint.closedAt)} />
          <Meta label="Ack deadline" value={formatWhen(complaint.acknowledgementDeadline)} />
          <Meta label="Resolve deadline" value={formatWhen(complaint.resolutionDeadline)} />
          {complaint.resolutionNote && (
            <div className="md:col-span-2">
              <Meta label="Resolution note" value={complaint.resolutionNote} />
            </div>
          )}
          {complaint.latitude != null && complaint.longitude != null && (
            <div className="md:col-span-2">
              <a
                className="text-sm font-semibold text-[var(--fn-acc)]"
                href={openStreetMapUrl(complaint.latitude, complaint.longitude)}
                target="_blank"
                rel="noreferrer"
              >
                Map pin ({complaint.latitude.toFixed(5)}, {complaint.longitude.toFixed(5)}) ↗
              </a>
            </div>
          )}
        </dl>

        <div className="mt-4">
          <button
            type="button"
            className="fn-btn fn-btn-ghost text-sm"
            disabled={busy}
            onClick={() =>
              void runAction('Support updated', () =>
                toggleComplaintSupport(organizationId, complaintId).then((r) => {
                  setComplaint(r.data)
                }),
              )
            }
          >
            Support this ({complaint.supportCount ?? 0})
          </button>
        </div>
      </section>

      <section className="fn-card fn-enter fn-enter-delay-1 mb-5 p-6">
        <h2 className="fn-display text-lg font-semibold">Actions</h2>
        <div className="mt-4 flex flex-wrap gap-2">
          {canAcknowledge && (
            <button
              type="button"
              className="fn-btn fn-btn-primary text-sm"
              disabled={busy}
              onClick={() =>
                void runAction('Acknowledged', () => acknowledgeComplaint(organizationId, complaintId))
              }
            >
              Acknowledge
            </button>
          )}
          {canStart && (
            <button
              type="button"
              className="fn-btn fn-btn-primary text-sm"
              disabled={busy}
              onClick={() => void runAction('Started', () => startComplaint(organizationId, complaintId))}
            >
              Start work
            </button>
          )}
        </div>

        {canAssign && (
          <form
            className="mt-4 grid gap-3 md:grid-cols-3"
            onSubmit={(e) => {
              e.preventDefault()
              void runAction('Assigned', () =>
                assignComplaint(organizationId, complaintId, {
                  assigneeUserId,
                  departmentId: departmentId || undefined,
                }),
              )
            }}
          >
            <select
              className="fn-input"
              value={assigneeUserId}
              onChange={(e) => setAssigneeUserId(e.target.value)}
              required
            >
              <option value="">Assign to…</option>
              {staffMembers.map((m) => (
                <option key={m.userId} value={m.userId}>
                  {m.fullName} ({m.memberRole})
                </option>
              ))}
            </select>
            <select className="fn-input" value={departmentId} onChange={(e) => setDepartmentId(e.target.value)}>
              <option value="">Department (optional)</option>
              {departments.map((d) => (
                <option key={d.id} value={d.id}>
                  {d.name}
                </option>
              ))}
            </select>
            <button type="submit" className="fn-btn fn-btn-primary" disabled={busy}>
              Assign
            </button>
          </form>
        )}

        {canResolve && (
          <form
            className="mt-4 flex flex-col gap-2 md:flex-row"
            onSubmit={(e) => {
              e.preventDefault()
              void runAction('Resolved', () =>
                resolveComplaint(organizationId, complaintId, { resolutionNote }).then(() =>
                  setResolutionNote(''),
                ),
              )
            }}
          >
            <input
              className="fn-input"
              placeholder="Resolution note"
              value={resolutionNote}
              onChange={(e) => setResolutionNote(e.target.value)}
              required
            />
            <button type="submit" className="fn-btn fn-btn-primary shrink-0" disabled={busy}>
              Resolve
            </button>
          </form>
        )}

        {canReject && (
          <form
            className="mt-4 flex flex-col gap-2 md:flex-row"
            onSubmit={(e) => {
              e.preventDefault()
              void runAction('Rejected', () =>
                rejectComplaint(organizationId, complaintId, { note: rejectNote }).then(() =>
                  setRejectNote(''),
                ),
              )
            }}
          >
            <input
              className="fn-input"
              placeholder="Rejection note"
              value={rejectNote}
              onChange={(e) => setRejectNote(e.target.value)}
              required
            />
            <button type="submit" className="fn-btn fn-btn-ghost shrink-0" disabled={busy}>
              Reject
            </button>
          </form>
        )}

        {canReporterAck && (
          <div className="mt-4 space-y-2">
            <input
              className="fn-input"
              placeholder="Optional note"
              value={reporterNote}
              onChange={(e) => setReporterNote(e.target.value)}
            />
            <div className="flex flex-wrap gap-2">
              <button
                type="button"
                className="fn-btn fn-btn-primary text-sm"
                disabled={busy}
                onClick={() =>
                  void runAction('Accepted & closed', () =>
                    reporterAckComplaint(organizationId, complaintId, {
                      accept: true,
                      note: reporterNote || undefined,
                    }).then(() => setReporterNote('')),
                  )
                }
              >
                Accept resolution
              </button>
              <button
                type="button"
                className="fn-btn fn-btn-ghost text-sm"
                disabled={busy}
                onClick={() =>
                  void runAction('Reopened', () =>
                    reporterAckComplaint(organizationId, complaintId, {
                      accept: false,
                      note: reporterNote || undefined,
                    }).then(() => setReporterNote('')),
                  )
                }
              >
                Reject & reopen
              </button>
            </div>
          </div>
        )}

        {canAdminClose && (
          <form
            className="mt-4 flex flex-col gap-2 md:flex-row"
            onSubmit={(e) => {
              e.preventDefault()
              void runAction('Closed by admin', () =>
                adminCloseComplaint(organizationId, complaintId, {
                  note: adminCloseNote || undefined,
                }).then(() => setAdminCloseNote('')),
              )
            }}
          >
            <input
              className="fn-input"
              placeholder="Admin close note (optional)"
              value={adminCloseNote}
              onChange={(e) => setAdminCloseNote(e.target.value)}
            />
            <button type="submit" className="fn-btn fn-btn-ghost shrink-0" disabled={busy}>
              Admin close
            </button>
          </form>
        )}

        {!canAcknowledge &&
          !canAssign &&
          !canStart &&
          !canResolve &&
          !canReject &&
          !canReporterAck &&
          !canAdminClose && (
            <p className="mt-3 text-sm text-[var(--fn-mute)]">No workflow actions available for your role/status.</p>
          )}
      </section>

      <div className="grid gap-5 lg:grid-cols-2">
        <section className="fn-card fn-enter fn-enter-delay-2 p-6">
          <h2 className="fn-display text-lg font-semibold">Timeline</h2>
          <ul className="mt-4 space-y-3">
            {events.map((ev) => (
              <li key={ev.id} className="rounded-xl border border-[var(--fn-line)] bg-[var(--fn-bg)] p-3 text-sm">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="fn-badge">{ev.eventType}</span>
                  <span className="text-[var(--fn-mute)]">{formatWhen(ev.createdAt)}</span>
                </div>
                <p className="mt-1">
                  {ev.actorName ?? 'System'}
                  {ev.note ? ` — ${ev.note}` : ''}
                </p>
              </li>
            ))}
            {events.length === 0 && <p className="text-sm text-[var(--fn-mute)]">No events yet.</p>}
          </ul>
        </section>

        <section className="fn-card fn-enter fn-enter-delay-2 p-6">
          <h2 className="fn-display text-lg font-semibold">Comments</h2>
          <ul className="mt-4 space-y-3">
            {comments.map((c) => (
              <li key={c.id} className="rounded-xl border border-[var(--fn-line)] bg-[var(--fn-bg)] p-3 text-sm">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="font-semibold">{c.authorName}</span>
                  <span className="fn-badge">{c.visibility}</span>
                  <span className="text-[var(--fn-mute)]">{formatWhen(c.createdAt)}</span>
                </div>
                <p className="mt-1 whitespace-pre-wrap">{c.body}</p>
              </li>
            ))}
            {comments.length === 0 && <p className="text-sm text-[var(--fn-mute)]">No comments yet.</p>}
          </ul>
          <form
            className="mt-4 space-y-2"
            onSubmit={(e: FormEvent) => {
              e.preventDefault()
              void runAction('Comment added', () =>
                addComplaintComment(organizationId, complaintId, {
                  body: commentBody,
                  visibility: commentVisibility,
                }).then(() => setCommentBody('')),
              )
            }}
          >
            <textarea
              className="fn-input min-h-20"
              placeholder="Add a comment"
              value={commentBody}
              onChange={(e) => setCommentBody(e.target.value)}
              required
            />
            <div className="flex flex-wrap gap-2">
              <select
                className="fn-input max-w-xs"
                value={commentVisibility}
                onChange={(e) => setCommentVisibility(e.target.value as CommentVisibility)}
              >
                <option value="PUBLIC">PUBLIC</option>
                {isStaff && <option value="INTERNAL">INTERNAL</option>}
                <option value="REPORTER_THREAD">REPORTER_THREAD</option>
              </select>
              <button type="submit" className="fn-btn fn-btn-primary" disabled={busy}>
                Post
              </button>
            </div>
          </form>
        </section>
      </div>

      <section className="fn-card fn-enter fn-enter-delay-3 mt-5 p-6">
        <h2 className="fn-display text-lg font-semibold">Attachments</h2>
        <ul className="mt-3 space-y-2">
          {attachments.map((a) => (
            <li
              key={a.id}
              className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-[var(--fn-line)] bg-[var(--fn-bg)] px-3 py-2 text-sm"
            >
              <span>
                {a.originalName}
                {a.uploaderName ? ` · ${a.uploaderName}` : ''}
              </span>
              <button
                type="button"
                className="fn-btn fn-btn-ghost text-sm"
                disabled={busy}
                onClick={() =>
                  void (async () => {
                    try {
                      const blob = await downloadComplaintAttachment(organizationId, complaintId, a.id)
                      const url = URL.createObjectURL(blob)
                      const link = document.createElement('a')
                      link.href = url
                      link.download = a.originalName
                      link.click()
                      URL.revokeObjectURL(url)
                    } catch (err) {
                      setError(apiError(err, 'Download failed'))
                    }
                  })()
                }
              >
                Download
              </button>
            </li>
          ))}
          {attachments.length === 0 && (
            <p className="text-sm text-[var(--fn-mute)]">No attachments uploaded.</p>
          )}
        </ul>
        <form
          className="mt-4 flex flex-col gap-2 md:flex-row md:items-center"
          onSubmit={(e) => {
            e.preventDefault()
            if (!uploadFile) return
            void runAction('Attachment uploaded', () =>
              uploadComplaintAttachment(organizationId, complaintId, uploadFile).then(() =>
                setUploadFile(null),
              ),
            )
          }}
        >
          <input
            type="file"
            className="fn-input"
            onChange={(e) => setUploadFile(e.target.files?.[0] ?? null)}
          />
          <button type="submit" className="fn-btn fn-btn-primary shrink-0" disabled={busy || !uploadFile}>
            Upload
          </button>
        </form>
      </section>
    </AppShell>
  )
}

function Meta({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <dt className="text-xs font-semibold uppercase tracking-wide text-[var(--fn-mute)]">{label}</dt>
      <dd className="mt-0.5">{value}</dd>
    </div>
  )
}
