import { axiosInstance } from './axiosInstance'

export interface ApiMeta {
  requestId: string
  timestamp: string
}

export interface ApiResponse<T> {
  success: boolean
  data: T
  error: { code: string; message: string } | null
  meta: ApiMeta
}

export interface HealthPayload {
  status: string
  service: string
  phase: string
}

export async function getBackendHealth(): Promise<ApiResponse<HealthPayload>> {
  const { data } = await axiosInstance.get<ApiResponse<HealthPayload>>('/health')
  return data
}
