import { axiosInstance } from './axiosInstance'
import type { ApiResponse } from '../../types/auth'

export type CommitmentStatus = 'OPEN' | 'COMPLETED' | 'CANCELLED'

export interface Commitment {
  id: string
  organizationId: string
  title: string
  description: string | null
  ownerId: string | null
  ownerName: string | null
  dueAt: string | null
  status: CommitmentStatus
  completedAt: string | null
  completionNote: string | null
  createdAt: string
  updatedAt: string
}

export interface CreateCommitmentPayload {
  title: string
  description?: string
  ownerId?: string
  dueAt?: string
}

export async function listCommitments(organizationId: string) {
  const { data } = await axiosInstance.get<ApiResponse<Commitment[]>>(
    `/organizations/${organizationId}/commitments`,
  )
  return data
}

export async function createCommitment(organizationId: string, payload: CreateCommitmentPayload) {
  const { data } = await axiosInstance.post<ApiResponse<Commitment>>(
    `/organizations/${organizationId}/commitments`,
    payload,
  )
  return data
}

export async function completeCommitment(
  organizationId: string,
  commitmentId: string,
  payload?: { note?: string },
) {
  const { data } = await axiosInstance.post<ApiResponse<Commitment>>(
    `/organizations/${organizationId}/commitments/${commitmentId}/complete`,
    payload ?? {},
  )
  return data
}
