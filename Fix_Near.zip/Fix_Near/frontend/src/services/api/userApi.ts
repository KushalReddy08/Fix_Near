import { axiosInstance } from './axiosInstance'
import type { ApiResponse, User } from '../../types/auth'

export async function getMe(): Promise<ApiResponse<User>> {
  const { data } = await axiosInstance.get<ApiResponse<User>>('/users/me')
  return data
}

export async function updateMe(fullName: string): Promise<ApiResponse<User>> {
  const { data } = await axiosInstance.put<ApiResponse<User>>('/users/me', { fullName })
  return data
}

export async function changePassword(payload: {
  currentPassword: string
  newPassword: string
}): Promise<ApiResponse<{ message: string }>> {
  const { data } = await axiosInstance.put<ApiResponse<{ message: string }>>(
    '/users/me/password',
    payload,
  )
  return data
}
