import { axiosInstance } from './axiosInstance'
import type { ApiResponse } from '../../types/auth'

export type OrganizationType = 'COLLEGE' | 'CORPORATE' | 'RESIDENTIAL' | 'CIVIC'
export type MemberRole =
  | 'HEAD'
  | 'CO_ADMIN'
  | 'DEPARTMENT_MANAGER'
  | 'OFFICIAL'
  | 'INVESTIGATOR'
  | 'COMMUNITY_MODERATOR'
  | 'MEMBER'

export interface Organization {
  id: string
  name: string
  organizationType: OrganizationType
  description: string | null
  timezone: string
  country: string | null
  stateProvince: string | null
  city: string | null
  addressLine: string | null
  status: 'ACTIVE' | 'SUSPENDED'
  myRole: MemberRole
  createdAt: string
  updatedAt: string
}

export interface OrgRequest {
  id: string
  requesterId: string
  requesterEmail: string
  name: string
  organizationType: OrganizationType
  description: string | null
  timezone: string
  country: string | null
  stateProvince: string | null
  city: string | null
  addressLine: string | null
  status: 'PENDING' | 'APPROVED' | 'REJECTED'
  reviewNote: string | null
  createdAt: string
  reviewedAt: string | null
}

export interface Member {
  membershipId: string
  userId: string
  email: string
  fullName: string
  memberRole: MemberRole
  departmentId: string | null
  joinedAt: string
}

export interface Department {
  id: string
  name: string
  description: string | null
  managerMemberId: string | null
  createdAt: string
}

export interface InvitationCreated {
  invitationId: string
  invitationCode: string
  memberRole: MemberRole
  invitedEmail: string | null
  expiresAt: string
}

export async function submitOrgRequest(payload: {
  name: string
  organizationType: OrganizationType
  description?: string
  timezone: string
  country: string
  stateProvince: string
  city: string
  addressLine: string
}) {
  const { data } = await axiosInstance.post<ApiResponse<OrgRequest>>('/organizations/requests', payload)
  return data
}

export async function myOrgRequests() {
  const { data } = await axiosInstance.get<ApiResponse<OrgRequest[]>>('/organizations/requests/mine')
  return data
}

export async function myOrganizations() {
  const { data } = await axiosInstance.get<ApiResponse<Organization[]>>('/organizations')
  return data
}

export async function getOrganization(id: string) {
  const { data } = await axiosInstance.get<ApiResponse<Organization>>(`/organizations/${id}`)
  return data
}

export async function listMembers(orgId: string) {
  const { data } = await axiosInstance.get<ApiResponse<Member[]>>(`/organizations/${orgId}/members`)
  return data
}

export async function listDepartments(orgId: string) {
  const { data } = await axiosInstance.get<ApiResponse<Department[]>>(`/organizations/${orgId}/departments`)
  return data
}

export async function createDepartment(orgId: string, payload: { name: string; description?: string }) {
  const { data } = await axiosInstance.post<ApiResponse<Department>>(
    `/organizations/${orgId}/departments`,
    payload,
  )
  return data
}

export async function createInvitation(
  orgId: string,
  payload: { invitedEmail?: string; memberRole: MemberRole },
) {
  const { data } = await axiosInstance.post<ApiResponse<InvitationCreated>>(
    `/organizations/${orgId}/invitations`,
    payload,
  )
  return data
}

export async function joinOrganization(invitationCode: string) {
  const { data } = await axiosInstance.post<ApiResponse<Organization>>('/organizations/join', {
    invitationCode,
  })
  return data
}

export async function pendingOrgRequests() {
  const { data } = await axiosInstance.get<ApiResponse<OrgRequest[]>>('/platform/organization-requests')
  return data
}

export async function approveOrgRequest(requestId: string, reviewNote?: string) {
  const { data } = await axiosInstance.post<ApiResponse<Organization>>(
    `/platform/organization-requests/${requestId}/approve`,
    { reviewNote },
  )
  return data
}

export async function rejectOrgRequest(requestId: string, reviewNote?: string) {
  const { data } = await axiosInstance.post<ApiResponse<OrgRequest>>(
    `/platform/organization-requests/${requestId}/reject`,
    { reviewNote },
  )
  return data
}
