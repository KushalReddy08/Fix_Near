import { axiosInstance } from './axiosInstance'
import type { ApiResponse, AuthTokens } from '../../types/auth'

export interface RegisterResult {
  message: string
  verificationToken?: string | null
  verificationUrl?: string | null
}

export async function register(payload: {
  email: string
  password: string
  fullName: string
}): Promise<ApiResponse<RegisterResult>> {
  const { data } = await axiosInstance.post<ApiResponse<RegisterResult>>('/auth/register', payload)
  return data
}

export async function resendVerification(email: string): Promise<ApiResponse<RegisterResult>> {
  const { data } = await axiosInstance.post<ApiResponse<RegisterResult>>('/auth/resend-verification', {
    email,
  })
  return data
}

export async function verifyEmail(token: string): Promise<ApiResponse<{ message: string }>> {
  const { data } = await axiosInstance.post<ApiResponse<{ message: string }>>('/auth/verify-email', {
    token,
  })
  return data
}

export async function login(payload: {
  email: string
  password: string
}): Promise<ApiResponse<AuthTokens>> {
  const { data } = await axiosInstance.post<ApiResponse<AuthTokens>>('/auth/login', payload)
  return data
}

export async function refreshSession(): Promise<ApiResponse<AuthTokens>> {
  const { data } = await axiosInstance.post<ApiResponse<AuthTokens>>('/auth/refresh')
  return data
}

export async function logout(): Promise<ApiResponse<{ message: string }>> {
  const { data } = await axiosInstance.post<ApiResponse<{ message: string }>>('/auth/logout')
  return data
}
