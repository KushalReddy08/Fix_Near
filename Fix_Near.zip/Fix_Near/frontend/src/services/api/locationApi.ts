import { axiosInstance } from './axiosInstance'
import type { ApiResponse } from '../../types/auth'

interface LocationNameResponse {
  items: string[]
}

const locationRequestConfig = { timeout: 45_000 }

export async function listCountries() {
  const { data } = await axiosInstance.get<ApiResponse<LocationNameResponse>>(
    '/locations/countries',
    locationRequestConfig,
  )
  return data.data.items
}

export async function listStates(country: string) {
  const { data } = await axiosInstance.get<ApiResponse<LocationNameResponse>>('/locations/states', {
    ...locationRequestConfig,
    params: { country },
  })
  return data.data.items
}

export async function listCities(country: string, state: string) {
  const { data } = await axiosInstance.get<ApiResponse<LocationNameResponse>>('/locations/cities', {
    ...locationRequestConfig,
    params: { country, state },
  })
  return data.data.items
}
