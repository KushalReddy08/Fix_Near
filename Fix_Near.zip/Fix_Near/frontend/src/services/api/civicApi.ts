import { axiosInstance } from './axiosInstance'
import type { ApiResponse } from '../../types/auth'
import type { Complaint } from './complaintApi'

export interface CivicMapComplaint extends Complaint {
  organizationName?: string
}

export async function listCivicMapComplaints(bbox?: string) {
  const { data } = await axiosInstance.get<ApiResponse<CivicMapComplaint[]>>('/civic/map/complaints', {
    params: bbox ? { bbox } : undefined,
  })
  return data
}

export function openStreetMapUrl(latitude: number, longitude: number) {
  return `https://www.openstreetmap.org/?mlat=${latitude}&mlon=${longitude}#map=16/${latitude}/${longitude}`
}
