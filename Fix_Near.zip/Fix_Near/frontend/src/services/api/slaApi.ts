import { axiosInstance } from './axiosInstance'
import type { ApiResponse } from '../../types/auth'
import type { Complaint, ComplaintPriority } from './complaintApi'

export interface SlaPolicy {
  category: string
  priority: ComplaintPriority
  acknowledgeHours: number
  resolveHours: number
}

export interface OrgDashboard {
  openCount: number
  overdueCount: number
  byStatus: Record<string, number>
  supportHot: Complaint[]
}

export async function listSlaPolicies(organizationId: string) {
  const { data } = await axiosInstance.get<ApiResponse<SlaPolicy[]>>(
    `/organizations/${organizationId}/sla-policies`,
  )
  return data
}

export async function upsertSlaPolicies(organizationId: string, policies: SlaPolicy[]) {
  const { data } = await axiosInstance.put<ApiResponse<SlaPolicy[]>>(
    `/organizations/${organizationId}/sla-policies`,
    policies,
  )
  return data
}

export async function getOrgDashboard(organizationId: string) {
  const { data } = await axiosInstance.get<ApiResponse<OrgDashboard>>(
    `/organizations/${organizationId}/dashboard`,
  )
  return data
}
