import { axiosInstance } from './axiosInstance'
import type { ApiResponse } from '../../types/auth'

export type ComplaintStatus =
  | 'SUBMITTED'
  | 'ACKNOWLEDGED'
  | 'ASSIGNED'
  | 'IN_PROGRESS'
  | 'RESOLVED'
  | 'REJECTED'
  | 'CLOSED'
  | 'REOPENED'

export type ComplaintPriority = 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL'

export type IdentityMode = 'NAMED' | 'CONFIDENTIAL' | 'ANONYMOUS'

export type CommentVisibility = 'PUBLIC' | 'INTERNAL' | 'REPORTER_THREAD'

export interface Complaint {
  id: string
  organizationId: string
  reporterId: string | null
  reporterName: string
  title: string
  description: string
  category: string
  priority: ComplaintPriority
  workflowStatus: ComplaintStatus
  overdue: boolean
  locationText: string | null
  identityMode: IdentityMode
  latitude: number | null
  longitude: number | null
  assigneeId: string | null
  assigneeName: string | null
  departmentId: string | null
  acknowledgedAt: string | null
  resolvedAt: string | null
  closedAt: string | null
  resolutionNote: string | null
  reopenCount: number
  supportCount: number
  acknowledgementDeadline: string | null
  resolutionDeadline: string | null
  createdAt: string
  updatedAt: string
}

export interface ComplaintEvent {
  id: string
  eventType: string
  fromStatus: ComplaintStatus | null
  toStatus: ComplaintStatus | null
  actorId: string | null
  actorName: string | null
  note: string | null
  createdAt: string
}

export interface ComplaintComment {
  id: string
  authorId: string
  authorName: string
  body: string
  visibility: CommentVisibility
  createdAt: string
}

export interface ComplaintAttachment {
  id: string
  originalName: string
  contentType: string
  sizeBytes: number
  purpose: 'EVIDENCE' | 'RESOLUTION' | 'COMMENT'
  uploaderId: string
  uploaderName: string
  createdAt: string
}

export interface CreateComplaintPayload {
  title: string
  description: string
  category: string
  locationText?: string
  latitude?: number
  longitude?: number
  identityMode?: IdentityMode
  priority?: ComplaintPriority
}

function complaintBase(orgId: string, complaintId?: string) {
  const base = `/organizations/${orgId}/complaints`
  return complaintId ? `${base}/${complaintId}` : base
}

export async function listComplaints(organizationId: string) {
  const { data } = await axiosInstance.get<ApiResponse<Complaint[]>>(complaintBase(organizationId))
  return data
}

export async function getComplaint(organizationId: string, complaintId: string) {
  const { data } = await axiosInstance.get<ApiResponse<Complaint>>(
    complaintBase(organizationId, complaintId),
  )
  return data
}

export async function createComplaint(organizationId: string, payload: CreateComplaintPayload) {
  const { data } = await axiosInstance.post<ApiResponse<Complaint>>(
    complaintBase(organizationId),
    payload,
  )
  return data
}

export async function acknowledgeComplaint(organizationId: string, complaintId: string) {
  const { data } = await axiosInstance.post<ApiResponse<Complaint>>(
    `${complaintBase(organizationId, complaintId)}/acknowledge`,
  )
  return data
}

export async function assignComplaint(
  organizationId: string,
  complaintId: string,
  payload: { assigneeUserId: string; departmentId?: string },
) {
  const { data } = await axiosInstance.post<ApiResponse<Complaint>>(
    `${complaintBase(organizationId, complaintId)}/assign`,
    payload,
  )
  return data
}

export async function startComplaint(organizationId: string, complaintId: string) {
  const { data } = await axiosInstance.post<ApiResponse<Complaint>>(
    `${complaintBase(organizationId, complaintId)}/start`,
  )
  return data
}

export async function resolveComplaint(
  organizationId: string,
  complaintId: string,
  payload: { resolutionNote: string },
) {
  const { data } = await axiosInstance.post<ApiResponse<Complaint>>(
    `${complaintBase(organizationId, complaintId)}/resolve`,
    payload,
  )
  return data
}

export async function rejectComplaint(
  organizationId: string,
  complaintId: string,
  payload: { note: string },
) {
  const { data } = await axiosInstance.post<ApiResponse<Complaint>>(
    `${complaintBase(organizationId, complaintId)}/reject`,
    payload,
  )
  return data
}

export async function reporterAckComplaint(
  organizationId: string,
  complaintId: string,
  payload: { accept: boolean; note?: string },
) {
  const { data } = await axiosInstance.post<ApiResponse<Complaint>>(
    `${complaintBase(organizationId, complaintId)}/reporter-ack`,
    payload,
  )
  return data
}

export async function adminCloseComplaint(
  organizationId: string,
  complaintId: string,
  payload?: { note?: string },
) {
  const { data } = await axiosInstance.post<ApiResponse<Complaint>>(
    `${complaintBase(organizationId, complaintId)}/admin-close`,
    payload ?? {},
  )
  return data
}

export async function listComplaintEvents(organizationId: string, complaintId: string) {
  const { data } = await axiosInstance.get<ApiResponse<ComplaintEvent[]>>(
    `${complaintBase(organizationId, complaintId)}/events`,
  )
  return data
}

export async function listComplaintComments(organizationId: string, complaintId: string) {
  const { data } = await axiosInstance.get<ApiResponse<ComplaintComment[]>>(
    `${complaintBase(organizationId, complaintId)}/comments`,
  )
  return data
}

export async function addComplaintComment(
  organizationId: string,
  complaintId: string,
  payload: { body: string; visibility: CommentVisibility },
) {
  const { data } = await axiosInstance.post<ApiResponse<ComplaintComment>>(
    `${complaintBase(organizationId, complaintId)}/comments`,
    payload,
  )
  return data
}

export async function toggleComplaintSupport(organizationId: string, complaintId: string) {
  const { data } = await axiosInstance.post<ApiResponse<Complaint>>(
    `${complaintBase(organizationId, complaintId)}/support`,
  )
  return data
}

export async function listComplaintAttachments(organizationId: string, complaintId: string) {
  const { data } = await axiosInstance.get<ApiResponse<ComplaintAttachment[]>>(
    `${complaintBase(organizationId, complaintId)}/attachments`,
  )
  return data
}

export async function uploadComplaintAttachment(
  organizationId: string,
  complaintId: string,
  file: File,
) {
  const form = new FormData()
  form.append('file', file)
  const { data } = await axiosInstance.post<ApiResponse<ComplaintAttachment>>(
    `${complaintBase(organizationId, complaintId)}/attachments`,
    form,
    { headers: { 'Content-Type': 'multipart/form-data' } },
  )
  return data
}

export function complaintAttachmentDownloadUrl(
  organizationId: string,
  complaintId: string,
  attachmentId: string,
) {
  return `${complaintBase(organizationId, complaintId)}/attachments/${attachmentId}/download`
}

export async function downloadComplaintAttachment(
  organizationId: string,
  complaintId: string,
  attachmentId: string,
) {
  const { data } = await axiosInstance.get<Blob>(
    complaintAttachmentDownloadUrl(organizationId, complaintId, attachmentId),
    { responseType: 'blob' },
  )
  return data
}
