import { axiosInstance } from './axiosInstance'
import type { ApiResponse } from '../../types/auth'

export interface Notification {
  id: string
  title: string
  body: string
  type: string
  organizationId: string | null
  complaintId: string | null
  readAt: string | null
  createdAt: string
}

export async function listNotifications() {
  const { data } = await axiosInstance.get<ApiResponse<Notification[]>>('/notifications')
  return data
}

export async function markNotificationRead(notificationId: string) {
  const { data } = await axiosInstance.post<ApiResponse<Notification>>(
    `/notifications/${notificationId}/read`,
  )
  return data
}
