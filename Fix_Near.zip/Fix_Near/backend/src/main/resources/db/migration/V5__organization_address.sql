ALTER TABLE organization_creation_requests
    ADD COLUMN country VARCHAR(100),
    ADD COLUMN state_province VARCHAR(100),
    ADD COLUMN city VARCHAR(100),
    ADD COLUMN address_line VARCHAR(500);

ALTER TABLE organizations
    ADD COLUMN country VARCHAR(100),
    ADD COLUMN state_province VARCHAR(100),
    ADD COLUMN city VARCHAR(100),
    ADD COLUMN address_line VARCHAR(500);
