-- Accountability platform: workflow fields, events, comments, attachments,
-- supports, SLA policies, commitments, notifications.

ALTER TABLE complaints
    ADD COLUMN assignee_id UUID REFERENCES users (id),
    ADD COLUMN department_id UUID REFERENCES departments (id),
    ADD COLUMN identity_mode VARCHAR(32) NOT NULL DEFAULT 'NAMED',
    ADD COLUMN latitude DOUBLE PRECISION,
    ADD COLUMN longitude DOUBLE PRECISION,
    ADD COLUMN acknowledged_at TIMESTAMPTZ,
    ADD COLUMN resolved_at TIMESTAMPTZ,
    ADD COLUMN closed_at TIMESTAMPTZ,
    ADD COLUMN resolution_note TEXT,
    ADD COLUMN reopen_count INTEGER NOT NULL DEFAULT 0,
    ADD COLUMN support_count INTEGER NOT NULL DEFAULT 0,
    ADD COLUMN acknowledgement_deadline TIMESTAMPTZ;

ALTER TABLE complaints
    ADD CONSTRAINT ck_complaint_identity_mode CHECK (identity_mode IN ('NAMED', 'CONFIDENTIAL', 'ANONYMOUS'));

CREATE TABLE complaint_events (
    id              UUID PRIMARY KEY,
    complaint_id    UUID         NOT NULL REFERENCES complaints (id) ON DELETE CASCADE,
    organization_id UUID         NOT NULL REFERENCES organizations (id) ON DELETE CASCADE,
    actor_id        UUID REFERENCES users (id),
    event_type      VARCHAR(64)  NOT NULL,
    from_status     VARCHAR(32),
    to_status       VARCHAR(32),
    note            TEXT,
    created_at      TIMESTAMPTZ  NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_complaint_events_complaint ON complaint_events (complaint_id, created_at ASC);

CREATE TABLE complaint_comments (
    id              UUID PRIMARY KEY,
    complaint_id    UUID         NOT NULL REFERENCES complaints (id) ON DELETE CASCADE,
    organization_id UUID         NOT NULL REFERENCES organizations (id) ON DELETE CASCADE,
    author_id       UUID         NOT NULL REFERENCES users (id),
    body            TEXT         NOT NULL,
    visibility      VARCHAR(32)  NOT NULL,
    created_at      TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    CONSTRAINT ck_comment_visibility CHECK (visibility IN ('PUBLIC', 'INTERNAL', 'REPORTER_THREAD'))
);

CREATE INDEX idx_complaint_comments_complaint ON complaint_comments (complaint_id, created_at ASC);

CREATE TABLE complaint_attachments (
    id              UUID PRIMARY KEY,
    complaint_id    UUID         NOT NULL REFERENCES complaints (id) ON DELETE CASCADE,
    organization_id UUID         NOT NULL REFERENCES organizations (id) ON DELETE CASCADE,
    uploader_id     UUID         NOT NULL REFERENCES users (id),
    original_name   VARCHAR(255) NOT NULL,
    storage_key     VARCHAR(500) NOT NULL,
    content_type    VARCHAR(100) NOT NULL,
    size_bytes      BIGINT       NOT NULL,
    purpose         VARCHAR(32)  NOT NULL DEFAULT 'EVIDENCE',
    created_at      TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    CONSTRAINT ck_attachment_purpose CHECK (purpose IN ('EVIDENCE', 'RESOLUTION', 'COMMENT')),
    CONSTRAINT ck_attachment_size CHECK (size_bytes > 0 AND size_bytes <= 10485760)
);

CREATE INDEX idx_complaint_attachments_complaint ON complaint_attachments (complaint_id);

CREATE TABLE complaint_supports (
    id              UUID PRIMARY KEY,
    complaint_id    UUID         NOT NULL REFERENCES complaints (id) ON DELETE CASCADE,
    organization_id UUID         NOT NULL REFERENCES organizations (id) ON DELETE CASCADE,
    user_id         UUID         NOT NULL REFERENCES users (id),
    created_at      TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    CONSTRAINT uq_complaint_support UNIQUE (complaint_id, user_id)
);

CREATE TABLE sla_policies (
    id                  UUID PRIMARY KEY,
    organization_id     UUID         NOT NULL REFERENCES organizations (id) ON DELETE CASCADE,
    category            VARCHAR(100) NOT NULL,
    priority            VARCHAR(32)  NOT NULL,
    acknowledge_hours   INTEGER      NOT NULL,
    resolve_hours       INTEGER      NOT NULL,
    created_at          TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    CONSTRAINT ck_sla_priority CHECK (priority IN ('LOW', 'MEDIUM', 'HIGH', 'CRITICAL')),
    CONSTRAINT ck_sla_hours CHECK (acknowledge_hours > 0 AND resolve_hours > 0),
    CONSTRAINT uq_sla_org_cat_pri UNIQUE (organization_id, category, priority)
);

CREATE TABLE commitments (
    id              UUID PRIMARY KEY,
    organization_id UUID         NOT NULL REFERENCES organizations (id) ON DELETE CASCADE,
    complaint_id    UUID REFERENCES complaints (id) ON DELETE SET NULL,
    created_by_id   UUID         NOT NULL REFERENCES users (id),
    title           VARCHAR(200) NOT NULL,
    description     TEXT         NOT NULL,
    status          VARCHAR(32)  NOT NULL DEFAULT 'PROPOSED',
    due_at          TIMESTAMPTZ,
    is_overdue      BOOLEAN      NOT NULL DEFAULT FALSE,
    completed_at    TIMESTAMPTZ,
    created_at      TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    CONSTRAINT ck_commitment_status CHECK (status IN (
        'PROPOSED', 'ACCEPTED', 'IN_PROGRESS', 'COMPLETED', 'VERIFIED', 'CANCELLED'
    ))
);

CREATE INDEX idx_commitments_org ON commitments (organization_id, created_at DESC);

CREATE TABLE commitment_updates (
    id              UUID PRIMARY KEY,
    commitment_id   UUID         NOT NULL REFERENCES commitments (id) ON DELETE CASCADE,
    author_id       UUID         NOT NULL REFERENCES users (id),
    note            TEXT         NOT NULL,
    created_at      TIMESTAMPTZ  NOT NULL DEFAULT NOW()
);

CREATE TABLE notifications (
    id              UUID PRIMARY KEY,
    user_id         UUID         NOT NULL REFERENCES users (id) ON DELETE CASCADE,
    organization_id UUID REFERENCES organizations (id) ON DELETE CASCADE,
    complaint_id    UUID REFERENCES complaints (id) ON DELETE CASCADE,
    title           VARCHAR(200) NOT NULL,
    body            TEXT         NOT NULL,
    read_at         TIMESTAMPTZ,
    created_at      TIMESTAMPTZ  NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_notifications_user ON notifications (user_id, created_at DESC);
