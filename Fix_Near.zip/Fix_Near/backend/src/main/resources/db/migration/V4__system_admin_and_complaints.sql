-- Seed platform admin for local bootstrap.
-- Login alias: username "system" → system@fixnear.local
-- Change this account password immediately in any shared or production environment.

UPDATE users
SET email = 'system@fixnear.local',
    password_hash = '$2a$10$A/0HSgKyiUAEa0.T5HUda.e84PkhKx99N0UYMCfZCH.EgIhN9yA5G',
    full_name = 'System',
    platform_role = 'PLATFORM_ADMIN',
    account_status = 'ACTIVE',
    updated_at = NOW()
WHERE id = '11111111-1111-1111-1111-111111111111'
   OR email = 'platform.admin@fixnear.local';

INSERT INTO users (id, email, password_hash, full_name, platform_role, account_status, created_at, updated_at)
SELECT
    '11111111-1111-1111-1111-111111111111',
    'system@fixnear.local',
    '$2a$10$A/0HSgKyiUAEa0.T5HUda.e84PkhKx99N0UYMCfZCH.EgIhN9yA5G',
    'System',
    'PLATFORM_ADMIN',
    'ACTIVE',
    NOW(),
    NOW()
WHERE NOT EXISTS (
    SELECT 1 FROM users WHERE email = 'system@fixnear.local'
);

CREATE TABLE complaints (
    id                   UUID PRIMARY KEY,
    organization_id      UUID         NOT NULL REFERENCES organizations (id) ON DELETE CASCADE,
    reporter_id          UUID         NOT NULL REFERENCES users (id),
    title                VARCHAR(200) NOT NULL,
    description          TEXT         NOT NULL,
    category             VARCHAR(100) NOT NULL,
    priority             VARCHAR(32)  NOT NULL,
    workflow_status      VARCHAR(32)  NOT NULL,
    is_overdue           BOOLEAN      NOT NULL DEFAULT FALSE,
    location_text        VARCHAR(500),
    resolution_deadline  TIMESTAMPTZ,
    created_at           TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    updated_at           TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    CONSTRAINT ck_complaint_priority CHECK (priority IN ('LOW', 'MEDIUM', 'HIGH', 'CRITICAL')),
    CONSTRAINT ck_complaint_status CHECK (workflow_status IN (
        'SUBMITTED', 'ACKNOWLEDGED', 'ASSIGNED', 'IN_PROGRESS',
        'RESOLVED', 'REJECTED', 'CLOSED', 'REOPENED'
    ))
);

CREATE INDEX idx_complaints_org_created ON complaints (organization_id, created_at DESC);
CREATE INDEX idx_complaints_reporter ON complaints (reporter_id);
CREATE INDEX idx_complaints_status ON complaints (organization_id, workflow_status);
