-- FixNear Phase 1 baseline.
-- Full domain tables are introduced in later phases via Flyway.
-- This migration establishes schema ownership and a lightweight bootstrap marker.

CREATE TABLE IF NOT EXISTS schema_bootstrap (
    id SMALLINT PRIMARY KEY,
    project_name VARCHAR(64) NOT NULL,
    phase VARCHAR(32) NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT schema_bootstrap_singleton CHECK (id = 1)
);

INSERT INTO schema_bootstrap (id, project_name, phase)
VALUES (1, 'FixNear', 'phase-1-foundation')
ON CONFLICT (id) DO NOTHING;

COMMENT ON TABLE schema_bootstrap IS 'Phase 1 marker table; replaced by domain migrations in later phases.';
