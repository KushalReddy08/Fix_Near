CREATE TABLE organization_creation_requests (
    id               UUID PRIMARY KEY,
    requester_id     UUID         NOT NULL REFERENCES users (id),
    name             VARCHAR(200) NOT NULL,
    organization_type VARCHAR(32) NOT NULL,
    description      VARCHAR(1000),
    timezone         VARCHAR(64)  NOT NULL,
    status           VARCHAR(32)  NOT NULL,
    review_note      VARCHAR(1000),
    reviewed_by_id   UUID REFERENCES users (id),
    reviewed_at      TIMESTAMPTZ,
    created_at       TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    updated_at       TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    CONSTRAINT ck_org_req_type CHECK (organization_type IN ('COLLEGE', 'CORPORATE', 'RESIDENTIAL', 'CIVIC')),
    CONSTRAINT ck_org_req_status CHECK (status IN ('PENDING', 'APPROVED', 'REJECTED'))
);

CREATE INDEX idx_org_req_status ON organization_creation_requests (status);
CREATE INDEX idx_org_req_requester ON organization_creation_requests (requester_id);

CREATE TABLE organizations (
    id                UUID PRIMARY KEY,
    name              VARCHAR(200) NOT NULL,
    organization_type VARCHAR(32)  NOT NULL,
    description       VARCHAR(1000),
    timezone          VARCHAR(64)  NOT NULL,
    status            VARCHAR(32)  NOT NULL,
    created_by_request_id UUID REFERENCES organization_creation_requests (id),
    created_at        TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    updated_at        TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    CONSTRAINT ck_org_type CHECK (organization_type IN ('COLLEGE', 'CORPORATE', 'RESIDENTIAL', 'CIVIC')),
    CONSTRAINT ck_org_status CHECK (status IN ('ACTIVE', 'SUSPENDED'))
);

CREATE TABLE organization_members (
    id               UUID PRIMARY KEY,
    organization_id  UUID         NOT NULL REFERENCES organizations (id) ON DELETE CASCADE,
    user_id          UUID         NOT NULL REFERENCES users (id) ON DELETE CASCADE,
    member_role      VARCHAR(32)  NOT NULL,
    department_id    UUID,
    joined_at        TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    revoked_at       TIMESTAMPTZ,
    CONSTRAINT uq_org_member UNIQUE (organization_id, user_id),
    CONSTRAINT ck_member_role CHECK (member_role IN (
        'HEAD', 'CO_ADMIN', 'DEPARTMENT_MANAGER', 'OFFICIAL',
        'INVESTIGATOR', 'COMMUNITY_MODERATOR', 'MEMBER'
    ))
);

CREATE INDEX idx_org_members_user ON organization_members (user_id);
CREATE INDEX idx_org_members_org_active ON organization_members (organization_id) WHERE revoked_at IS NULL;

CREATE UNIQUE INDEX uq_org_single_head
    ON organization_members (organization_id)
    WHERE member_role = 'HEAD' AND revoked_at IS NULL;

CREATE TABLE departments (
    id               UUID PRIMARY KEY,
    organization_id  UUID         NOT NULL REFERENCES organizations (id) ON DELETE CASCADE,
    name             VARCHAR(150) NOT NULL,
    description      VARCHAR(500),
    manager_member_id UUID REFERENCES organization_members (id),
    created_at       TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    updated_at       TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    CONSTRAINT uq_department_name UNIQUE (organization_id, name)
);

ALTER TABLE organization_members
    ADD CONSTRAINT fk_org_member_department
    FOREIGN KEY (department_id) REFERENCES departments (id);

CREATE TABLE organization_invitations (
    id               UUID PRIMARY KEY,
    organization_id  UUID         NOT NULL REFERENCES organizations (id) ON DELETE CASCADE,
    code_hash        VARCHAR(64)  NOT NULL,
    invited_email    VARCHAR(320),
    member_role      VARCHAR(32)  NOT NULL,
    created_by_id    UUID         NOT NULL REFERENCES users (id),
    expires_at       TIMESTAMPTZ  NOT NULL,
    used_at          TIMESTAMPTZ,
    used_by_id       UUID REFERENCES users (id),
    created_at       TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    CONSTRAINT uq_org_invite_code UNIQUE (code_hash),
    CONSTRAINT ck_invite_role CHECK (member_role IN (
        'CO_ADMIN', 'DEPARTMENT_MANAGER', 'OFFICIAL',
        'INVESTIGATOR', 'COMMUNITY_MODERATOR', 'MEMBER'
    ))
);

CREATE INDEX idx_org_invites_org ON organization_invitations (organization_id);

-- Dev platform admin (password: Admin123!)
INSERT INTO users (id, email, password_hash, full_name, platform_role, account_status, created_at, updated_at)
VALUES (
    '11111111-1111-1111-1111-111111111111',
    'platform.admin@fixnear.local',
    '$2a$10$NWHBBsA4g5mx3G2kiqtZGOXCx8UkLDC6FzaWu6tt/UOFmSBfAsShS',
    'Platform Admin',
    'PLATFORM_ADMIN',
    'ACTIVE',
    NOW(),
    NOW()
)
ON CONFLICT (email) DO NOTHING;
