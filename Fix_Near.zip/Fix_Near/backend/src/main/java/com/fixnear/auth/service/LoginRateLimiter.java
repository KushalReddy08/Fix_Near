package com.fixnear.auth.service;

import java.time.Instant;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import com.fixnear.common.exception.ApiException;
import com.fixnear.config.AuthProperties;

@Component
public class LoginRateLimiter {

    private final AuthProperties authProperties;
    private final Map<String, AttemptWindow> attempts = new ConcurrentHashMap<>();

    public LoginRateLimiter(AuthProperties authProperties) {
        this.authProperties = authProperties;
    }

    public void check(String key) {
        AttemptWindow window = attempts.compute(key, (ignored, existing) -> {
            Instant now = Instant.now();
            long windowSeconds = authProperties.getLoginRateLimit().getWindowSeconds();
            if (existing == null || existing.windowStart().plusSeconds(windowSeconds).isBefore(now)) {
                return new AttemptWindow(now, 0);
            }
            return existing;
        });

        if (window.count() >= authProperties.getLoginRateLimit().getMaxAttempts()) {
            throw new ApiException(
                    "LOGIN_RATE_LIMITED",
                    "Too many login attempts. Try again later.",
                    HttpStatus.TOO_MANY_REQUESTS);
        }
    }

    public void recordFailure(String key) {
        attempts.compute(key, (ignored, existing) -> {
            Instant now = Instant.now();
            long windowSeconds = authProperties.getLoginRateLimit().getWindowSeconds();
            if (existing == null || existing.windowStart().plusSeconds(windowSeconds).isBefore(now)) {
                return new AttemptWindow(now, 1);
            }
            return new AttemptWindow(existing.windowStart(), existing.count() + 1);
        });
    }

    public void clear(String key) {
        attempts.remove(key);
    }

    private record AttemptWindow(Instant windowStart, int count) {
    }
}
