package com.fixnear.auth.dto;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public record RegisterResponse(
        String message,
        String verificationToken,
        String verificationUrl
) {
}
