package com.fixnear.user.domain;

public enum AccountStatus {
    PENDING_VERIFICATION,
    ACTIVE,
    DISABLED
}
