package com.fixnear.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "fixnear.auth")
public class AuthProperties {

    private final Jwt jwt = new Jwt();
    private final RefreshCookie refreshCookie = new RefreshCookie();
    private final EmailVerification emailVerification = new EmailVerification();
    private final LoginRateLimit loginRateLimit = new LoginRateLimit();
    /**
     * When true (local/dev only), register/resend responses include the raw verification token
     * so you can complete signup without a mail server.
     */
    private boolean exposeVerificationToken = false;

    public Jwt getJwt() {
        return jwt;
    }

    public RefreshCookie getRefreshCookie() {
        return refreshCookie;
    }

    public EmailVerification getEmailVerification() {
        return emailVerification;
    }

    public LoginRateLimit getLoginRateLimit() {
        return loginRateLimit;
    }

    public boolean isExposeVerificationToken() {
        return exposeVerificationToken;
    }

    public void setExposeVerificationToken(boolean exposeVerificationToken) {
        this.exposeVerificationToken = exposeVerificationToken;
    }

    public static class Jwt {
        private String secret = "change-me-to-a-long-random-secret-at-least-32-chars";
        private long accessTokenTtlSeconds = 900;

        public String getSecret() {
            return secret;
        }

        public void setSecret(String secret) {
            this.secret = secret;
        }

        public long getAccessTokenTtlSeconds() {
            return accessTokenTtlSeconds;
        }

        public void setAccessTokenTtlSeconds(long accessTokenTtlSeconds) {
            this.accessTokenTtlSeconds = accessTokenTtlSeconds;
        }
    }

    public static class RefreshCookie {
        private String name = "fixnear_refresh";
        private long ttlSeconds = 1_209_600;
        private boolean secure = false;
        private String sameSite = "Lax";
        private String path = "/api/v1/auth";

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public long getTtlSeconds() {
            return ttlSeconds;
        }

        public void setTtlSeconds(long ttlSeconds) {
            this.ttlSeconds = ttlSeconds;
        }

        public boolean isSecure() {
            return secure;
        }

        public void setSecure(boolean secure) {
            this.secure = secure;
        }

        public String getSameSite() {
            return sameSite;
        }

        public void setSameSite(String sameSite) {
            this.sameSite = sameSite;
        }

        public String getPath() {
            return path;
        }

        public void setPath(String path) {
            this.path = path;
        }
    }

    public static class EmailVerification {
        private long ttlSeconds = 86_400;
        private String frontendBaseUrl = "http://localhost:5173";

        public long getTtlSeconds() {
            return ttlSeconds;
        }

        public void setTtlSeconds(long ttlSeconds) {
            this.ttlSeconds = ttlSeconds;
        }

        public String getFrontendBaseUrl() {
            return frontendBaseUrl;
        }

        public void setFrontendBaseUrl(String frontendBaseUrl) {
            this.frontendBaseUrl = frontendBaseUrl;
        }
    }

    public static class LoginRateLimit {
        private int maxAttempts = 5;
        private long windowSeconds = 900;

        public int getMaxAttempts() {
            return maxAttempts;
        }

        public void setMaxAttempts(int maxAttempts) {
            this.maxAttempts = maxAttempts;
        }

        public long getWindowSeconds() {
            return windowSeconds;
        }

        public void setWindowSeconds(long windowSeconds) {
            this.windowSeconds = windowSeconds;
        }
    }
}
