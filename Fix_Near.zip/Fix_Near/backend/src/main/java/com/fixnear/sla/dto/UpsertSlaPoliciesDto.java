package com.fixnear.sla.dto;

import java.util.List;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;

public record UpsertSlaPoliciesDto(@NotEmpty @Valid List<SlaPolicyDto> policies) {
}
