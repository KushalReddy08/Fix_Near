package com.fixnear.commitment.dto;

import jakarta.validation.constraints.Size;

public record CompleteCommitmentDto(@Size(max = 5000) String note) {
}
