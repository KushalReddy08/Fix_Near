package com.fixnear.user.dto;

import java.time.Instant;
import java.util.UUID;

import com.fixnear.user.domain.AccountStatus;
import com.fixnear.user.domain.PlatformRole;
import com.fixnear.user.domain.User;

public record UserResponse(
        UUID id,
        String email,
        String fullName,
        PlatformRole platformRole,
        AccountStatus accountStatus,
        Instant createdAt,
        Instant updatedAt
) {

    public static UserResponse from(User user) {
        return new UserResponse(
                user.getId(),
                user.getEmail(),
                user.getFullName(),
                user.getPlatformRole(),
                user.getAccountStatus(),
                user.getCreatedAt(),
                user.getUpdatedAt()
        );
    }
}
