package com.fixnear.sla.dto;

import java.util.UUID;

import com.fixnear.complaint.domain.ComplaintPriority;
import com.fixnear.sla.domain.SlaPolicy;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public record SlaPolicyDto(
        UUID id,
        @NotBlank @Size(max = 100) String category,
        @NotNull ComplaintPriority priority,
        @Min(1) int acknowledgeHours,
        @Min(1) int resolveHours
) {

    public static SlaPolicyDto from(SlaPolicy policy) {
        return new SlaPolicyDto(
                policy.getId(),
                policy.getCategory(),
                policy.getPriority(),
                policy.getAcknowledgeHours(),
                policy.getResolveHours());
    }
}
