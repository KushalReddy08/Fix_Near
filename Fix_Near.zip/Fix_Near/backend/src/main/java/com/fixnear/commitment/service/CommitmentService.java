package com.fixnear.commitment.service;

import java.time.Instant;
import java.util.List;
import java.util.UUID;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.fixnear.commitment.domain.Commitment;
import com.fixnear.commitment.domain.CommitmentStatus;
import com.fixnear.commitment.dto.CommitmentResponse;
import com.fixnear.commitment.dto.CompleteCommitmentDto;
import com.fixnear.commitment.dto.CreateCommitmentDto;
import com.fixnear.commitment.repository.CommitmentRepository;
import com.fixnear.common.exception.ApiException;
import com.fixnear.complaint.repository.ComplaintRepository;
import com.fixnear.organization.domain.Organization;
import com.fixnear.organization.repository.OrganizationRepository;
import com.fixnear.organization.service.OrganizationAccessService;
import com.fixnear.user.domain.User;
import com.fixnear.user.repository.UserRepository;

@Service
public class CommitmentService {

    private final CommitmentRepository commitmentRepository;
    private final OrganizationRepository organizationRepository;
    private final ComplaintRepository complaintRepository;
    private final UserRepository userRepository;
    private final OrganizationAccessService accessService;

    public CommitmentService(
            CommitmentRepository commitmentRepository,
            OrganizationRepository organizationRepository,
            ComplaintRepository complaintRepository,
            UserRepository userRepository,
            OrganizationAccessService accessService) {
        this.commitmentRepository = commitmentRepository;
        this.organizationRepository = organizationRepository;
        this.complaintRepository = complaintRepository;
        this.userRepository = userRepository;
        this.accessService = accessService;
    }

    @Transactional(readOnly = true)
    public List<CommitmentResponse> list(UUID organizationId, UUID userId) {
        accessService.requireActiveMember(organizationId, userId);
        return commitmentRepository.findByOrganizationIdOrderByCreatedAtDesc(organizationId).stream()
                .map(CommitmentResponse::from)
                .toList();
    }

    @Transactional
    public CommitmentResponse create(UUID organizationId, UUID userId, CreateCommitmentDto dto) {
        accessService.requireComplaintHandler(organizationId, userId);
        Organization organization = organizationRepository.findById(organizationId)
                .orElseThrow(() -> new ApiException("ORG_NOT_FOUND", "Organization not found", HttpStatus.NOT_FOUND));
        User creator = userRepository.findById(userId)
                .orElseThrow(() -> new ApiException("USER_NOT_FOUND", "User not found", HttpStatus.NOT_FOUND));
        if (dto.complaintId() != null) {
            complaintRepository.findByIdAndOrganizationId(dto.complaintId(), organizationId)
                    .orElseThrow(() -> new ApiException("COMPLAINT_NOT_FOUND", "Complaint not found", HttpStatus.NOT_FOUND));
        }

        Commitment commitment = new Commitment();
        commitment.setOrganization(organization);
        commitment.setCreatedBy(creator);
        commitment.setComplaintId(dto.complaintId());
        commitment.setTitle(dto.title().trim());
        commitment.setDescription(dto.description().trim());
        commitment.setDueAt(dto.dueAt());
        commitment.setStatus(CommitmentStatus.ACCEPTED);
        commitmentRepository.save(commitment);
        return CommitmentResponse.from(commitment);
    }

    @Transactional
    public CommitmentResponse complete(UUID organizationId, UUID commitmentId, UUID userId, CompleteCommitmentDto dto) {
        accessService.requireComplaintHandler(organizationId, userId);
        Commitment commitment = commitmentRepository.findByIdAndOrganizationId(commitmentId, organizationId)
                .orElseThrow(() -> new ApiException("NOT_FOUND", "Commitment not found", HttpStatus.NOT_FOUND));
        commitment.setStatus(CommitmentStatus.COMPLETED);
        commitment.setCompletedAt(Instant.now());
        commitment.setOverdue(false);
        return CommitmentResponse.from(commitment);
    }
}
