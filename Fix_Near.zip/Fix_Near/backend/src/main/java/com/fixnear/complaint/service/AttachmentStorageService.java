package com.fixnear.complaint.service;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.Set;
import java.util.UUID;

import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.fixnear.common.exception.ApiException;
import com.fixnear.config.StorageProperties;

@Service
public class AttachmentStorageService {

    public static final long MAX_BYTES = 10 * 1024 * 1024;
    public static final int MAX_PER_COMPLAINT = 5;
    public static final Set<String> ALLOWED_TYPES = Set.of(
            "image/jpeg", "image/png", "image/webp", "application/pdf");

    private final Path root;

    public AttachmentStorageService(StorageProperties properties) {
        this.root = Path.of(properties.getRootDir()).toAbsolutePath().normalize();
        try {
            Files.createDirectories(root);
        } catch (IOException ex) {
            throw new IllegalStateException("Cannot create attachment storage directory: " + root, ex);
        }
    }

    public String store(UUID organizationId, UUID complaintId, MultipartFile file) {
        validate(file);
        String key = organizationId + "/" + complaintId + "/" + UUID.randomUUID() + "-" + sanitize(file.getOriginalFilename());
        Path target = root.resolve(key).normalize();
        if (!target.startsWith(root)) {
            throw new ApiException("INVALID_PATH", "Invalid storage path", HttpStatus.BAD_REQUEST);
        }
        try {
            Files.createDirectories(target.getParent());
            try (InputStream in = file.getInputStream()) {
                Files.copy(in, target, StandardCopyOption.REPLACE_EXISTING);
            }
            return key;
        } catch (IOException ex) {
            throw new ApiException("STORAGE_ERROR", "Failed to store attachment", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public Resource loadAsResource(String storageKey) {
        try {
            Path file = root.resolve(storageKey).normalize();
            if (!file.startsWith(root) || !Files.exists(file)) {
                throw new ApiException("NOT_FOUND", "Attachment file not found", HttpStatus.NOT_FOUND);
            }
            return new UrlResource(file.toUri());
        } catch (IOException ex) {
            throw new ApiException("STORAGE_ERROR", "Failed to read attachment", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    private void validate(MultipartFile file) {
        if (file == null || file.isEmpty()) {
            throw new ApiException("VALIDATION_ERROR", "File is required", HttpStatus.BAD_REQUEST);
        }
        if (file.getSize() > MAX_BYTES) {
            throw new ApiException("FILE_TOO_LARGE", "Max file size is 10 MB", HttpStatus.BAD_REQUEST);
        }
        String contentType = file.getContentType();
        if (contentType == null || !ALLOWED_TYPES.contains(contentType)) {
            throw new ApiException(
                    "INVALID_FILE_TYPE",
                    "Only jpeg, png, webp, and pdf are allowed",
                    HttpStatus.BAD_REQUEST);
        }
    }

    private String sanitize(String name) {
        if (name == null || name.isBlank()) {
            return "file";
        }
        return name.replaceAll("[^a-zA-Z0-9._-]", "_");
    }
}
