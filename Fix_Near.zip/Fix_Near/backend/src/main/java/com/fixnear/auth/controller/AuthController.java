package com.fixnear.auth.controller;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.fixnear.auth.dto.AuthTokensResponse;
import com.fixnear.auth.dto.LoginRequest;
import com.fixnear.auth.dto.MessageResponse;
import com.fixnear.auth.dto.RegisterRequest;
import com.fixnear.auth.dto.RegisterResponse;
import com.fixnear.auth.dto.ResendVerificationRequest;
import com.fixnear.auth.dto.VerifyEmailRequest;
import com.fixnear.auth.service.AuthService;
import com.fixnear.auth.service.RefreshCookieService;
import com.fixnear.common.api.ApiResponse;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/v1/auth")
public class AuthController {

    private final AuthService authService;
    private final RefreshCookieService refreshCookieService;

    public AuthController(AuthService authService, RefreshCookieService refreshCookieService) {
        this.authService = authService;
        this.refreshCookieService = refreshCookieService;
    }

    @PostMapping("/register")
    @ResponseStatus(HttpStatus.CREATED)
    public ApiResponse<RegisterResponse> register(@Valid @RequestBody RegisterRequest request) {
        return ApiResponse.ok(authService.register(request));
    }

    @PostMapping("/resend-verification")
    public ApiResponse<RegisterResponse> resendVerification(
            @Valid @RequestBody ResendVerificationRequest request) {
        return ApiResponse.ok(authService.resendVerification(request.email()));
    }

    @PostMapping("/verify-email")
    public ApiResponse<MessageResponse> verifyEmail(@Valid @RequestBody VerifyEmailRequest request) {
        authService.verifyEmail(request.token());
        return ApiResponse.ok(new MessageResponse("Email verified successfully. You can now log in."));
    }

    @PostMapping("/login")
    public ApiResponse<AuthTokensResponse> login(
            @Valid @RequestBody LoginRequest request,
            HttpServletRequest httpRequest,
            HttpServletResponse httpResponse) {
        String clientKey = httpRequest.getRemoteAddr();
        AuthService.IssuedSession session = authService.login(request, clientKey);
        refreshCookieService.write(httpResponse, session.rawRefreshToken());
        return ApiResponse.ok(session.body());
    }

    @PostMapping("/refresh")
    public ApiResponse<AuthTokensResponse> refresh(
            HttpServletRequest httpRequest,
            HttpServletResponse httpResponse) {
        String rawRefresh = refreshCookieService.read(httpRequest);
        AuthService.IssuedSession session = authService.refresh(rawRefresh);
        refreshCookieService.write(httpResponse, session.rawRefreshToken());
        return ApiResponse.ok(session.body());
    }

    @PostMapping("/logout")
    public ApiResponse<MessageResponse> logout(
            HttpServletRequest httpRequest,
            HttpServletResponse httpResponse) {
        authService.logout(refreshCookieService.read(httpRequest));
        refreshCookieService.clear(httpResponse);
        return ApiResponse.ok(new MessageResponse("Logged out"));
    }
}
