package com.fixnear.organization.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public record CreateDepartmentDto(
        @NotBlank @Size(max = 150) String name,
        @Size(max = 500) String description
) {
}
