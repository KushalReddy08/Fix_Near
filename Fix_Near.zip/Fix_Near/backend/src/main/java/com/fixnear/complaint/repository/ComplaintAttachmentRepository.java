package com.fixnear.complaint.repository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;

import com.fixnear.complaint.domain.ComplaintAttachment;

public interface ComplaintAttachmentRepository extends JpaRepository<ComplaintAttachment, UUID> {

    List<ComplaintAttachment> findByComplaintIdOrderByCreatedAtAsc(UUID complaintId);

    Optional<ComplaintAttachment> findByIdAndComplaintIdAndOrganizationId(
            UUID id, UUID complaintId, UUID organizationId);

    long countByComplaintId(UUID complaintId);
}
