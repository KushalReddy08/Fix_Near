package com.fixnear.commitment.domain;

public enum CommitmentStatus {
    PROPOSED,
    ACCEPTED,
    IN_PROGRESS,
    COMPLETED,
    VERIFIED,
    CANCELLED
}
