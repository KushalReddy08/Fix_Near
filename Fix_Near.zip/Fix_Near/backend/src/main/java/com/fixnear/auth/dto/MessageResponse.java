package com.fixnear.auth.dto;

public record MessageResponse(String message) {
}
