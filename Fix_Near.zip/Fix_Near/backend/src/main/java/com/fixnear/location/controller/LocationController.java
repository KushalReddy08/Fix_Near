package com.fixnear.location.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fixnear.common.api.ApiResponse;
import com.fixnear.location.dto.LocationNameResponse;
import com.fixnear.location.service.LocationService;

@RestController
@RequestMapping("/api/v1/locations")
public class LocationController {

    private final LocationService locationService;

    public LocationController(LocationService locationService) {
        this.locationService = locationService;
    }

    @GetMapping("/countries")
    public ApiResponse<LocationNameResponse> countries() {
        return ApiResponse.ok(new LocationNameResponse(locationService.listCountries()));
    }

    @GetMapping("/states")
    public ApiResponse<LocationNameResponse> states(@RequestParam String country) {
        return ApiResponse.ok(new LocationNameResponse(locationService.listStates(country)));
    }

    @GetMapping("/cities")
    public ApiResponse<LocationNameResponse> cities(
            @RequestParam String country,
            @RequestParam String state) {
        return ApiResponse.ok(new LocationNameResponse(locationService.listCities(country, state)));
    }
}
