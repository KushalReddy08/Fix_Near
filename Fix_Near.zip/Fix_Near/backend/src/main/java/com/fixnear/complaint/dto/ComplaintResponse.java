package com.fixnear.complaint.dto;

import java.time.Instant;
import java.util.UUID;

import com.fixnear.complaint.domain.Complaint;
import com.fixnear.complaint.domain.ComplaintPriority;
import com.fixnear.complaint.domain.ComplaintStatus;
import com.fixnear.complaint.domain.IdentityMode;

public record ComplaintResponse(
        UUID id,
        UUID organizationId,
        UUID reporterId,
        String reporterName,
        UUID assigneeId,
        String assigneeName,
        UUID departmentId,
        String title,
        String description,
        String category,
        ComplaintPriority priority,
        ComplaintStatus workflowStatus,
        IdentityMode identityMode,
        boolean overdue,
        String locationText,
        Double latitude,
        Double longitude,
        Instant acknowledgementDeadline,
        Instant resolutionDeadline,
        Instant acknowledgedAt,
        Instant resolvedAt,
        Instant closedAt,
        String resolutionNote,
        int reopenCount,
        int supportCount,
        Instant createdAt,
        Instant updatedAt
) {

    public static ComplaintResponse from(Complaint complaint) {
        return from(complaint, true);
    }

    public static ComplaintResponse from(Complaint complaint, boolean revealReporter) {
        boolean redact = !revealReporter && complaint.getIdentityMode() != IdentityMode.NAMED;
        String reporterName = redact ? "Anonymous reporter" : complaint.getReporter().getFullName();
        UUID reporterId = redact ? null : complaint.getReporter().getId();
        return new ComplaintResponse(
                complaint.getId(),
                complaint.getOrganization().getId(),
                reporterId,
                reporterName,
                complaint.getAssignee() == null ? null : complaint.getAssignee().getId(),
                complaint.getAssignee() == null ? null : complaint.getAssignee().getFullName(),
                complaint.getDepartment() == null ? null : complaint.getDepartment().getId(),
                complaint.getTitle(),
                complaint.getDescription(),
                complaint.getCategory(),
                complaint.getPriority(),
                complaint.getWorkflowStatus(),
                complaint.getIdentityMode(),
                complaint.isOverdue(),
                complaint.getLocationText(),
                complaint.getLatitude(),
                complaint.getLongitude(),
                complaint.getAcknowledgementDeadline(),
                complaint.getResolutionDeadline(),
                complaint.getAcknowledgedAt(),
                complaint.getResolvedAt(),
                complaint.getClosedAt(),
                complaint.getResolutionNote(),
                complaint.getReopenCount(),
                complaint.getSupportCount(),
                complaint.getCreatedAt(),
                complaint.getUpdatedAt());
    }
}
