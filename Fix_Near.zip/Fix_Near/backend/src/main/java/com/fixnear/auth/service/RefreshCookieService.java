package com.fixnear.auth.service;

import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseCookie;
import org.springframework.stereotype.Service;

import com.fixnear.config.AuthProperties;

import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@Service
public class RefreshCookieService {

    private final AuthProperties authProperties;

    public RefreshCookieService(AuthProperties authProperties) {
        this.authProperties = authProperties;
    }

    public void write(HttpServletResponse response, String rawRefreshToken) {
        AuthProperties.RefreshCookie cfg = authProperties.getRefreshCookie();
        ResponseCookie cookie = ResponseCookie.from(cfg.getName(), rawRefreshToken)
                .httpOnly(true)
                .secure(cfg.isSecure())
                .path(cfg.getPath())
                .maxAge(cfg.getTtlSeconds())
                .sameSite(cfg.getSameSite())
                .build();
        response.addHeader(HttpHeaders.SET_COOKIE, cookie.toString());
    }

    public void clear(HttpServletResponse response) {
        AuthProperties.RefreshCookie cfg = authProperties.getRefreshCookie();
        ResponseCookie cookie = ResponseCookie.from(cfg.getName(), "")
                .httpOnly(true)
                .secure(cfg.isSecure())
                .path(cfg.getPath())
                .maxAge(0)
                .sameSite(cfg.getSameSite())
                .build();
        response.addHeader(HttpHeaders.SET_COOKIE, cookie.toString());
    }

    public String read(HttpServletRequest request) {
        Cookie[] cookies = request.getCookies();
        if (cookies == null) {
            return null;
        }
        String name = authProperties.getRefreshCookie().getName();
        for (Cookie cookie : cookies) {
            if (name.equals(cookie.getName())) {
                return cookie.getValue();
            }
        }
        return null;
    }
}
