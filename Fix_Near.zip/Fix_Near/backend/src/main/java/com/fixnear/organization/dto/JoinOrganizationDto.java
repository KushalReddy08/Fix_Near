package com.fixnear.organization.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public record JoinOrganizationDto(
        @NotBlank @Size(min = 20, max = 200) String invitationCode
) {
}
