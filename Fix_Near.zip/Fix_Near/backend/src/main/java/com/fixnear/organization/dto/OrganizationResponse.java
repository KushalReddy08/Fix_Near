package com.fixnear.organization.dto;

import java.time.Instant;
import java.util.UUID;

import com.fixnear.organization.domain.MemberRole;
import com.fixnear.organization.domain.Organization;
import com.fixnear.organization.domain.OrganizationStatus;
import com.fixnear.organization.domain.OrganizationType;

public record OrganizationResponse(
        UUID id,
        String name,
        OrganizationType organizationType,
        String description,
        String timezone,
        String country,
        String stateProvince,
        String city,
        String addressLine,
        OrganizationStatus status,
        MemberRole myRole,
        Instant createdAt,
        Instant updatedAt
) {

    public static OrganizationResponse from(Organization org, MemberRole myRole) {
        return new OrganizationResponse(
                org.getId(),
                org.getName(),
                org.getOrganizationType(),
                org.getDescription(),
                org.getTimezone(),
                org.getCountry(),
                org.getStateProvince(),
                org.getCity(),
                org.getAddressLine(),
                org.getStatus(),
                myRole,
                org.getCreatedAt(),
                org.getUpdatedAt());
    }
}
