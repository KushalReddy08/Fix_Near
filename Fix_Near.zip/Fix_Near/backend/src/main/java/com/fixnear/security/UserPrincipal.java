package com.fixnear.security;

import java.util.Collection;
import java.util.List;
import java.util.UUID;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import com.fixnear.user.domain.PlatformRole;
import com.fixnear.user.domain.User;

public class UserPrincipal implements UserDetails {

    private final UUID id;
    private final String email;
    private final String passwordHash;
    private final PlatformRole platformRole;
    private final boolean active;

    public UserPrincipal(UUID id, String email, String passwordHash, PlatformRole platformRole, boolean active) {
        this.id = id;
        this.email = email;
        this.passwordHash = passwordHash;
        this.platformRole = platformRole;
        this.active = active;
    }

    public static UserPrincipal from(User user) {
        return new UserPrincipal(
                user.getId(),
                user.getEmail(),
                user.getPasswordHash(),
                user.getPlatformRole(),
                user.getAccountStatus().name().equals("ACTIVE"));
    }

    public UUID getId() {
        return id;
    }

    public PlatformRole getPlatformRole() {
        return platformRole;
    }

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return List.of(new SimpleGrantedAuthority("ROLE_" + platformRole.name()));
    }

    @Override
    public String getPassword() {
        return passwordHash;
    }

    @Override
    public String getUsername() {
        return email;
    }

    @Override
    public boolean isAccountNonExpired() {
        return true;
    }

    @Override
    public boolean isAccountNonLocked() {
        return active;
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return true;
    }

    @Override
    public boolean isEnabled() {
        return active;
    }
}
