package com.fixnear.organization.dto;

import java.time.Instant;
import java.util.UUID;

import com.fixnear.organization.domain.Department;

public record DepartmentResponse(
        UUID id,
        String name,
        String description,
        UUID managerMemberId,
        Instant createdAt
) {

    public static DepartmentResponse from(Department department) {
        return new DepartmentResponse(
                department.getId(),
                department.getName(),
                department.getDescription(),
                department.getManagerMember() == null ? null : department.getManagerMember().getId(),
                department.getCreatedAt());
    }
}
