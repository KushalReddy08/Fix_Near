package com.fixnear.complaint.dto;

import com.fixnear.complaint.domain.CommentVisibility;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public record CreateCommentDto(
        @NotBlank @Size(max = 5000) String body,
        @NotNull CommentVisibility visibility
) {
}
