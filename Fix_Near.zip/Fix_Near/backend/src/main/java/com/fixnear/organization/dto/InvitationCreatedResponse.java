package com.fixnear.organization.dto;

import java.time.Instant;
import java.util.UUID;

import com.fixnear.organization.domain.MemberRole;

public record InvitationCreatedResponse(
        UUID invitationId,
        String invitationCode,
        MemberRole memberRole,
        String invitedEmail,
        Instant expiresAt
) {
}
