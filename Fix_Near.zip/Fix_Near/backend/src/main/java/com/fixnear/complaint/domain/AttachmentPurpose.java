package com.fixnear.complaint.domain;

public enum AttachmentPurpose {
    EVIDENCE,
    RESOLUTION,
    COMMENT
}
