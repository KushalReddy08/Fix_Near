package com.fixnear.complaint.dto;

import java.time.Instant;
import java.util.UUID;

import com.fixnear.complaint.domain.AttachmentPurpose;
import com.fixnear.complaint.domain.ComplaintAttachment;

public record AttachmentResponse(
        UUID id,
        String originalName,
        String contentType,
        long sizeBytes,
        AttachmentPurpose purpose,
        UUID uploaderId,
        String uploaderName,
        Instant createdAt
) {

    public static AttachmentResponse from(ComplaintAttachment attachment) {
        return new AttachmentResponse(
                attachment.getId(),
                attachment.getOriginalName(),
                attachment.getContentType(),
                attachment.getSizeBytes(),
                attachment.getPurpose(),
                attachment.getUploader().getId(),
                attachment.getUploader().getFullName(),
                attachment.getCreatedAt());
    }
}
