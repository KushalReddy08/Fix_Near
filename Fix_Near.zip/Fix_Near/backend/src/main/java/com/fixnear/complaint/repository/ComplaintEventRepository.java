package com.fixnear.complaint.repository;

import java.util.List;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;

import com.fixnear.complaint.domain.ComplaintEvent;

public interface ComplaintEventRepository extends JpaRepository<ComplaintEvent, UUID> {

    List<ComplaintEvent> findByComplaintIdOrderByCreatedAtAsc(UUID complaintId);
}
