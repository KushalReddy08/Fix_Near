package com.fixnear.complaint.domain;

public enum ComplaintStatus {
    SUBMITTED,
    ACKNOWLEDGED,
    ASSIGNED,
    IN_PROGRESS,
    RESOLVED,
    REJECTED,
    CLOSED,
    REOPENED
}
