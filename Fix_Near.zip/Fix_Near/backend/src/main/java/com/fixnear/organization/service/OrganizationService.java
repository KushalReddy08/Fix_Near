package com.fixnear.organization.service;

import java.security.SecureRandom;
import java.time.Instant;
import java.time.ZoneId;
import java.util.Base64;
import java.util.List;
import java.util.UUID;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.fixnear.auth.util.TokenHasher;
import com.fixnear.common.exception.ApiException;
import com.fixnear.organization.domain.Department;
import com.fixnear.organization.domain.MemberRole;
import com.fixnear.organization.domain.OrgRequestStatus;
import com.fixnear.organization.domain.Organization;
import com.fixnear.organization.domain.OrganizationCreationRequest;
import com.fixnear.organization.domain.OrganizationInvitation;
import com.fixnear.organization.domain.OrganizationMember;
import com.fixnear.organization.domain.OrganizationStatus;
import com.fixnear.organization.dto.CreateDepartmentDto;
import com.fixnear.organization.dto.CreateInvitationDto;
import com.fixnear.organization.dto.CreateOrgRequestDto;
import com.fixnear.organization.dto.DepartmentResponse;
import com.fixnear.organization.dto.InvitationCreatedResponse;
import com.fixnear.organization.dto.JoinOrganizationDto;
import com.fixnear.organization.dto.MemberResponse;
import com.fixnear.organization.dto.OrgRequestResponse;
import com.fixnear.organization.dto.OrganizationResponse;
import com.fixnear.organization.dto.ReviewOrgRequestDto;
import com.fixnear.organization.dto.UpdateMemberRoleDto;
import com.fixnear.organization.dto.UpdateOrganizationDto;
import com.fixnear.organization.repository.DepartmentRepository;
import com.fixnear.organization.repository.OrganizationCreationRequestRepository;
import com.fixnear.organization.repository.OrganizationInvitationRepository;
import com.fixnear.organization.repository.OrganizationMemberRepository;
import com.fixnear.organization.repository.OrganizationRepository;
import com.fixnear.security.UserPrincipal;
import com.fixnear.user.domain.User;
import com.fixnear.user.repository.UserRepository;

@Service
public class OrganizationService {

    private static final long INVITE_TTL_SECONDS = 7 * 24 * 3600L;

    private final OrganizationRepository organizationRepository;
    private final OrganizationCreationRequestRepository requestRepository;
    private final OrganizationMemberRepository memberRepository;
    private final OrganizationInvitationRepository invitationRepository;
    private final DepartmentRepository departmentRepository;
    private final UserRepository userRepository;
    private final OrganizationAccessService accessService;
    private final SecureRandom secureRandom = new SecureRandom();

    public OrganizationService(
            OrganizationRepository organizationRepository,
            OrganizationCreationRequestRepository requestRepository,
            OrganizationMemberRepository memberRepository,
            OrganizationInvitationRepository invitationRepository,
            DepartmentRepository departmentRepository,
            UserRepository userRepository,
            OrganizationAccessService accessService) {
        this.organizationRepository = organizationRepository;
        this.requestRepository = requestRepository;
        this.memberRepository = memberRepository;
        this.invitationRepository = invitationRepository;
        this.departmentRepository = departmentRepository;
        this.userRepository = userRepository;
        this.accessService = accessService;
    }

    @Transactional
    public OrgRequestResponse submitCreationRequest(UUID requesterId, CreateOrgRequestDto dto) {
        validateTimezone(dto.timezone());
        if (requestRepository.existsByRequesterIdAndStatus(requesterId, OrgRequestStatus.PENDING)) {
            throw new ApiException(
                    "PENDING_REQUEST_EXISTS",
                    "You already have a pending organization creation request",
                    HttpStatus.CONFLICT);
        }

        User requester = userRepository.findById(requesterId)
                .orElseThrow(() -> new ApiException("USER_NOT_FOUND", "User not found", HttpStatus.NOT_FOUND));

        OrganizationCreationRequest request = new OrganizationCreationRequest();
        request.setRequester(requester);
        request.setName(dto.name().trim());
        request.setOrganizationType(dto.organizationType());
        request.setDescription(trimToNull(dto.description()));
        request.setTimezone(dto.timezone().trim());
        request.setCountry(dto.country().trim());
        request.setStateProvince(dto.stateProvince().trim());
        request.setCity(dto.city().trim());
        request.setAddressLine(dto.addressLine().trim());
        request.setStatus(OrgRequestStatus.PENDING);
        requestRepository.save(request);
        return OrgRequestResponse.from(request);
    }

    @Transactional(readOnly = true)
    public List<OrgRequestResponse> myRequests(UUID requesterId) {
        return requestRepository.findByRequesterIdOrderByCreatedAtDesc(requesterId).stream()
                .map(OrgRequestResponse::from)
                .toList();
    }

    @Transactional(readOnly = true)
    public List<OrgRequestResponse> pendingRequests(UserPrincipal principal) {
        accessService.requirePlatformAdmin(principal);
        return requestRepository.findByStatusOrderByCreatedAtAsc(OrgRequestStatus.PENDING).stream()
                .map(OrgRequestResponse::from)
                .toList();
    }

    @Transactional
    public OrganizationResponse approveRequest(UUID requestId, UserPrincipal admin, ReviewOrgRequestDto dto) {
        accessService.requirePlatformAdmin(admin);
        OrganizationCreationRequest request = requestRepository.findById(requestId)
                .orElseThrow(() -> new ApiException("REQUEST_NOT_FOUND", "Request not found", HttpStatus.NOT_FOUND));
        if (request.getStatus() != OrgRequestStatus.PENDING) {
            throw new ApiException("REQUEST_NOT_PENDING", "Request is not pending", HttpStatus.CONFLICT);
        }

        User reviewer = userRepository.findById(admin.getId())
                .orElseThrow(() -> new ApiException("USER_NOT_FOUND", "User not found", HttpStatus.NOT_FOUND));

        Organization organization = new Organization();
        organization.setName(request.getName());
        organization.setOrganizationType(request.getOrganizationType());
        organization.setDescription(request.getDescription());
        organization.setTimezone(request.getTimezone());
        organization.setCountry(request.getCountry());
        organization.setStateProvince(request.getStateProvince());
        organization.setCity(request.getCity());
        organization.setAddressLine(request.getAddressLine());
        organization.setStatus(OrganizationStatus.ACTIVE);
        organization.setCreatedByRequestId(request.getId());
        organizationRepository.save(organization);

        OrganizationMember head = new OrganizationMember();
        head.setOrganization(organization);
        head.setUser(request.getRequester());
        head.setMemberRole(MemberRole.HEAD);
        memberRepository.save(head);

        request.setStatus(OrgRequestStatus.APPROVED);
        request.setReviewNote(trimToNull(dto == null ? null : dto.reviewNote()));
        request.setReviewedBy(reviewer);
        request.setReviewedAt(Instant.now());

        return OrganizationResponse.from(organization, MemberRole.HEAD);
    }

    @Transactional
    public OrgRequestResponse rejectRequest(UUID requestId, UserPrincipal admin, ReviewOrgRequestDto dto) {
        accessService.requirePlatformAdmin(admin);
        OrganizationCreationRequest request = requestRepository.findById(requestId)
                .orElseThrow(() -> new ApiException("REQUEST_NOT_FOUND", "Request not found", HttpStatus.NOT_FOUND));
        if (request.getStatus() != OrgRequestStatus.PENDING) {
            throw new ApiException("REQUEST_NOT_PENDING", "Request is not pending", HttpStatus.CONFLICT);
        }
        User reviewer = userRepository.findById(admin.getId())
                .orElseThrow(() -> new ApiException("USER_NOT_FOUND", "User not found", HttpStatus.NOT_FOUND));
        request.setStatus(OrgRequestStatus.REJECTED);
        request.setReviewNote(trimToNull(dto == null ? null : dto.reviewNote()));
        request.setReviewedBy(reviewer);
        request.setReviewedAt(Instant.now());
        return OrgRequestResponse.from(request);
    }

    @Transactional(readOnly = true)
    public List<OrganizationResponse> myOrganizations(UUID userId) {
        return memberRepository.findByUserIdAndRevokedAtIsNull(userId).stream()
                .map(member -> OrganizationResponse.from(member.getOrganization(), member.getMemberRole()))
                .toList();
    }

    @Transactional(readOnly = true)
    public OrganizationResponse getOrganization(UUID organizationId, UUID userId) {
        OrganizationMember member = accessService.requireActiveMember(organizationId, userId);
        return OrganizationResponse.from(member.getOrganization(), member.getMemberRole());
    }

    @Transactional
    public OrganizationResponse updateOrganization(UUID organizationId, UUID userId, UpdateOrganizationDto dto) {
        accessService.requireLeadership(organizationId, userId);
        validateTimezone(dto.timezone());
        Organization organization = organizationRepository.findById(organizationId)
                .orElseThrow(() -> new ApiException("ORG_NOT_FOUND", "Organization not found", HttpStatus.NOT_FOUND));
        organization.setName(dto.name().trim());
        organization.setDescription(trimToNull(dto.description()));
        organization.setTimezone(dto.timezone().trim());
        OrganizationMember me = accessService.requireActiveMember(organizationId, userId);
        return OrganizationResponse.from(organization, me.getMemberRole());
    }

    @Transactional
    public InvitationCreatedResponse createInvitation(UUID organizationId, UUID actorId, CreateInvitationDto dto) {
        accessService.requireLeadership(organizationId, actorId);
        if (dto.memberRole() == MemberRole.HEAD) {
            throw new ApiException("INVALID_INVITE_ROLE", "HEAD cannot be assigned via invitation", HttpStatus.BAD_REQUEST);
        }
        accessService.ensureCoAdminCap(organizationId, dto.memberRole());

        Organization organization = organizationRepository.findById(organizationId)
                .orElseThrow(() -> new ApiException("ORG_NOT_FOUND", "Organization not found", HttpStatus.NOT_FOUND));
        User creator = userRepository.findById(actorId)
                .orElseThrow(() -> new ApiException("USER_NOT_FOUND", "User not found", HttpStatus.NOT_FOUND));

        String rawCode = createOpaqueToken();
        OrganizationInvitation invitation = new OrganizationInvitation();
        invitation.setOrganization(organization);
        invitation.setCodeHash(TokenHasher.sha256(rawCode));
        invitation.setInvitedEmail(dto.invitedEmail() == null ? null : dto.invitedEmail().trim().toLowerCase());
        invitation.setMemberRole(dto.memberRole());
        invitation.setCreatedBy(creator);
        invitation.setExpiresAt(Instant.now().plusSeconds(INVITE_TTL_SECONDS));
        invitationRepository.save(invitation);

        return new InvitationCreatedResponse(
                invitation.getId(),
                rawCode,
                invitation.getMemberRole(),
                invitation.getInvitedEmail(),
                invitation.getExpiresAt());
    }

    @Transactional
    public OrganizationResponse join(UUID userId, JoinOrganizationDto dto) {
        OrganizationInvitation invitation = invitationRepository.findByCodeHash(TokenHasher.sha256(dto.invitationCode()))
                .orElseThrow(() -> new ApiException("INVALID_INVITATION", "Invalid invitation code", HttpStatus.BAD_REQUEST));
        if (invitation.isUsed() || invitation.isExpired()) {
            throw new ApiException("INVALID_INVITATION", "Invitation is used or expired", HttpStatus.BAD_REQUEST);
        }

        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ApiException("USER_NOT_FOUND", "User not found", HttpStatus.NOT_FOUND));
        if (invitation.getInvitedEmail() != null
                && !invitation.getInvitedEmail().equalsIgnoreCase(user.getEmail())) {
            throw new ApiException(
                    "INVITATION_EMAIL_MISMATCH",
                    "This invitation is restricted to a different email address",
                    HttpStatus.FORBIDDEN);
        }

        UUID organizationId = invitation.getOrganization().getId();
        if (memberRepository.existsByOrganizationIdAndUserIdAndRevokedAtIsNull(organizationId, userId)) {
            throw new ApiException("ALREADY_MEMBER", "You are already a member of this organization", HttpStatus.CONFLICT);
        }

        accessService.ensureCoAdminCap(organizationId, invitation.getMemberRole());

        OrganizationMember member = new OrganizationMember();
        member.setOrganization(invitation.getOrganization());
        member.setUser(user);
        member.setMemberRole(invitation.getMemberRole());
        memberRepository.save(member);

        invitation.setUsedAt(Instant.now());
        invitation.setUsedBy(user);

        return OrganizationResponse.from(invitation.getOrganization(), member.getMemberRole());
    }

    @Transactional(readOnly = true)
    public List<MemberResponse> listMembers(UUID organizationId, UUID userId) {
        accessService.requireActiveMember(organizationId, userId);
        return memberRepository.findByOrganizationIdAndRevokedAtIsNullOrderByJoinedAtAsc(organizationId).stream()
                .map(MemberResponse::from)
                .toList();
    }

    @Transactional
    public MemberResponse updateMemberRole(UUID organizationId, UUID actorId, UUID targetUserId, UpdateMemberRoleDto dto) {
        OrganizationMember actor = accessService.requireLeadership(organizationId, actorId);
        if (dto.memberRole() == MemberRole.HEAD) {
            throw new ApiException(
                    "HEAD_TRANSFER_REQUIRED",
                    "HEAD is unique. Use an audited head-transfer flow (not available in this phase).",
                    HttpStatus.BAD_REQUEST);
        }

        OrganizationMember target = accessService.requireActiveMember(organizationId, targetUserId);
        if (target.getMemberRole() == MemberRole.HEAD) {
            throw new ApiException("CANNOT_CHANGE_HEAD", "Cannot change the HEAD role this way", HttpStatus.BAD_REQUEST);
        }
        if (actor.getMemberRole() == MemberRole.CO_ADMIN && target.getMemberRole() == MemberRole.CO_ADMIN
                && dto.memberRole() != MemberRole.CO_ADMIN) {
            // co-admins may demote other co-admins only if HEAD does it — keep simple: only HEAD changes co-admins
        }
        if (actor.getMemberRole() != MemberRole.HEAD && target.getMemberRole() == MemberRole.CO_ADMIN) {
            throw new ApiException("HEAD_REQUIRED", "Only the HEAD can change co-admin roles", HttpStatus.FORBIDDEN);
        }

        if (dto.memberRole() == MemberRole.CO_ADMIN && target.getMemberRole() != MemberRole.CO_ADMIN) {
            accessService.ensureCoAdminCap(organizationId, MemberRole.CO_ADMIN);
        }
        target.setMemberRole(dto.memberRole());
        return MemberResponse.from(target);
    }

    @Transactional
    public void revokeMember(UUID organizationId, UUID actorId, UUID targetUserId) {
        OrganizationMember actor = accessService.requireLeadership(organizationId, actorId);
        OrganizationMember target = accessService.requireActiveMember(organizationId, targetUserId);
        if (target.getMemberRole() == MemberRole.HEAD) {
            throw new ApiException("CANNOT_REVOKE_HEAD", "HEAD membership cannot be revoked this way", HttpStatus.BAD_REQUEST);
        }
        if (actor.getUser().getId().equals(targetUserId)) {
            throw new ApiException("CANNOT_REVOKE_SELF", "Use leave flow later; cannot revoke yourself here", HttpStatus.BAD_REQUEST);
        }
        if (actor.getMemberRole() != MemberRole.HEAD && target.getMemberRole() == MemberRole.CO_ADMIN) {
            throw new ApiException("HEAD_REQUIRED", "Only the HEAD can revoke a co-admin", HttpStatus.FORBIDDEN);
        }
        target.setRevokedAt(Instant.now());
    }

    @Transactional
    public DepartmentResponse createDepartment(UUID organizationId, UUID actorId, CreateDepartmentDto dto) {
        accessService.requireLeadership(organizationId, actorId);
        if (departmentRepository.existsByOrganizationIdAndNameIgnoreCase(organizationId, dto.name().trim())) {
            throw new ApiException("DEPARTMENT_EXISTS", "Department name already exists", HttpStatus.CONFLICT);
        }
        Organization organization = organizationRepository.findById(organizationId)
                .orElseThrow(() -> new ApiException("ORG_NOT_FOUND", "Organization not found", HttpStatus.NOT_FOUND));
        Department department = new Department();
        department.setOrganization(organization);
        department.setName(dto.name().trim());
        department.setDescription(trimToNull(dto.description()));
        departmentRepository.save(department);
        return DepartmentResponse.from(department);
    }

    @Transactional(readOnly = true)
    public List<DepartmentResponse> listDepartments(UUID organizationId, UUID userId) {
        accessService.requireActiveMember(organizationId, userId);
        return departmentRepository.findByOrganizationIdOrderByNameAsc(organizationId).stream()
                .map(DepartmentResponse::from)
                .toList();
    }

    private void validateTimezone(String timezone) {
        try {
            ZoneId.of(timezone.trim());
        } catch (Exception ex) {
            throw new ApiException("INVALID_TIMEZONE", "Invalid IANA timezone", HttpStatus.BAD_REQUEST);
        }
    }

    private String createOpaqueToken() {
        byte[] bytes = new byte[24];
        secureRandom.nextBytes(bytes);
        return Base64.getUrlEncoder().withoutPadding().encodeToString(bytes);
    }

    private String trimToNull(String value) {
        if (value == null) {
            return null;
        }
        String trimmed = value.trim();
        return trimmed.isEmpty() ? null : trimmed;
    }
}
