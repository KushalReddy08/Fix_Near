package com.fixnear.organization.dto;

import java.time.Instant;
import java.util.UUID;

import com.fixnear.organization.domain.OrgRequestStatus;
import com.fixnear.organization.domain.OrganizationCreationRequest;
import com.fixnear.organization.domain.OrganizationType;

public record OrgRequestResponse(
        UUID id,
        UUID requesterId,
        String requesterEmail,
        String name,
        OrganizationType organizationType,
        String description,
        String timezone,
        String country,
        String stateProvince,
        String city,
        String addressLine,
        OrgRequestStatus status,
        String reviewNote,
        Instant createdAt,
        Instant reviewedAt
) {

    public static OrgRequestResponse from(OrganizationCreationRequest request) {
        return new OrgRequestResponse(
                request.getId(),
                request.getRequester().getId(),
                request.getRequester().getEmail(),
                request.getName(),
                request.getOrganizationType(),
                request.getDescription(),
                request.getTimezone(),
                request.getCountry(),
                request.getStateProvince(),
                request.getCity(),
                request.getAddressLine(),
                request.getStatus(),
                request.getReviewNote(),
                request.getCreatedAt(),
                request.getReviewedAt());
    }
}
