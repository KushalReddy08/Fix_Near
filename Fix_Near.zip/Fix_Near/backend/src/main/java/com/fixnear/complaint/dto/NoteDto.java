package com.fixnear.complaint.dto;

import jakarta.validation.constraints.Size;

public record NoteDto(@Size(max = 5000) String note) {
}
