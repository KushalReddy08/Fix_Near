package com.fixnear.complaint.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public record ResolveComplaintDto(@NotBlank @Size(max = 5000) String resolutionNote) {
}
