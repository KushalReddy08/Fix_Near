package com.fixnear.auth.service;

import java.security.SecureRandom;
import java.time.Instant;
import java.util.Base64;
import java.util.UUID;

import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.fixnear.auth.domain.EmailVerificationToken;
import com.fixnear.auth.domain.RefreshToken;
import com.fixnear.auth.dto.AuthTokensResponse;
import com.fixnear.auth.dto.LoginRequest;
import com.fixnear.auth.dto.RegisterRequest;
import com.fixnear.auth.dto.RegisterResponse;
import com.fixnear.auth.repository.EmailVerificationTokenRepository;
import com.fixnear.auth.repository.RefreshTokenRepository;
import com.fixnear.auth.util.TokenHasher;
import com.fixnear.common.exception.ApiException;
import com.fixnear.config.AuthProperties;
import com.fixnear.user.domain.AccountStatus;
import com.fixnear.user.domain.PlatformRole;
import com.fixnear.user.domain.User;
import com.fixnear.user.dto.UserResponse;
import com.fixnear.user.repository.UserRepository;

@Service
public class AuthService {

    private final UserRepository userRepository;
    private final EmailVerificationTokenRepository emailVerificationTokenRepository;
    private final RefreshTokenRepository refreshTokenRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtService jwtService;
    private final AuthMailService authMailService;
    private final AuthProperties authProperties;
    private final LoginRateLimiter loginRateLimiter;
    private final SecureRandom secureRandom = new SecureRandom();

    public AuthService(
            UserRepository userRepository,
            EmailVerificationTokenRepository emailVerificationTokenRepository,
            RefreshTokenRepository refreshTokenRepository,
            PasswordEncoder passwordEncoder,
            JwtService jwtService,
            AuthMailService authMailService,
            AuthProperties authProperties,
            LoginRateLimiter loginRateLimiter) {
        this.userRepository = userRepository;
        this.emailVerificationTokenRepository = emailVerificationTokenRepository;
        this.refreshTokenRepository = refreshTokenRepository;
        this.passwordEncoder = passwordEncoder;
        this.jwtService = jwtService;
        this.authMailService = authMailService;
        this.authProperties = authProperties;
        this.loginRateLimiter = loginRateLimiter;
    }

    @Transactional
    public RegisterResponse register(RegisterRequest request) {
        String email = normalizeEmail(request.email());
        if (userRepository.existsByEmailIgnoreCase(email)) {
            throw new ApiException("EMAIL_ALREADY_REGISTERED", "An account with this email already exists",
                    HttpStatus.CONFLICT);
        }

        User user = new User();
        user.setEmail(email);
        user.setFullName(request.fullName().trim());
        user.setPasswordHash(passwordEncoder.encode(request.password()));
        user.setPlatformRole(PlatformRole.USER);
        user.setAccountStatus(AccountStatus.PENDING_VERIFICATION);
        userRepository.save(user);

        return issueVerification(user);
    }

    @Transactional
    public RegisterResponse resendVerification(String emailRaw) {
        String email = normalizeEmail(emailRaw);
        User user = userRepository.findByEmailIgnoreCase(email)
                .orElseThrow(() -> new ApiException("USER_NOT_FOUND", "No account found for this email",
                        HttpStatus.NOT_FOUND));

        if (user.getAccountStatus() == AccountStatus.ACTIVE) {
            throw new ApiException("ALREADY_VERIFIED", "This email is already verified. Please sign in.",
                    HttpStatus.CONFLICT);
        }
        if (user.getAccountStatus() == AccountStatus.DISABLED) {
            throw new ApiException("ACCOUNT_DISABLED", "This account has been disabled", HttpStatus.FORBIDDEN);
        }

        return issueVerification(user);
    }

    private RegisterResponse issueVerification(User user) {
        String rawToken = createOpaqueToken();
        EmailVerificationToken verificationToken = new EmailVerificationToken();
        verificationToken.setUser(user);
        verificationToken.setTokenHash(TokenHasher.sha256(rawToken));
        verificationToken.setExpiresAt(Instant.now()
                .plusSeconds(authProperties.getEmailVerification().getTtlSeconds()));
        emailVerificationTokenRepository.save(verificationToken);

        try {
            authMailService.sendVerificationEmail(user.getEmail(), rawToken);
        } catch (IllegalStateException ex) {
            throw new ApiException(
                    "EMAIL_SEND_FAILED",
                    "Could not send verification email. Start Mailpit with scripts/start-mailpit.sh "
                            + "and open http://127.0.0.1:8025 to read system emails.",
                    HttpStatus.SERVICE_UNAVAILABLE);
        }

        String verifyUrl = authProperties.getEmailVerification().getFrontendBaseUrl()
                + "/verify-email?token=" + rawToken;
        if (authProperties.isExposeVerificationToken()) {
            return new RegisterResponse(
                    "Registration successful. Use the verification token below (local/dev — no mail server).",
                    rawToken,
                    verifyUrl);
        }
        return new RegisterResponse(
                "Registration successful. Please verify your email before logging in.",
                null,
                null);
    }

    @Transactional
    public void verifyEmail(String rawToken) {
        EmailVerificationToken token = emailVerificationTokenRepository
                .findByTokenHash(TokenHasher.sha256(rawToken))
                .orElseThrow(() -> new ApiException("INVALID_VERIFICATION_TOKEN",
                        "Invalid or expired verification token", HttpStatus.BAD_REQUEST));

        if (token.isUsed() || token.isExpired()) {
            throw new ApiException("INVALID_VERIFICATION_TOKEN",
                    "Invalid or expired verification token", HttpStatus.BAD_REQUEST);
        }

        User user = token.getUser();
        user.setAccountStatus(AccountStatus.ACTIVE);
        token.setUsedAt(Instant.now());
    }

    @Transactional
    public IssuedSession login(LoginRequest request, String clientKey) {
        String email = normalizeEmail(request.email());
        String rateKey = clientKey + "|" + email;
        loginRateLimiter.check(rateKey);

        User user = userRepository.findByEmailIgnoreCase(email).orElse(null);
        if (user == null || !passwordEncoder.matches(request.password(), user.getPasswordHash())) {
            loginRateLimiter.recordFailure(rateKey);
            throw new ApiException("INVALID_CREDENTIALS", "Invalid email or password", HttpStatus.UNAUTHORIZED);
        }

        if (user.getAccountStatus() == AccountStatus.PENDING_VERIFICATION) {
            throw new ApiException("EMAIL_NOT_VERIFIED", "Please verify your email before logging in",
                    HttpStatus.FORBIDDEN);
        }
        if (user.getAccountStatus() == AccountStatus.DISABLED) {
            throw new ApiException("ACCOUNT_DISABLED", "This account has been disabled", HttpStatus.FORBIDDEN);
        }

        loginRateLimiter.clear(rateKey);
        return issueSession(user, UUID.randomUUID());
    }

    @Transactional
    public IssuedSession refresh(String rawRefreshToken) {
        if (rawRefreshToken == null || rawRefreshToken.isBlank()) {
            throw new ApiException("REFRESH_TOKEN_MISSING", "Refresh token cookie is missing",
                    HttpStatus.UNAUTHORIZED);
        }

        RefreshToken existing = refreshTokenRepository.findByTokenHash(TokenHasher.sha256(rawRefreshToken))
                .orElseThrow(() -> new ApiException("INVALID_REFRESH_TOKEN", "Invalid refresh token",
                        HttpStatus.UNAUTHORIZED));

        if (existing.isRevoked() || existing.isExpired()) {
            refreshTokenRepository.revokeFamily(existing.getFamilyId(), Instant.now());
            throw new ApiException("INVALID_REFRESH_TOKEN", "Refresh token is revoked or expired",
                    HttpStatus.UNAUTHORIZED);
        }

        User user = existing.getUser();
        if (user.getAccountStatus() != AccountStatus.ACTIVE) {
            refreshTokenRepository.revokeFamily(existing.getFamilyId(), Instant.now());
            throw new ApiException("ACCOUNT_NOT_ACTIVE", "Account is not active", HttpStatus.FORBIDDEN);
        }

        IssuedSession session = issueSession(user, existing.getFamilyId());
        existing.setRevokedAt(Instant.now());
        existing.setReplacedById(session.refreshTokenEntity().getId());
        return session;
    }

    @Transactional
    public void logout(String rawRefreshToken) {
        if (rawRefreshToken == null || rawRefreshToken.isBlank()) {
            return;
        }
        refreshTokenRepository.findByTokenHash(TokenHasher.sha256(rawRefreshToken))
                .ifPresent(token -> {
                    if (!token.isRevoked()) {
                        token.setRevokedAt(Instant.now());
                    }
                });
    }

    @Transactional
    public void revokeAllSessions(UUID userId) {
        refreshTokenRepository.revokeAllActiveForUser(userId, Instant.now());
    }

    private IssuedSession issueSession(User user, UUID familyId) {
        String accessToken = jwtService.createAccessToken(user);
        String rawRefresh = createOpaqueToken();

        RefreshToken refreshToken = new RefreshToken();
        refreshToken.setUser(user);
        refreshToken.setFamilyId(familyId);
        refreshToken.setTokenHash(TokenHasher.sha256(rawRefresh));
        refreshToken.setExpiresAt(Instant.now().plusSeconds(authProperties.getRefreshCookie().getTtlSeconds()));
        refreshTokenRepository.save(refreshToken);

        AuthTokensResponse response = new AuthTokensResponse(
                accessToken,
                "Bearer",
                jwtService.getAccessTokenTtlSeconds(),
                UserResponse.from(user));
        return new IssuedSession(response, rawRefresh, refreshToken);
    }

    private String createOpaqueToken() {
        byte[] bytes = new byte[32];
        secureRandom.nextBytes(bytes);
        return Base64.getUrlEncoder().withoutPadding().encodeToString(bytes);
    }

    private String normalizeEmail(String email) {
        String normalized = email.trim().toLowerCase();
        // Hardcoded system operator login alias (Phase 3+).
        if ("system".equals(normalized)) {
            return "system@fixnear.local";
        }
        return normalized;
    }

    public record IssuedSession(AuthTokensResponse body, String rawRefreshToken, RefreshToken refreshTokenEntity) {
    }
}
