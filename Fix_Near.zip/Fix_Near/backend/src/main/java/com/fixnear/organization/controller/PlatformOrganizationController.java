package com.fixnear.organization.controller;

import java.util.List;
import java.util.UUID;

import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fixnear.common.api.ApiResponse;
import com.fixnear.organization.dto.OrgRequestResponse;
import com.fixnear.organization.dto.OrganizationResponse;
import com.fixnear.organization.dto.ReviewOrgRequestDto;
import com.fixnear.organization.service.OrganizationService;
import com.fixnear.security.UserPrincipal;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/v1/platform/organization-requests")
public class PlatformOrganizationController {

    private final OrganizationService organizationService;

    public PlatformOrganizationController(OrganizationService organizationService) {
        this.organizationService = organizationService;
    }

    @GetMapping
    public ApiResponse<List<OrgRequestResponse>> pending(@AuthenticationPrincipal UserPrincipal principal) {
        return ApiResponse.ok(organizationService.pendingRequests(principal));
    }

    @PostMapping("/{requestId}/approve")
    public ApiResponse<OrganizationResponse> approve(
            @AuthenticationPrincipal UserPrincipal principal,
            @PathVariable UUID requestId,
            @RequestBody(required = false) @Valid ReviewOrgRequestDto body) {
        return ApiResponse.ok(organizationService.approveRequest(
                requestId, principal, body == null ? new ReviewOrgRequestDto(null) : body));
    }

    @PostMapping("/{requestId}/reject")
    public ApiResponse<OrgRequestResponse> reject(
            @AuthenticationPrincipal UserPrincipal principal,
            @PathVariable UUID requestId,
            @RequestBody(required = false) @Valid ReviewOrgRequestDto body) {
        return ApiResponse.ok(organizationService.rejectRequest(
                requestId, principal, body == null ? new ReviewOrgRequestDto(null) : body));
    }
}
