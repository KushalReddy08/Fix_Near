package com.fixnear.location.service;

import java.net.URI;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Collections;
import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;

import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClient;
import org.springframework.web.client.RestClientException;
import org.springframework.web.util.UriComponentsBuilder;

import com.fixnear.common.exception.ApiException;

@Service
public class LocationService {

    private static final String COUNTRIES_STATES_URL = "https://countriesnow.space/api/v0.1/countries/states";
    private static final String CITIES_URL = "https://countriesnow.space/api/v0.1/countries/state/cities/q";

    private final RestClient restClient;
    private final AtomicReference<Map<String, List<String>>> countryStatesCache = new AtomicReference<>();

    public LocationService(RestClient restClient) {
        this.restClient = restClient;
    }

    public List<String> listCountries() {
        return List.copyOf(loadCountryStates().keySet());
    }

    public List<String> listStates(String country) {
        requireText(country, "country");
        String needle = country.trim();
        Map<String, List<String>> catalog = loadCountryStates();
        List<String> states = catalog.get(needle);
        if (states != null) {
            return states;
        }
        for (Map.Entry<String, List<String>> entry : catalog.entrySet()) {
            if (entry.getKey().equalsIgnoreCase(needle)) {
                return entry.getValue();
            }
        }
        return List.of();
    }

    public List<String> listCities(String country, String state) {
        requireText(country, "country");
        requireText(state, "state");
        try {
            URI uri = UriComponentsBuilder.fromUriString(CITIES_URL)
                    .queryParam("country", country.trim())
                    .queryParam("state", state.trim())
                    .encode()
                    .build()
                    .toUri();
            Map<String, Object> response = restClient.get()
                    .uri(uri)
                    .retrieve()
                    .body(new ParameterizedTypeReference<>() {
                    });
            if (response == null || Boolean.TRUE.equals(response.get("error"))) {
                return List.of();
            }
            Object data = response.get("data");
            if (!(data instanceof List<?> list)) {
                return List.of();
            }
            List<String> cities = new ArrayList<>();
            for (Object item : list) {
                if (item != null && !item.toString().isBlank()) {
                    cities.add(item.toString());
                }
            }
            cities.sort(String.CASE_INSENSITIVE_ORDER);
            return cities;
        } catch (RestClientException ex) {
            throw new ApiException(
                    "LOCATION_UNAVAILABLE",
                    "City lookup service is temporarily unavailable",
                    HttpStatus.BAD_GATEWAY);
        }
    }

    private Map<String, List<String>> loadCountryStates() {
        Map<String, List<String>> cached = countryStatesCache.get();
        if (cached != null) {
            return cached;
        }
        synchronized (this) {
            cached = countryStatesCache.get();
            if (cached != null) {
                return cached;
            }
            try {
                Map<String, Object> response = restClient.get()
                        .uri(COUNTRIES_STATES_URL)
                        .retrieve()
                        .body(new ParameterizedTypeReference<>() {
                        });
                if (response == null || Boolean.TRUE.equals(response.get("error"))) {
                    throw new ApiException("LOCATION_UNAVAILABLE", "Could not load countries", HttpStatus.BAD_GATEWAY);
                }
                Object data = response.get("data");
                if (!(data instanceof List<?> list)) {
                    throw new ApiException("LOCATION_UNAVAILABLE", "Could not load countries", HttpStatus.BAD_GATEWAY);
                }

                Map<String, List<String>> catalog = new LinkedHashMap<>();
                for (Object item : list) {
                    if (!(item instanceof Map<?, ?> map)) {
                        continue;
                    }
                    Object nameObj = map.get("name");
                    if (nameObj == null || nameObj.toString().isBlank()) {
                        continue;
                    }
                    String countryName = nameObj.toString().trim();
                    List<String> states = new ArrayList<>();
                    Object nested = map.get("states");
                    if (nested instanceof List<?> stateList) {
                        for (Object stateItem : stateList) {
                            if (stateItem instanceof Map<?, ?> stateMap) {
                                Object stateName = stateMap.get("name");
                                if (stateName != null && !stateName.toString().isBlank()) {
                                    states.add(stateName.toString());
                                }
                            } else if (stateItem != null && !stateItem.toString().isBlank()) {
                                states.add(stateItem.toString());
                            }
                        }
                    }
                    states.sort(String.CASE_INSENSITIVE_ORDER);
                    catalog.put(countryName, List.copyOf(states));
                }

                // Keep insertion order by sorted country names for dropdown UX.
                Map<String, List<String>> sorted = new LinkedHashMap<>();
                catalog.entrySet().stream()
                        .sorted(Map.Entry.comparingByKey(String.CASE_INSENSITIVE_ORDER))
                        .forEach(entry -> sorted.put(entry.getKey(), entry.getValue()));

                countryStatesCache.set(Collections.unmodifiableMap(sorted));
                return countryStatesCache.get();
            } catch (RestClientException ex) {
                throw new ApiException(
                        "LOCATION_UNAVAILABLE",
                        "Country lookup service is temporarily unavailable",
                        HttpStatus.BAD_GATEWAY);
            }
        }
    }

    private void requireText(String value, String field) {
        if (value == null || value.trim().isEmpty()) {
            throw new ApiException("VALIDATION_ERROR", field + " is required", HttpStatus.BAD_REQUEST);
        }
    }
}
