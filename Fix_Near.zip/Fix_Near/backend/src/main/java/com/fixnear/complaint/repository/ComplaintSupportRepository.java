package com.fixnear.complaint.repository;

import java.util.Optional;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;

import com.fixnear.complaint.domain.ComplaintSupport;

public interface ComplaintSupportRepository extends JpaRepository<ComplaintSupport, UUID> {

    Optional<ComplaintSupport> findByComplaintIdAndUserId(UUID complaintId, UUID userId);

    boolean existsByComplaintIdAndUserId(UUID complaintId, UUID userId);

    long countByComplaintId(UUID complaintId);
}
