package com.fixnear.civic.controller;

import java.util.List;

import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fixnear.common.api.ApiResponse;
import com.fixnear.complaint.dto.ComplaintResponse;
import com.fixnear.complaint.service.ComplaintService;
import com.fixnear.security.UserPrincipal;

@RestController
@RequestMapping("/api/v1/civic")
public class CivicController {

    private final ComplaintService complaintService;

    public CivicController(ComplaintService complaintService) {
        this.complaintService = complaintService;
    }

    @GetMapping("/map/complaints")
    public ApiResponse<List<ComplaintResponse>> mapComplaints(@AuthenticationPrincipal UserPrincipal principal) {
        return ApiResponse.ok(complaintService.civicMap(principal.getId()));
    }
}
