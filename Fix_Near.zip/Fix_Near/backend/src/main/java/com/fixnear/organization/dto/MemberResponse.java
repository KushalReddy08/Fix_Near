package com.fixnear.organization.dto;

import java.time.Instant;
import java.util.UUID;

import com.fixnear.organization.domain.MemberRole;
import com.fixnear.organization.domain.OrganizationMember;

public record MemberResponse(
        UUID membershipId,
        UUID userId,
        String email,
        String fullName,
        MemberRole memberRole,
        UUID departmentId,
        Instant joinedAt
) {

    public static MemberResponse from(OrganizationMember member) {
        return new MemberResponse(
                member.getId(),
                member.getUser().getId(),
                member.getUser().getEmail(),
                member.getUser().getFullName(),
                member.getMemberRole(),
                member.getDepartment() == null ? null : member.getDepartment().getId(),
                member.getJoinedAt());
    }
}
