package com.fixnear.organization.service;

import java.util.UUID;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.fixnear.common.exception.ApiException;
import com.fixnear.organization.domain.MemberRole;
import com.fixnear.organization.domain.OrganizationMember;
import com.fixnear.organization.repository.OrganizationMemberRepository;
import com.fixnear.security.UserPrincipal;
import com.fixnear.user.domain.PlatformRole;

@Service
public class OrganizationAccessService {

    private final OrganizationMemberRepository memberRepository;

    public OrganizationAccessService(OrganizationMemberRepository memberRepository) {
        this.memberRepository = memberRepository;
    }

    @Transactional(readOnly = true)
    public OrganizationMember requireActiveMember(UUID organizationId, UUID userId) {
        return memberRepository.findByOrganizationIdAndUserIdAndRevokedAtIsNull(organizationId, userId)
                .orElseThrow(() -> new ApiException(
                        "ORG_ACCESS_DENIED",
                        "You are not a member of this organization",
                        HttpStatus.FORBIDDEN));
    }

    @Transactional(readOnly = true)
    public OrganizationMember requireLeadership(UUID organizationId, UUID userId) {
        OrganizationMember member = requireActiveMember(organizationId, userId);
        if (!member.getMemberRole().canManageMembers()) {
            throw new ApiException(
                    "ORG_LEADERSHIP_REQUIRED",
                    "Only the organization head or co-admins can perform this action",
                    HttpStatus.FORBIDDEN);
        }
        return member;
    }

    @Transactional(readOnly = true)
    public OrganizationMember requireComplaintHandler(UUID organizationId, UUID userId) {
        OrganizationMember member = requireActiveMember(organizationId, userId);
        if (!member.getMemberRole().canHandleComplaints()) {
            throw new ApiException(
                    "COMPLAINT_HANDLER_REQUIRED",
                    "Only officials or leadership can perform this complaint action",
                    HttpStatus.FORBIDDEN);
        }
        return member;
    }

    public void requirePlatformAdmin(UserPrincipal principal) {
        if (principal.getPlatformRole() != PlatformRole.PLATFORM_ADMIN) {
            throw new ApiException(
                    "PLATFORM_ADMIN_REQUIRED",
                    "Only platform administrators can perform this action",
                    HttpStatus.FORBIDDEN);
        }
    }

    public void ensureCoAdminCap(UUID organizationId, MemberRole role) {
        if (role != MemberRole.CO_ADMIN) {
            return;
        }
        long count = memberRepository.countByOrganizationIdAndMemberRoleAndRevokedAtIsNull(
                organizationId, MemberRole.CO_ADMIN);
        if (count >= 4) {
            throw new ApiException(
                    "CO_ADMIN_LIMIT_REACHED",
                    "An organization may have at most 4 co-admins",
                    HttpStatus.CONFLICT);
        }
    }
}
