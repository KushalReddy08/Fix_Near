package com.fixnear.organization.repository;

import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;

import com.fixnear.organization.domain.Organization;

public interface OrganizationRepository extends JpaRepository<Organization, UUID> {
}
