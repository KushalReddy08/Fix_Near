package com.fixnear.organization.repository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;

import com.fixnear.organization.domain.MemberRole;
import com.fixnear.organization.domain.OrganizationMember;

public interface OrganizationMemberRepository extends JpaRepository<OrganizationMember, UUID> {

    Optional<OrganizationMember> findByOrganizationIdAndUserIdAndRevokedAtIsNull(UUID organizationId, UUID userId);

    List<OrganizationMember> findByUserIdAndRevokedAtIsNull(UUID userId);

    List<OrganizationMember> findByOrganizationIdAndRevokedAtIsNullOrderByJoinedAtAsc(UUID organizationId);

    long countByOrganizationIdAndMemberRoleAndRevokedAtIsNull(UUID organizationId, MemberRole memberRole);

    boolean existsByOrganizationIdAndUserIdAndRevokedAtIsNull(UUID organizationId, UUID userId);
}
