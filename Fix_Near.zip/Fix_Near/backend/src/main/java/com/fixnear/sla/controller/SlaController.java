package com.fixnear.sla.controller;

import java.util.List;
import java.util.UUID;

import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fixnear.common.api.ApiResponse;
import com.fixnear.security.UserPrincipal;
import com.fixnear.sla.dto.OrgDashboardResponse;
import com.fixnear.sla.dto.SlaPolicyDto;
import com.fixnear.sla.dto.UpsertSlaPoliciesDto;
import com.fixnear.sla.service.SlaService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/v1/organizations/{organizationId}")
public class SlaController {

    private final SlaService slaService;

    public SlaController(SlaService slaService) {
        this.slaService = slaService;
    }

    @GetMapping("/sla-policies")
    public ApiResponse<List<SlaPolicyDto>> list(
            @AuthenticationPrincipal UserPrincipal principal,
            @PathVariable UUID organizationId) {
        return ApiResponse.ok(slaService.listPolicies(organizationId, principal.getId()));
    }

    @PutMapping("/sla-policies")
    public ApiResponse<List<SlaPolicyDto>> upsert(
            @AuthenticationPrincipal UserPrincipal principal,
            @PathVariable UUID organizationId,
            @Valid @RequestBody UpsertSlaPoliciesDto request) {
        return ApiResponse.ok(slaService.upsertPolicies(organizationId, principal.getId(), request));
    }

    @GetMapping("/dashboard")
    public ApiResponse<OrgDashboardResponse> dashboard(
            @AuthenticationPrincipal UserPrincipal principal,
            @PathVariable UUID organizationId) {
        return ApiResponse.ok(slaService.dashboard(organizationId, principal.getId()));
    }
}
