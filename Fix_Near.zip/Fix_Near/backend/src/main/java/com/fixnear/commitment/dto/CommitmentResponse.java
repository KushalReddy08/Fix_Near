package com.fixnear.commitment.dto;

import java.time.Instant;
import java.util.UUID;

import com.fixnear.commitment.domain.Commitment;
import com.fixnear.commitment.domain.CommitmentStatus;

public record CommitmentResponse(
        UUID id,
        UUID organizationId,
        UUID complaintId,
        UUID createdById,
        String createdByName,
        String title,
        String description,
        CommitmentStatus status,
        Instant dueAt,
        boolean overdue,
        Instant completedAt,
        Instant createdAt,
        Instant updatedAt
) {

    public static CommitmentResponse from(Commitment commitment) {
        return new CommitmentResponse(
                commitment.getId(),
                commitment.getOrganization().getId(),
                commitment.getComplaintId(),
                commitment.getCreatedBy().getId(),
                commitment.getCreatedBy().getFullName(),
                commitment.getTitle(),
                commitment.getDescription(),
                commitment.getStatus(),
                commitment.getDueAt(),
                commitment.isOverdue(),
                commitment.getCompletedAt(),
                commitment.getCreatedAt(),
                commitment.getUpdatedAt());
    }
}
