package com.fixnear.organization.controller;

import java.util.List;
import java.util.UUID;

import org.springframework.http.HttpStatus;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.fixnear.common.api.ApiResponse;
import com.fixnear.organization.dto.CreateDepartmentDto;
import com.fixnear.organization.dto.CreateInvitationDto;
import com.fixnear.organization.dto.CreateOrgRequestDto;
import com.fixnear.organization.dto.DepartmentResponse;
import com.fixnear.organization.dto.InvitationCreatedResponse;
import com.fixnear.organization.dto.JoinOrganizationDto;
import com.fixnear.organization.dto.MemberResponse;
import com.fixnear.organization.dto.OrgRequestResponse;
import com.fixnear.organization.dto.OrganizationResponse;
import com.fixnear.organization.dto.UpdateMemberRoleDto;
import com.fixnear.organization.dto.UpdateOrganizationDto;
import com.fixnear.organization.service.OrganizationService;
import com.fixnear.security.UserPrincipal;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/v1/organizations")
public class OrganizationController {

    private final OrganizationService organizationService;

    public OrganizationController(OrganizationService organizationService) {
        this.organizationService = organizationService;
    }

    @PostMapping("/requests")
    @ResponseStatus(HttpStatus.CREATED)
    public ApiResponse<OrgRequestResponse> submitRequest(
            @AuthenticationPrincipal UserPrincipal principal,
            @Valid @RequestBody CreateOrgRequestDto request) {
        return ApiResponse.ok(organizationService.submitCreationRequest(principal.getId(), request));
    }

    @GetMapping("/requests/mine")
    public ApiResponse<List<OrgRequestResponse>> myRequests(@AuthenticationPrincipal UserPrincipal principal) {
        return ApiResponse.ok(organizationService.myRequests(principal.getId()));
    }

    @GetMapping
    public ApiResponse<List<OrganizationResponse>> myOrganizations(@AuthenticationPrincipal UserPrincipal principal) {
        return ApiResponse.ok(organizationService.myOrganizations(principal.getId()));
    }

    @GetMapping("/{organizationId}")
    public ApiResponse<OrganizationResponse> getOrganization(
            @AuthenticationPrincipal UserPrincipal principal,
            @PathVariable UUID organizationId) {
        return ApiResponse.ok(organizationService.getOrganization(organizationId, principal.getId()));
    }

    @PutMapping("/{organizationId}")
    public ApiResponse<OrganizationResponse> updateOrganization(
            @AuthenticationPrincipal UserPrincipal principal,
            @PathVariable UUID organizationId,
            @Valid @RequestBody UpdateOrganizationDto request) {
        return ApiResponse.ok(organizationService.updateOrganization(organizationId, principal.getId(), request));
    }

    @PostMapping("/{organizationId}/invitations")
    @ResponseStatus(HttpStatus.CREATED)
    public ApiResponse<InvitationCreatedResponse> createInvitation(
            @AuthenticationPrincipal UserPrincipal principal,
            @PathVariable UUID organizationId,
            @Valid @RequestBody CreateInvitationDto request) {
        return ApiResponse.ok(organizationService.createInvitation(organizationId, principal.getId(), request));
    }

    @PostMapping("/join")
    public ApiResponse<OrganizationResponse> join(
            @AuthenticationPrincipal UserPrincipal principal,
            @Valid @RequestBody JoinOrganizationDto request) {
        return ApiResponse.ok(organizationService.join(principal.getId(), request));
    }

    @GetMapping("/{organizationId}/members")
    public ApiResponse<List<MemberResponse>> members(
            @AuthenticationPrincipal UserPrincipal principal,
            @PathVariable UUID organizationId) {
        return ApiResponse.ok(organizationService.listMembers(organizationId, principal.getId()));
    }

    @PutMapping("/{organizationId}/members/{userId}")
    public ApiResponse<MemberResponse> updateMemberRole(
            @AuthenticationPrincipal UserPrincipal principal,
            @PathVariable UUID organizationId,
            @PathVariable UUID userId,
            @Valid @RequestBody UpdateMemberRoleDto request) {
        return ApiResponse.ok(
                organizationService.updateMemberRole(organizationId, principal.getId(), userId, request));
    }

    @DeleteMapping("/{organizationId}/members/{userId}")
    public ApiResponse<Void> revokeMember(
            @AuthenticationPrincipal UserPrincipal principal,
            @PathVariable UUID organizationId,
            @PathVariable UUID userId) {
        organizationService.revokeMember(organizationId, principal.getId(), userId);
        return ApiResponse.ok();
    }

    @PostMapping("/{organizationId}/departments")
    @ResponseStatus(HttpStatus.CREATED)
    public ApiResponse<DepartmentResponse> createDepartment(
            @AuthenticationPrincipal UserPrincipal principal,
            @PathVariable UUID organizationId,
            @Valid @RequestBody CreateDepartmentDto request) {
        return ApiResponse.ok(organizationService.createDepartment(organizationId, principal.getId(), request));
    }

    @GetMapping("/{organizationId}/departments")
    public ApiResponse<List<DepartmentResponse>> listDepartments(
            @AuthenticationPrincipal UserPrincipal principal,
            @PathVariable UUID organizationId) {
        return ApiResponse.ok(organizationService.listDepartments(organizationId, principal.getId()));
    }
}
