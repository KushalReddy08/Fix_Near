package com.fixnear.common.api;

public record ApiError(String code, String message) {
}
