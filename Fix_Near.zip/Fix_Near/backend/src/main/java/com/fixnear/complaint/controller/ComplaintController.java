package com.fixnear.complaint.controller;

import java.util.List;
import java.util.UUID;

import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.fixnear.common.api.ApiResponse;
import com.fixnear.complaint.domain.AttachmentPurpose;
import com.fixnear.complaint.domain.ComplaintAttachment;
import com.fixnear.complaint.dto.AssignComplaintDto;
import com.fixnear.complaint.dto.AttachmentResponse;
import com.fixnear.complaint.dto.CommentResponse;
import com.fixnear.complaint.dto.ComplaintEventResponse;
import com.fixnear.complaint.dto.ComplaintResponse;
import com.fixnear.complaint.dto.CreateCommentDto;
import com.fixnear.complaint.dto.CreateComplaintDto;
import com.fixnear.complaint.dto.NoteDto;
import com.fixnear.complaint.dto.ReporterAckDto;
import com.fixnear.complaint.dto.ResolveComplaintDto;
import com.fixnear.complaint.service.ComplaintService;
import com.fixnear.security.UserPrincipal;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/v1/organizations/{organizationId}/complaints")
public class ComplaintController {

    private final ComplaintService complaintService;

    public ComplaintController(ComplaintService complaintService) {
        this.complaintService = complaintService;
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public ApiResponse<ComplaintResponse> create(
            @AuthenticationPrincipal UserPrincipal principal,
            @PathVariable UUID organizationId,
            @Valid @RequestBody CreateComplaintDto request) {
        return ApiResponse.ok(complaintService.create(organizationId, principal.getId(), request));
    }

    @GetMapping
    public ApiResponse<List<ComplaintResponse>> list(
            @AuthenticationPrincipal UserPrincipal principal,
            @PathVariable UUID organizationId) {
        return ApiResponse.ok(complaintService.listForOrganization(organizationId, principal.getId()));
    }

    @GetMapping("/{complaintId}")
    public ApiResponse<ComplaintResponse> get(
            @AuthenticationPrincipal UserPrincipal principal,
            @PathVariable UUID organizationId,
            @PathVariable UUID complaintId) {
        return ApiResponse.ok(complaintService.get(organizationId, complaintId, principal.getId()));
    }

    @PostMapping("/{complaintId}/acknowledge")
    public ApiResponse<ComplaintResponse> acknowledge(
            @AuthenticationPrincipal UserPrincipal principal,
            @PathVariable UUID organizationId,
            @PathVariable UUID complaintId) {
        return ApiResponse.ok(complaintService.acknowledge(organizationId, complaintId, principal.getId()));
    }

    @PostMapping("/{complaintId}/assign")
    public ApiResponse<ComplaintResponse> assign(
            @AuthenticationPrincipal UserPrincipal principal,
            @PathVariable UUID organizationId,
            @PathVariable UUID complaintId,
            @Valid @RequestBody AssignComplaintDto request) {
        return ApiResponse.ok(complaintService.assign(organizationId, complaintId, principal.getId(), request));
    }

    @PostMapping("/{complaintId}/start")
    public ApiResponse<ComplaintResponse> start(
            @AuthenticationPrincipal UserPrincipal principal,
            @PathVariable UUID organizationId,
            @PathVariable UUID complaintId) {
        return ApiResponse.ok(complaintService.start(organizationId, complaintId, principal.getId()));
    }

    @PostMapping("/{complaintId}/resolve")
    public ApiResponse<ComplaintResponse> resolve(
            @AuthenticationPrincipal UserPrincipal principal,
            @PathVariable UUID organizationId,
            @PathVariable UUID complaintId,
            @Valid @RequestBody ResolveComplaintDto request) {
        return ApiResponse.ok(complaintService.resolve(organizationId, complaintId, principal.getId(), request));
    }

    @PostMapping("/{complaintId}/reject")
    public ApiResponse<ComplaintResponse> reject(
            @AuthenticationPrincipal UserPrincipal principal,
            @PathVariable UUID organizationId,
            @PathVariable UUID complaintId,
            @RequestBody(required = false) NoteDto request) {
        return ApiResponse.ok(complaintService.reject(organizationId, complaintId, principal.getId(), request));
    }

    @PostMapping("/{complaintId}/reporter-ack")
    public ApiResponse<ComplaintResponse> reporterAck(
            @AuthenticationPrincipal UserPrincipal principal,
            @PathVariable UUID organizationId,
            @PathVariable UUID complaintId,
            @Valid @RequestBody ReporterAckDto request) {
        return ApiResponse.ok(complaintService.reporterAck(organizationId, complaintId, principal.getId(), request));
    }

    @PostMapping("/{complaintId}/admin-close")
    public ApiResponse<ComplaintResponse> adminClose(
            @AuthenticationPrincipal UserPrincipal principal,
            @PathVariable UUID organizationId,
            @PathVariable UUID complaintId,
            @RequestBody(required = false) NoteDto request) {
        return ApiResponse.ok(complaintService.adminClose(organizationId, complaintId, principal.getId(), request));
    }

    @GetMapping("/{complaintId}/events")
    public ApiResponse<List<ComplaintEventResponse>> events(
            @AuthenticationPrincipal UserPrincipal principal,
            @PathVariable UUID organizationId,
            @PathVariable UUID complaintId) {
        return ApiResponse.ok(complaintService.listEvents(organizationId, complaintId, principal.getId()));
    }

    @GetMapping("/{complaintId}/comments")
    public ApiResponse<List<CommentResponse>> comments(
            @AuthenticationPrincipal UserPrincipal principal,
            @PathVariable UUID organizationId,
            @PathVariable UUID complaintId) {
        return ApiResponse.ok(complaintService.listComments(organizationId, complaintId, principal.getId()));
    }

    @PostMapping("/{complaintId}/comments")
    @ResponseStatus(HttpStatus.CREATED)
    public ApiResponse<CommentResponse> addComment(
            @AuthenticationPrincipal UserPrincipal principal,
            @PathVariable UUID organizationId,
            @PathVariable UUID complaintId,
            @Valid @RequestBody CreateCommentDto request) {
        return ApiResponse.ok(complaintService.addComment(organizationId, complaintId, principal.getId(), request));
    }

    @PostMapping("/{complaintId}/support")
    public ApiResponse<ComplaintResponse> support(
            @AuthenticationPrincipal UserPrincipal principal,
            @PathVariable UUID organizationId,
            @PathVariable UUID complaintId) {
        return ApiResponse.ok(complaintService.support(organizationId, complaintId, principal.getId()));
    }

    @GetMapping("/{complaintId}/attachments")
    public ApiResponse<List<AttachmentResponse>> attachments(
            @AuthenticationPrincipal UserPrincipal principal,
            @PathVariable UUID organizationId,
            @PathVariable UUID complaintId) {
        return ApiResponse.ok(complaintService.listAttachments(organizationId, complaintId, principal.getId()));
    }

    @PostMapping(value = "/{complaintId}/attachments", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @ResponseStatus(HttpStatus.CREATED)
    public ApiResponse<AttachmentResponse> uploadAttachment(
            @AuthenticationPrincipal UserPrincipal principal,
            @PathVariable UUID organizationId,
            @PathVariable UUID complaintId,
            @RequestPart("file") MultipartFile file,
            @RequestParam(defaultValue = "EVIDENCE") AttachmentPurpose purpose) {
        return ApiResponse.ok(complaintService.uploadAttachment(
                organizationId, complaintId, principal.getId(), file, purpose));
    }

    @GetMapping("/{complaintId}/attachments/{attachmentId}/download")
    public ResponseEntity<Resource> download(
            @AuthenticationPrincipal UserPrincipal principal,
            @PathVariable UUID organizationId,
            @PathVariable UUID complaintId,
            @PathVariable UUID attachmentId) {
        Resource resource = complaintService.downloadAttachment(
                organizationId, complaintId, attachmentId, principal.getId());
        ComplaintAttachment meta = complaintService.requireAttachmentMeta(organizationId, complaintId, attachmentId);
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + meta.getOriginalName() + "\"")
                .contentType(MediaType.parseMediaType(meta.getContentType()))
                .body(resource);
    }
}
