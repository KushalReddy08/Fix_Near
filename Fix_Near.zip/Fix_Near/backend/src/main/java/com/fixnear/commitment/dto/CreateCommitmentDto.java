package com.fixnear.commitment.dto;

import java.time.Instant;
import java.util.UUID;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public record CreateCommitmentDto(
        @NotBlank @Size(max = 200) String title,
        @NotBlank @Size(max = 5000) String description,
        UUID complaintId,
        Instant dueAt
) {
}
