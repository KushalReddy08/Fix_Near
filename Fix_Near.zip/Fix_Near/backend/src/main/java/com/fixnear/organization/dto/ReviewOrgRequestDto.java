package com.fixnear.organization.dto;

import jakarta.validation.constraints.Size;

public record ReviewOrgRequestDto(
        @Size(max = 1000) String reviewNote
) {
}
