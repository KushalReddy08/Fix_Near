package com.fixnear.complaint.dto;

import com.fixnear.complaint.domain.IdentityMode;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public record CreateComplaintDto(
        @NotBlank @Size(max = 200) String title,
        @NotBlank @Size(max = 5000) String description,
        @NotBlank @Size(max = 100) String category,
        @Size(max = 500) String locationText,
        Double latitude,
        Double longitude,
        IdentityMode identityMode
) {
}
