package com.fixnear.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class OpenApiConfig {

    @Bean
    OpenAPI fixNearOpenApi() {
        return new OpenAPI()
                .info(new Info()
                        .title("FixNear API")
                        .description("FixNear participation and accountability platform")
                        .version("v1"));
    }
}
