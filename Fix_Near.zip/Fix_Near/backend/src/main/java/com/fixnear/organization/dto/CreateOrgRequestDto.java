package com.fixnear.organization.dto;

import com.fixnear.organization.domain.OrganizationType;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public record CreateOrgRequestDto(
        @NotBlank @Size(max = 200) String name,
        @NotNull OrganizationType organizationType,
        @Size(max = 1000) String description,
        @NotBlank @Size(max = 64) String timezone,
        @NotBlank @Size(max = 100) String country,
        @NotBlank @Size(max = 100) String stateProvince,
        @NotBlank @Size(max = 100) String city,
        @NotBlank @Size(max = 500) String addressLine
) {
}
