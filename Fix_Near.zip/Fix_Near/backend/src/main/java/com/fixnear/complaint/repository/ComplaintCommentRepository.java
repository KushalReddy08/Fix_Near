package com.fixnear.complaint.repository;

import java.util.List;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;

import com.fixnear.complaint.domain.ComplaintComment;

public interface ComplaintCommentRepository extends JpaRepository<ComplaintComment, UUID> {

    List<ComplaintComment> findByComplaintIdOrderByCreatedAtAsc(UUID complaintId);
}
