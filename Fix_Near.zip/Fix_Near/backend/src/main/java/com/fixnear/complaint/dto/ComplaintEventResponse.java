package com.fixnear.complaint.dto;

import java.time.Instant;
import java.util.UUID;

import com.fixnear.complaint.domain.ComplaintEvent;
import com.fixnear.complaint.domain.ComplaintStatus;

public record ComplaintEventResponse(
        UUID id,
        String eventType,
        ComplaintStatus fromStatus,
        ComplaintStatus toStatus,
        String note,
        UUID actorId,
        String actorName,
        Instant createdAt
) {

    public static ComplaintEventResponse from(ComplaintEvent event) {
        return new ComplaintEventResponse(
                event.getId(),
                event.getEventType(),
                event.getFromStatus(),
                event.getToStatus(),
                event.getNote(),
                event.getActor() == null ? null : event.getActor().getId(),
                event.getActor() == null ? null : event.getActor().getFullName(),
                event.getCreatedAt());
    }
}
