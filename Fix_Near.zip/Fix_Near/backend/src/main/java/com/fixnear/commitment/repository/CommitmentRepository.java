package com.fixnear.commitment.repository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;

import com.fixnear.commitment.domain.Commitment;

public interface CommitmentRepository extends JpaRepository<Commitment, UUID> {

    List<Commitment> findByOrganizationIdOrderByCreatedAtDesc(UUID organizationId);

    Optional<Commitment> findByIdAndOrganizationId(UUID id, UUID organizationId);
}
