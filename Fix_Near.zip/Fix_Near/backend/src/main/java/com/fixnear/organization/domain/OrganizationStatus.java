package com.fixnear.organization.domain;

public enum OrganizationStatus {
    ACTIVE,
    SUSPENDED
}
