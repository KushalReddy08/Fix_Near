package com.fixnear.sla.repository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;

import com.fixnear.complaint.domain.ComplaintPriority;
import com.fixnear.sla.domain.SlaPolicy;

public interface SlaPolicyRepository extends JpaRepository<SlaPolicy, UUID> {

    List<SlaPolicy> findByOrganizationIdOrderByCategoryAscPriorityAsc(UUID organizationId);

    Optional<SlaPolicy> findByOrganizationIdAndCategoryIgnoreCaseAndPriority(
            UUID organizationId, String category, ComplaintPriority priority);
}
