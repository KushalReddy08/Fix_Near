package com.fixnear.sla.dto;

import java.util.List;
import java.util.Map;

import com.fixnear.complaint.dto.ComplaintResponse;

public record OrgDashboardResponse(
        long openCount,
        long overdueCount,
        Map<String, Long> byStatus,
        List<ComplaintResponse> supportHot
) {
}
