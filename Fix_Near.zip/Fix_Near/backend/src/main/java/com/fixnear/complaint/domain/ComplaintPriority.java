package com.fixnear.complaint.domain;

public enum ComplaintPriority {
    LOW,
    MEDIUM,
    HIGH,
    CRITICAL
}
