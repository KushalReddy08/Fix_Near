package com.fixnear.complaint.repository;

import java.time.Instant;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.fixnear.complaint.domain.Complaint;
import com.fixnear.complaint.domain.ComplaintStatus;
import com.fixnear.organization.domain.OrganizationType;

public interface ComplaintRepository extends JpaRepository<Complaint, UUID> {

    List<Complaint> findByOrganizationIdOrderByCreatedAtDesc(UUID organizationId);

    Optional<Complaint> findByIdAndOrganizationId(UUID id, UUID organizationId);

    long countByOrganizationId(UUID organizationId);

    long countByOrganizationIdAndOverdueTrue(UUID organizationId);

    long countByOrganizationIdAndWorkflowStatus(UUID organizationId, ComplaintStatus workflowStatus);

    List<Complaint> findByOrganizationIdAndOverdueTrueOrderByCreatedAtDesc(UUID organizationId);

    List<Complaint> findTop5ByOrganizationIdOrderBySupportCountDescCreatedAtDesc(UUID organizationId);

    List<Complaint> findByWorkflowStatusNotInAndResolutionDeadlineBefore(
            List<ComplaintStatus> statuses, Instant deadline);

    @Query("""
            select c from Complaint c
            join c.organization o
            where o.organizationType = :type
              and c.latitude is not null
              and c.longitude is not null
            order by c.createdAt desc
            """)
    List<Complaint> findMappedByOrganizationType(OrganizationType type);
}
