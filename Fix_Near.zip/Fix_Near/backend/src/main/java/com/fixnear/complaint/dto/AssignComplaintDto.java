package com.fixnear.complaint.dto;

import java.util.UUID;

import jakarta.validation.constraints.NotNull;

public record AssignComplaintDto(
        @NotNull UUID assigneeUserId,
        UUID departmentId
) {
}
