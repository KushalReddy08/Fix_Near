package com.fixnear.sla.service;

import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.springframework.http.HttpStatus;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.fixnear.common.exception.ApiException;
import com.fixnear.complaint.domain.Complaint;
import com.fixnear.complaint.domain.ComplaintPriority;
import com.fixnear.complaint.domain.ComplaintStatus;
import com.fixnear.complaint.dto.ComplaintResponse;
import com.fixnear.complaint.repository.ComplaintRepository;
import com.fixnear.organization.domain.Organization;
import com.fixnear.organization.repository.OrganizationRepository;
import com.fixnear.organization.service.OrganizationAccessService;
import com.fixnear.sla.domain.SlaPolicy;
import com.fixnear.sla.dto.OrgDashboardResponse;
import com.fixnear.sla.dto.SlaPolicyDto;
import com.fixnear.sla.dto.UpsertSlaPoliciesDto;
import com.fixnear.sla.repository.SlaPolicyRepository;

@Service
public class SlaService {

    private final SlaPolicyRepository slaPolicyRepository;
    private final ComplaintRepository complaintRepository;
    private final OrganizationRepository organizationRepository;
    private final OrganizationAccessService accessService;

    public SlaService(
            SlaPolicyRepository slaPolicyRepository,
            ComplaintRepository complaintRepository,
            OrganizationRepository organizationRepository,
            OrganizationAccessService accessService) {
        this.slaPolicyRepository = slaPolicyRepository;
        this.complaintRepository = complaintRepository;
        this.organizationRepository = organizationRepository;
        this.accessService = accessService;
    }

    public void applyDeadlines(Complaint complaint, Organization organization) {
        int ackHours = 24;
        int resolveHours = defaultResolveHours(complaint.getPriority());
        SlaPolicy policy = slaPolicyRepository
                .findByOrganizationIdAndCategoryIgnoreCaseAndPriority(
                        organization.getId(), complaint.getCategory(), complaint.getPriority())
                .or(() -> slaPolicyRepository.findByOrganizationIdAndCategoryIgnoreCaseAndPriority(
                        organization.getId(), "*", complaint.getPriority()))
                .orElse(null);
        if (policy != null) {
            ackHours = policy.getAcknowledgeHours();
            resolveHours = policy.getResolveHours();
        }
        Instant now = Instant.now();
        complaint.setAcknowledgementDeadline(now.plus(ackHours, ChronoUnit.HOURS));
        complaint.setResolutionDeadline(now.plus(resolveHours, ChronoUnit.HOURS));
    }

    @Transactional(readOnly = true)
    public List<SlaPolicyDto> listPolicies(UUID organizationId, UUID userId) {
        accessService.requireActiveMember(organizationId, userId);
        return slaPolicyRepository.findByOrganizationIdOrderByCategoryAscPriorityAsc(organizationId).stream()
                .map(SlaPolicyDto::from)
                .toList();
    }

    @Transactional
    public List<SlaPolicyDto> upsertPolicies(UUID organizationId, UUID userId, UpsertSlaPoliciesDto dto) {
        accessService.requireLeadership(organizationId, userId);
        Organization organization = organizationRepository.findById(organizationId)
                .orElseThrow(() -> new ApiException("ORG_NOT_FOUND", "Organization not found", HttpStatus.NOT_FOUND));
        List<SlaPolicyDto> saved = new ArrayList<>();
        for (SlaPolicyDto item : dto.policies()) {
            SlaPolicy policy = slaPolicyRepository
                    .findByOrganizationIdAndCategoryIgnoreCaseAndPriority(
                            organizationId, item.category().trim(), item.priority())
                    .orElseGet(SlaPolicy::new);
            policy.setOrganization(organization);
            policy.setCategory(item.category().trim());
            policy.setPriority(item.priority());
            policy.setAcknowledgeHours(item.acknowledgeHours());
            policy.setResolveHours(item.resolveHours());
            slaPolicyRepository.save(policy);
            saved.add(SlaPolicyDto.from(policy));
        }
        return saved;
    }

    @Transactional(readOnly = true)
    public OrgDashboardResponse dashboard(UUID organizationId, UUID userId) {
        accessService.requireActiveMember(organizationId, userId);
        Map<String, Long> byStatus = new LinkedHashMap<>();
        for (ComplaintStatus status : ComplaintStatus.values()) {
            byStatus.put(status.name(), complaintRepository.countByOrganizationIdAndWorkflowStatus(organizationId, status));
        }
        List<ComplaintResponse> hot = complaintRepository
                .findTop5ByOrganizationIdOrderBySupportCountDescCreatedAtDesc(organizationId)
                .stream()
                .map(ComplaintResponse::from)
                .toList();
        long open = complaintRepository.countByOrganizationId(organizationId)
                - byStatus.getOrDefault(ComplaintStatus.CLOSED.name(), 0L)
                - byStatus.getOrDefault(ComplaintStatus.REJECTED.name(), 0L);
        return new OrgDashboardResponse(
                open,
                complaintRepository.countByOrganizationIdAndOverdueTrue(organizationId),
                byStatus,
                hot);
    }

    @Scheduled(fixedDelayString = "${fixnear.sla.overdue-scan-ms:60000}")
    @Transactional
    public void markOverdueComplaints() {
        Instant now = Instant.now();
        List<ComplaintStatus> closed = List.of(ComplaintStatus.CLOSED, ComplaintStatus.REJECTED);
        List<Complaint> candidates = complaintRepository.findByWorkflowStatusNotInAndResolutionDeadlineBefore(closed, now);
        for (Complaint complaint : candidates) {
            if (!complaint.isOverdue()) {
                complaint.setOverdue(true);
            }
        }
    }

    private int defaultResolveHours(ComplaintPriority priority) {
        return switch (priority) {
            case CRITICAL -> 24;
            case HIGH -> 72;
            case MEDIUM -> 120;
            case LOW -> 240;
        };
    }
}
