package com.fixnear.organization.domain;

public enum MemberRole {
    HEAD,
    CO_ADMIN,
    DEPARTMENT_MANAGER,
    OFFICIAL,
    INVESTIGATOR,
    COMMUNITY_MODERATOR,
    MEMBER;

    public boolean isLeadership() {
        return this == HEAD || this == CO_ADMIN;
    }

    public boolean canManageMembers() {
        return this == HEAD || this == CO_ADMIN;
    }

    public boolean canHandleComplaints() {
        return this == HEAD
                || this == CO_ADMIN
                || this == DEPARTMENT_MANAGER
                || this == OFFICIAL
                || this == INVESTIGATOR;
    }
}
