package com.fixnear.commitment.controller;

import java.util.List;
import java.util.UUID;

import org.springframework.http.HttpStatus;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.fixnear.commitment.dto.CommitmentResponse;
import com.fixnear.commitment.dto.CompleteCommitmentDto;
import com.fixnear.commitment.dto.CreateCommitmentDto;
import com.fixnear.commitment.service.CommitmentService;
import com.fixnear.common.api.ApiResponse;
import com.fixnear.security.UserPrincipal;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/v1/organizations/{organizationId}/commitments")
public class CommitmentController {

    private final CommitmentService commitmentService;

    public CommitmentController(CommitmentService commitmentService) {
        this.commitmentService = commitmentService;
    }

    @GetMapping
    public ApiResponse<List<CommitmentResponse>> list(
            @AuthenticationPrincipal UserPrincipal principal,
            @PathVariable UUID organizationId) {
        return ApiResponse.ok(commitmentService.list(organizationId, principal.getId()));
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public ApiResponse<CommitmentResponse> create(
            @AuthenticationPrincipal UserPrincipal principal,
            @PathVariable UUID organizationId,
            @Valid @RequestBody CreateCommitmentDto request) {
        return ApiResponse.ok(commitmentService.create(organizationId, principal.getId(), request));
    }

    @PostMapping("/{commitmentId}/complete")
    public ApiResponse<CommitmentResponse> complete(
            @AuthenticationPrincipal UserPrincipal principal,
            @PathVariable UUID organizationId,
            @PathVariable UUID commitmentId,
            @RequestBody(required = false) CompleteCommitmentDto request) {
        return ApiResponse.ok(commitmentService.complete(
                organizationId, commitmentId, principal.getId(), request == null ? new CompleteCommitmentDto(null) : request));
    }
}
