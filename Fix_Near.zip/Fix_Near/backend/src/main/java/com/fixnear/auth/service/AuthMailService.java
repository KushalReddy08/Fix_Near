package com.fixnear.auth.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import com.fixnear.config.AuthProperties;

@Service
public class AuthMailService {

    private static final Logger log = LoggerFactory.getLogger(AuthMailService.class);

    private final JavaMailSender mailSender;
    private final AuthProperties authProperties;
    private final String fromAddress;

    public AuthMailService(
            JavaMailSender mailSender,
            AuthProperties authProperties,
            @Value("${fixnear.mail.from:FixNear <noreply@fixnear.local>}") String fromAddress) {
        this.mailSender = mailSender;
        this.authProperties = authProperties;
        this.fromAddress = fromAddress;
    }

    public void sendVerificationEmail(String toEmail, String rawToken) {
        String verifyUrl = authProperties.getEmailVerification().getFrontendBaseUrl()
                + "/verify-email?token=" + rawToken;

        log.info("Sending verification email to {} (link also logged for local debugging): {}", toEmail, verifyUrl);

        SimpleMailMessage message = new SimpleMailMessage();
        message.setFrom(fromAddress);
        message.setTo(toEmail);
        message.setSubject("Verify your FixNear account");
        message.setText("""
                Welcome to FixNear.

                A system-generated verification was requested for this email address.

                Verify your account by opening this link:
                %s

                Or paste this token on the Verify Email page:
                %s

                If you did not create a FixNear account, you can ignore this email.
                """.formatted(verifyUrl, rawToken));

        try {
            mailSender.send(message);
            log.info("Verification email accepted by SMTP for {}", toEmail);
        } catch (Exception ex) {
            log.error("Failed to send verification email to {}: {}", toEmail, ex.getMessage());
            throw new IllegalStateException(
                    "Could not send verification email. Ensure Mailpit/SMTP is running on "
                            + "the configured mail host.",
                    ex);
        }
    }
}
