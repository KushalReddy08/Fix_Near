package com.fixnear.user.domain;

public enum PlatformRole {
    USER,
    PLATFORM_ADMIN
}
