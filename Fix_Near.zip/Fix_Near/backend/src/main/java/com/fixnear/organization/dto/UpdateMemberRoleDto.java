package com.fixnear.organization.dto;

import com.fixnear.organization.domain.MemberRole;

import jakarta.validation.constraints.NotNull;

public record UpdateMemberRoleDto(
        @NotNull MemberRole memberRole
) {
}
