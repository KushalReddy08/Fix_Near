package com.fixnear.notification.service;

import java.time.Instant;
import java.util.List;
import java.util.UUID;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.fixnear.common.exception.ApiException;
import com.fixnear.notification.domain.Notification;
import com.fixnear.notification.dto.NotificationResponse;
import com.fixnear.notification.repository.NotificationRepository;

@Service
public class NotificationService {

    private final NotificationRepository notificationRepository;

    public NotificationService(NotificationRepository notificationRepository) {
        this.notificationRepository = notificationRepository;
    }

    @Transactional
    public void notify(UUID userId, UUID organizationId, UUID complaintId, String title, String body) {
        Notification notification = new Notification();
        notification.setUserId(userId);
        notification.setOrganizationId(organizationId);
        notification.setComplaintId(complaintId);
        notification.setTitle(title);
        notification.setBody(body);
        notificationRepository.save(notification);
    }

    @Transactional(readOnly = true)
    public List<NotificationResponse> listForUser(UUID userId) {
        return notificationRepository.findByUserIdOrderByCreatedAtDesc(userId).stream()
                .map(NotificationResponse::from)
                .toList();
    }

    @Transactional
    public NotificationResponse markRead(UUID userId, UUID notificationId) {
        Notification notification = notificationRepository.findByIdAndUserId(notificationId, userId)
                .orElseThrow(() -> new ApiException("NOT_FOUND", "Notification not found", HttpStatus.NOT_FOUND));
        if (notification.getReadAt() == null) {
            notification.setReadAt(Instant.now());
        }
        return NotificationResponse.from(notification);
    }
}
