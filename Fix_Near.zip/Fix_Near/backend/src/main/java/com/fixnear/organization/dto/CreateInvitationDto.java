package com.fixnear.organization.dto;

import com.fixnear.organization.domain.MemberRole;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public record CreateInvitationDto(
        @Email @Size(max = 320) String invitedEmail,
        @NotNull MemberRole memberRole
) {
}
