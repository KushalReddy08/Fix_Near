package com.fixnear.complaint.domain;

public enum CommentVisibility {
    PUBLIC,
    INTERNAL,
    REPORTER_THREAD
}
