package com.fixnear.complaint.domain;

public enum IdentityMode {
    NAMED,
    CONFIDENTIAL,
    ANONYMOUS
}
