package com.fixnear.complaint.service;

import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.EnumSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;

import org.springframework.core.io.Resource;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.fixnear.common.exception.ApiException;
import com.fixnear.complaint.domain.AttachmentPurpose;
import com.fixnear.complaint.domain.CommentVisibility;
import com.fixnear.complaint.domain.Complaint;
import com.fixnear.complaint.domain.ComplaintAttachment;
import com.fixnear.complaint.domain.ComplaintComment;
import com.fixnear.complaint.domain.ComplaintEvent;
import com.fixnear.complaint.domain.ComplaintPriority;
import com.fixnear.complaint.domain.ComplaintStatus;
import com.fixnear.complaint.domain.ComplaintSupport;
import com.fixnear.complaint.domain.IdentityMode;
import com.fixnear.complaint.dto.AssignComplaintDto;
import com.fixnear.complaint.dto.AttachmentResponse;
import com.fixnear.complaint.dto.CommentResponse;
import com.fixnear.complaint.dto.ComplaintEventResponse;
import com.fixnear.complaint.dto.ComplaintResponse;
import com.fixnear.complaint.dto.CreateCommentDto;
import com.fixnear.complaint.dto.CreateComplaintDto;
import com.fixnear.complaint.dto.NoteDto;
import com.fixnear.complaint.dto.ReporterAckDto;
import com.fixnear.complaint.dto.ResolveComplaintDto;
import com.fixnear.complaint.repository.ComplaintAttachmentRepository;
import com.fixnear.complaint.repository.ComplaintCommentRepository;
import com.fixnear.complaint.repository.ComplaintEventRepository;
import com.fixnear.complaint.repository.ComplaintRepository;
import com.fixnear.complaint.repository.ComplaintSupportRepository;
import com.fixnear.notification.service.NotificationService;
import com.fixnear.organization.domain.Department;
import com.fixnear.organization.domain.MemberRole;
import com.fixnear.organization.domain.Organization;
import com.fixnear.organization.domain.OrganizationMember;
import com.fixnear.organization.domain.OrganizationType;
import com.fixnear.organization.repository.DepartmentRepository;
import com.fixnear.organization.repository.OrganizationRepository;
import com.fixnear.organization.service.OrganizationAccessService;
import com.fixnear.sla.service.SlaService;
import com.fixnear.user.domain.User;
import com.fixnear.user.repository.UserRepository;

@Service
public class ComplaintService {

    private static final Set<String> SAFETY_CATEGORIES = Set.of("safety", "security", "hazard");
    private static final EnumSet<ComplaintStatus> TERMINAL = EnumSet.of(
            ComplaintStatus.CLOSED, ComplaintStatus.REJECTED);

    private final ComplaintRepository complaintRepository;
    private final ComplaintEventRepository eventRepository;
    private final ComplaintCommentRepository commentRepository;
    private final ComplaintAttachmentRepository attachmentRepository;
    private final ComplaintSupportRepository supportRepository;
    private final OrganizationRepository organizationRepository;
    private final DepartmentRepository departmentRepository;
    private final UserRepository userRepository;
    private final OrganizationAccessService accessService;
    private final AttachmentStorageService storageService;
    private final SlaService slaService;
    private final NotificationService notificationService;

    public ComplaintService(
            ComplaintRepository complaintRepository,
            ComplaintEventRepository eventRepository,
            ComplaintCommentRepository commentRepository,
            ComplaintAttachmentRepository attachmentRepository,
            ComplaintSupportRepository supportRepository,
            OrganizationRepository organizationRepository,
            DepartmentRepository departmentRepository,
            UserRepository userRepository,
            OrganizationAccessService accessService,
            AttachmentStorageService storageService,
            SlaService slaService,
            NotificationService notificationService) {
        this.complaintRepository = complaintRepository;
        this.eventRepository = eventRepository;
        this.commentRepository = commentRepository;
        this.attachmentRepository = attachmentRepository;
        this.supportRepository = supportRepository;
        this.organizationRepository = organizationRepository;
        this.departmentRepository = departmentRepository;
        this.userRepository = userRepository;
        this.accessService = accessService;
        this.storageService = storageService;
        this.slaService = slaService;
        this.notificationService = notificationService;
    }

    @Transactional
    public ComplaintResponse create(UUID organizationId, UUID reporterId, CreateComplaintDto dto) {
        accessService.requireActiveMember(organizationId, reporterId);
        Organization organization = organizationRepository.findById(organizationId)
                .orElseThrow(() -> new ApiException("ORG_NOT_FOUND", "Organization not found", HttpStatus.NOT_FOUND));
        User reporter = userRepository.findById(reporterId)
                .orElseThrow(() -> new ApiException("USER_NOT_FOUND", "User not found", HttpStatus.NOT_FOUND));

        IdentityMode identityMode = dto.identityMode() == null ? IdentityMode.NAMED : dto.identityMode();
        ComplaintPriority priority = assignPriority(dto.category());

        Complaint complaint = new Complaint();
        complaint.setOrganization(organization);
        complaint.setReporter(reporter);
        complaint.setTitle(dto.title().trim());
        complaint.setDescription(dto.description().trim());
        complaint.setCategory(dto.category().trim());
        complaint.setPriority(priority);
        complaint.setWorkflowStatus(ComplaintStatus.SUBMITTED);
        complaint.setIdentityMode(identityMode);
        complaint.setOverdue(false);
        complaint.setLocationText(blankToNull(dto.locationText()));
        complaint.setLatitude(dto.latitude());
        complaint.setLongitude(dto.longitude());
        slaService.applyDeadlines(complaint, organization);
        complaintRepository.save(complaint);

        recordEvent(complaint, reporter, "CREATED", null, ComplaintStatus.SUBMITTED, "Complaint registered");
        return toResponse(complaint, reporterId);
    }

    @Transactional(readOnly = true)
    public List<ComplaintResponse> listForOrganization(UUID organizationId, UUID userId) {
        OrganizationMember member = accessService.requireActiveMember(organizationId, userId);
        boolean reveal = member.getMemberRole().canHandleComplaints();
        return complaintRepository.findByOrganizationIdOrderByCreatedAtDesc(organizationId).stream()
                .map(c -> ComplaintResponse.from(c, reveal || c.getReporter().getId().equals(userId)))
                .toList();
    }

    @Transactional(readOnly = true)
    public ComplaintResponse get(UUID organizationId, UUID complaintId, UUID userId) {
        OrganizationMember member = accessService.requireActiveMember(organizationId, userId);
        Complaint complaint = requireComplaint(organizationId, complaintId);
        boolean reveal = member.getMemberRole().canHandleComplaints()
                || complaint.getReporter().getId().equals(userId);
        return ComplaintResponse.from(complaint, reveal);
    }

    @Transactional
    public ComplaintResponse acknowledge(UUID organizationId, UUID complaintId, UUID actorId) {
        accessService.requireComplaintHandler(organizationId, actorId);
        Complaint complaint = requireComplaint(organizationId, complaintId);
        transition(complaint, actorId, ComplaintStatus.ACKNOWLEDGED, "Acknowledged by official", Set.of(
                ComplaintStatus.SUBMITTED, ComplaintStatus.REOPENED));
        complaint.setAcknowledgedAt(Instant.now());
        notifyReporter(complaint, "Complaint acknowledged", "Your complaint was acknowledged by an official.");
        return toResponse(complaint, actorId);
    }

    @Transactional
    public ComplaintResponse assign(UUID organizationId, UUID complaintId, UUID actorId, AssignComplaintDto dto) {
        accessService.requireComplaintHandler(organizationId, actorId);
        Complaint complaint = requireComplaint(organizationId, complaintId);
        User assignee = userRepository.findById(dto.assigneeUserId())
                .orElseThrow(() -> new ApiException("USER_NOT_FOUND", "Assignee not found", HttpStatus.NOT_FOUND));
        accessService.requireActiveMember(organizationId, assignee.getId());

        if (dto.departmentId() != null) {
            Department department = departmentRepository.findById(dto.departmentId())
                    .orElseThrow(() -> new ApiException("DEPT_NOT_FOUND", "Department not found", HttpStatus.NOT_FOUND));
            if (!department.getOrganization().getId().equals(organizationId)) {
                throw new ApiException("DEPT_NOT_FOUND", "Department not found", HttpStatus.NOT_FOUND);
            }
            complaint.setDepartment(department);
        }

        ComplaintStatus from = complaint.getWorkflowStatus();
        ensureTransition(from, Set.of(
                ComplaintStatus.SUBMITTED, ComplaintStatus.ACKNOWLEDGED, ComplaintStatus.ASSIGNED, ComplaintStatus.REOPENED));
        complaint.setAssignee(assignee);
        complaint.setWorkflowStatus(ComplaintStatus.ASSIGNED);
        if (complaint.getAcknowledgedAt() == null) {
            complaint.setAcknowledgedAt(Instant.now());
        }
        recordEvent(complaint, loadUser(actorId), "ASSIGNED", from, ComplaintStatus.ASSIGNED,
                "Assigned to " + assignee.getFullName());
        notificationService.notify(
                assignee.getId(),
                organizationId,
                complaint.getId(),
                "Complaint assigned",
                "You were assigned: " + complaint.getTitle());
        return toResponse(complaint, actorId);
    }

    @Transactional
    public ComplaintResponse start(UUID organizationId, UUID complaintId, UUID actorId) {
        accessService.requireComplaintHandler(organizationId, actorId);
        Complaint complaint = requireComplaint(organizationId, complaintId);
        transition(complaint, actorId, ComplaintStatus.IN_PROGRESS, "Work started", Set.of(
                ComplaintStatus.ASSIGNED, ComplaintStatus.ACKNOWLEDGED, ComplaintStatus.REOPENED));
        return toResponse(complaint, actorId);
    }

    @Transactional
    public ComplaintResponse resolve(UUID organizationId, UUID complaintId, UUID actorId, ResolveComplaintDto dto) {
        accessService.requireComplaintHandler(organizationId, actorId);
        Complaint complaint = requireComplaint(organizationId, complaintId);
        transition(complaint, actorId, ComplaintStatus.RESOLVED, dto.resolutionNote(), Set.of(
                ComplaintStatus.IN_PROGRESS, ComplaintStatus.ASSIGNED, ComplaintStatus.ACKNOWLEDGED));
        complaint.setResolvedAt(Instant.now());
        complaint.setResolutionNote(dto.resolutionNote().trim());
        notifyReporter(complaint, "Resolution claimed", "An official marked your complaint resolved. Please confirm.");
        return toResponse(complaint, actorId);
    }

    @Transactional
    public ComplaintResponse reject(UUID organizationId, UUID complaintId, UUID actorId, NoteDto dto) {
        accessService.requireComplaintHandler(organizationId, actorId);
        Complaint complaint = requireComplaint(organizationId, complaintId);
        transition(complaint, actorId, ComplaintStatus.REJECTED, blankToNull(dto == null ? null : dto.note()), Set.of(
                ComplaintStatus.SUBMITTED,
                ComplaintStatus.ACKNOWLEDGED,
                ComplaintStatus.ASSIGNED,
                ComplaintStatus.IN_PROGRESS,
                ComplaintStatus.REOPENED));
        complaint.setClosedAt(Instant.now());
        notifyReporter(complaint, "Complaint rejected", "Your complaint was rejected by an official.");
        return toResponse(complaint, actorId);
    }

    @Transactional
    public ComplaintResponse reporterAck(UUID organizationId, UUID complaintId, UUID actorId, ReporterAckDto dto) {
        accessService.requireActiveMember(organizationId, actorId);
        Complaint complaint = requireComplaint(organizationId, complaintId);
        if (!complaint.getReporter().getId().equals(actorId)) {
            throw new ApiException("ONLY_REPORTER", "Only the reporter can verify resolution", HttpStatus.FORBIDDEN);
        }
        if (complaint.getWorkflowStatus() != ComplaintStatus.RESOLVED) {
            throw new ApiException("INVALID_STATE", "Complaint is not awaiting reporter verification", HttpStatus.CONFLICT);
        }
        if (Boolean.TRUE.equals(dto.accept())) {
            transition(complaint, actorId, ComplaintStatus.CLOSED, blankToNull(dto.note()), Set.of(ComplaintStatus.RESOLVED));
            complaint.setClosedAt(Instant.now());
        } else {
            transition(complaint, actorId, ComplaintStatus.REOPENED, blankToNull(dto.note()), Set.of(ComplaintStatus.RESOLVED));
            complaint.setReopenCount(complaint.getReopenCount() + 1);
            complaint.setResolvedAt(null);
            complaint.setClosedAt(null);
            if (complaint.getAssignee() != null) {
                notificationService.notify(
                        complaint.getAssignee().getId(),
                        organizationId,
                        complaint.getId(),
                        "Complaint reopened",
                        "Reporter rejected the resolution for: " + complaint.getTitle());
            }
        }
        return toResponse(complaint, actorId);
    }

    @Transactional
    public ComplaintResponse adminClose(UUID organizationId, UUID complaintId, UUID actorId, NoteDto dto) {
        accessService.requireLeadership(organizationId, actorId);
        Complaint complaint = requireComplaint(organizationId, complaintId);
        transition(complaint, actorId, ComplaintStatus.CLOSED, blankToNull(dto == null ? null : dto.note()), Set.of(
                ComplaintStatus.SUBMITTED,
                ComplaintStatus.ACKNOWLEDGED,
                ComplaintStatus.ASSIGNED,
                ComplaintStatus.IN_PROGRESS,
                ComplaintStatus.RESOLVED,
                ComplaintStatus.REOPENED,
                ComplaintStatus.REJECTED));
        complaint.setClosedAt(Instant.now());
        return toResponse(complaint, actorId);
    }

    @Transactional(readOnly = true)
    public List<ComplaintEventResponse> listEvents(UUID organizationId, UUID complaintId, UUID userId) {
        accessService.requireActiveMember(organizationId, userId);
        requireComplaint(organizationId, complaintId);
        return eventRepository.findByComplaintIdOrderByCreatedAtAsc(complaintId).stream()
                .map(ComplaintEventResponse::from)
                .toList();
    }

    @Transactional(readOnly = true)
    public List<CommentResponse> listComments(UUID organizationId, UUID complaintId, UUID userId) {
        OrganizationMember member = accessService.requireActiveMember(organizationId, userId);
        Complaint complaint = requireComplaint(organizationId, complaintId);
        boolean handler = member.getMemberRole().canHandleComplaints();
        boolean reporter = complaint.getReporter().getId().equals(userId);
        return commentRepository.findByComplaintIdOrderByCreatedAtAsc(complaintId).stream()
                .filter(comment -> visible(comment.getVisibility(), handler, reporter))
                .map(CommentResponse::from)
                .toList();
    }

    @Transactional
    public CommentResponse addComment(UUID organizationId, UUID complaintId, UUID userId, CreateCommentDto dto) {
        OrganizationMember member = accessService.requireActiveMember(organizationId, userId);
        Complaint complaint = requireComplaint(organizationId, complaintId);
        boolean handler = member.getMemberRole().canHandleComplaints();
        boolean reporter = complaint.getReporter().getId().equals(userId);
        if (dto.visibility() == CommentVisibility.INTERNAL && !handler) {
            throw new ApiException("FORBIDDEN", "Only officials can post internal comments", HttpStatus.FORBIDDEN);
        }
        if (dto.visibility() == CommentVisibility.REPORTER_THREAD && !(handler || reporter)) {
            throw new ApiException("FORBIDDEN", "Not allowed for this thread", HttpStatus.FORBIDDEN);
        }

        ComplaintComment comment = new ComplaintComment();
        comment.setComplaintId(complaintId);
        comment.setOrganizationId(organizationId);
        comment.setAuthor(loadUser(userId));
        comment.setBody(dto.body().trim());
        comment.setVisibility(dto.visibility());
        commentRepository.save(comment);
        recordEvent(complaint, comment.getAuthor(), "COMMENT", complaint.getWorkflowStatus(),
                complaint.getWorkflowStatus(), "Comment added (" + dto.visibility() + ")");
        return CommentResponse.from(comment);
    }

    @Transactional
    public ComplaintResponse support(UUID organizationId, UUID complaintId, UUID userId) {
        accessService.requireActiveMember(organizationId, userId);
        Complaint complaint = requireComplaint(organizationId, complaintId);
        if (supportRepository.existsByComplaintIdAndUserId(complaintId, userId)) {
            supportRepository.findByComplaintIdAndUserId(complaintId, userId).ifPresent(supportRepository::delete);
            complaint.setSupportCount(Math.max(0, complaint.getSupportCount() - 1));
        } else {
            ComplaintSupport support = new ComplaintSupport();
            support.setComplaintId(complaintId);
            support.setOrganizationId(organizationId);
            support.setUserId(userId);
            supportRepository.save(support);
            complaint.setSupportCount(complaint.getSupportCount() + 1);
        }
        return toResponse(complaint, userId);
    }

    @Transactional
    public AttachmentResponse uploadAttachment(
            UUID organizationId,
            UUID complaintId,
            UUID userId,
            MultipartFile file,
            AttachmentPurpose purpose) {
        accessService.requireActiveMember(organizationId, userId);
        Complaint complaint = requireComplaint(organizationId, complaintId);
        long count = attachmentRepository.countByComplaintId(complaintId);
        if (count >= AttachmentStorageService.MAX_PER_COMPLAINT) {
            throw new ApiException("ATTACHMENT_LIMIT", "Max 5 attachments per complaint", HttpStatus.BAD_REQUEST);
        }
        String key = storageService.store(organizationId, complaintId, file);
        ComplaintAttachment attachment = new ComplaintAttachment();
        attachment.setComplaintId(complaintId);
        attachment.setOrganizationId(organizationId);
        attachment.setUploader(loadUser(userId));
        attachment.setOriginalName(file.getOriginalFilename() == null ? "file" : file.getOriginalFilename());
        attachment.setStorageKey(key);
        attachment.setContentType(file.getContentType());
        attachment.setSizeBytes(file.getSize());
        attachment.setPurpose(purpose == null ? AttachmentPurpose.EVIDENCE : purpose);
        attachmentRepository.save(attachment);
        recordEvent(complaint, attachment.getUploader(), "ATTACHMENT", complaint.getWorkflowStatus(),
                complaint.getWorkflowStatus(), "Uploaded " + attachment.getOriginalName());
        return AttachmentResponse.from(attachment);
    }

    @Transactional(readOnly = true)
    public List<AttachmentResponse> listAttachments(UUID organizationId, UUID complaintId, UUID userId) {
        accessService.requireActiveMember(organizationId, userId);
        requireComplaint(organizationId, complaintId);
        return attachmentRepository.findByComplaintIdOrderByCreatedAtAsc(complaintId).stream()
                .map(AttachmentResponse::from)
                .toList();
    }

    @Transactional(readOnly = true)
    public Resource downloadAttachment(UUID organizationId, UUID complaintId, UUID attachmentId, UUID userId) {
        accessService.requireActiveMember(organizationId, userId);
        requireComplaint(organizationId, complaintId);
        ComplaintAttachment attachment = attachmentRepository
                .findByIdAndComplaintIdAndOrganizationId(attachmentId, complaintId, organizationId)
                .orElseThrow(() -> new ApiException("NOT_FOUND", "Attachment not found", HttpStatus.NOT_FOUND));
        return storageService.loadAsResource(attachment.getStorageKey());
    }

    @Transactional(readOnly = true)
    public ComplaintAttachment requireAttachmentMeta(UUID organizationId, UUID complaintId, UUID attachmentId) {
        return attachmentRepository
                .findByIdAndComplaintIdAndOrganizationId(attachmentId, complaintId, organizationId)
                .orElseThrow(() -> new ApiException("NOT_FOUND", "Attachment not found", HttpStatus.NOT_FOUND));
    }

    @Transactional(readOnly = true)
    public List<ComplaintResponse> civicMap(UUID userId) {
        // Authenticated users can browse civic mapped complaints (no private org leakage).
        userRepository.findById(userId)
                .orElseThrow(() -> new ApiException("USER_NOT_FOUND", "User not found", HttpStatus.NOT_FOUND));
        return complaintRepository.findMappedByOrganizationType(OrganizationType.CIVIC).stream()
                .map(c -> ComplaintResponse.from(c, false))
                .toList();
    }

    private void transition(
            Complaint complaint,
            UUID actorId,
            ComplaintStatus to,
            String note,
            Set<ComplaintStatus> allowedFrom) {
        ComplaintStatus from = complaint.getWorkflowStatus();
        ensureTransition(from, allowedFrom);
        complaint.setWorkflowStatus(to);
        recordEvent(complaint, loadUser(actorId), "STATUS_CHANGE", from, to, note);
    }

    private void ensureTransition(ComplaintStatus from, Set<ComplaintStatus> allowedFrom) {
        if (!allowedFrom.contains(from)) {
            throw new ApiException(
                    "INVALID_TRANSITION",
                    "Cannot transition from status " + from,
                    HttpStatus.CONFLICT);
        }
        if (TERMINAL.contains(from) && from != ComplaintStatus.REJECTED) {
            throw new ApiException("INVALID_TRANSITION", "Complaint is already closed", HttpStatus.CONFLICT);
        }
    }

    private void recordEvent(
            Complaint complaint,
            User actor,
            String eventType,
            ComplaintStatus from,
            ComplaintStatus to,
            String note) {
        ComplaintEvent event = new ComplaintEvent();
        event.setComplaintId(complaint.getId());
        event.setOrganizationId(complaint.getOrganization().getId());
        event.setActor(actor);
        event.setEventType(eventType);
        event.setFromStatus(from);
        event.setToStatus(to);
        event.setNote(note);
        eventRepository.save(event);
    }

    private Complaint requireComplaint(UUID organizationId, UUID complaintId) {
        return complaintRepository.findByIdAndOrganizationId(complaintId, organizationId)
                .orElseThrow(() -> new ApiException("COMPLAINT_NOT_FOUND", "Complaint not found", HttpStatus.NOT_FOUND));
    }

    private User loadUser(UUID userId) {
        return userRepository.findById(userId)
                .orElseThrow(() -> new ApiException("USER_NOT_FOUND", "User not found", HttpStatus.NOT_FOUND));
    }

    private ComplaintResponse toResponse(Complaint complaint, UUID viewerId) {
        OrganizationMember member = accessService.requireActiveMember(
                complaint.getOrganization().getId(), viewerId);
        boolean reveal = member.getMemberRole().canHandleComplaints()
                || complaint.getReporter().getId().equals(viewerId)
                || member.getMemberRole() == MemberRole.COMMUNITY_MODERATOR;
        return ComplaintResponse.from(complaint, reveal);
    }

    private void notifyReporter(Complaint complaint, String title, String body) {
        notificationService.notify(
                complaint.getReporter().getId(),
                complaint.getOrganization().getId(),
                complaint.getId(),
                title,
                body);
    }

    private boolean visible(CommentVisibility visibility, boolean handler, boolean reporter) {
        return switch (visibility) {
            case PUBLIC -> true;
            case INTERNAL -> handler;
            case REPORTER_THREAD -> handler || reporter;
        };
    }

    private ComplaintPriority assignPriority(String category) {
        String normalized = category.trim().toLowerCase(Locale.ROOT);
        if (SAFETY_CATEGORIES.contains(normalized)) {
            return ComplaintPriority.CRITICAL;
        }
        if (normalized.contains("water") || normalized.contains("electric") || normalized.contains("wifi")) {
            return ComplaintPriority.HIGH;
        }
        return ComplaintPriority.MEDIUM;
    }

    private String blankToNull(String value) {
        if (value == null || value.trim().isEmpty()) {
            return null;
        }
        return value.trim();
    }
}
