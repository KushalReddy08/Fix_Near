package com.fixnear.organization.domain;

public enum OrgRequestStatus {
    PENDING,
    APPROVED,
    REJECTED
}
