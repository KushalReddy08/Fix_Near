package com.fixnear.complaint.dto;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public record ReporterAckDto(
        @NotNull Boolean accept,
        @Size(max = 5000) String note
) {
}
