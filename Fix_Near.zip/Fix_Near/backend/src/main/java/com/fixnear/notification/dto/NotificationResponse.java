package com.fixnear.notification.dto;

import java.time.Instant;
import java.util.UUID;

import com.fixnear.notification.domain.Notification;

public record NotificationResponse(
        UUID id,
        UUID organizationId,
        UUID complaintId,
        String title,
        String body,
        Instant readAt,
        Instant createdAt
) {

    public static NotificationResponse from(Notification notification) {
        return new NotificationResponse(
                notification.getId(),
                notification.getOrganizationId(),
                notification.getComplaintId(),
                notification.getTitle(),
                notification.getBody(),
                notification.getReadAt(),
                notification.getCreatedAt());
    }
}
