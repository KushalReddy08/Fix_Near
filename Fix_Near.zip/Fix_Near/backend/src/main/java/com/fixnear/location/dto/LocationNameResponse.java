package com.fixnear.location.dto;

import java.util.List;

public record LocationNameResponse(List<String> items) {
}
