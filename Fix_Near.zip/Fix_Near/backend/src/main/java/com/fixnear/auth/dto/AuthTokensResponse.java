package com.fixnear.auth.dto;

import com.fixnear.user.dto.UserResponse;

public record AuthTokensResponse(
        String accessToken,
        String tokenType,
        long expiresInSeconds,
        UserResponse user
) {
}
