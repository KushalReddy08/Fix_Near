package com.fixnear.organization.repository;

import java.util.List;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;

import com.fixnear.organization.domain.OrgRequestStatus;
import com.fixnear.organization.domain.OrganizationCreationRequest;

public interface OrganizationCreationRequestRepository extends JpaRepository<OrganizationCreationRequest, UUID> {

    List<OrganizationCreationRequest> findByRequesterIdOrderByCreatedAtDesc(UUID requesterId);

    List<OrganizationCreationRequest> findByStatusOrderByCreatedAtAsc(OrgRequestStatus status);

    boolean existsByRequesterIdAndStatus(UUID requesterId, OrgRequestStatus status);
}
