package com.fixnear.complaint.dto;

import java.time.Instant;
import java.util.UUID;

import com.fixnear.complaint.domain.CommentVisibility;
import com.fixnear.complaint.domain.ComplaintComment;

public record CommentResponse(
        UUID id,
        UUID authorId,
        String authorName,
        String body,
        CommentVisibility visibility,
        Instant createdAt
) {

    public static CommentResponse from(ComplaintComment comment) {
        return new CommentResponse(
                comment.getId(),
                comment.getAuthor().getId(),
                comment.getAuthor().getFullName(),
                comment.getBody(),
                comment.getVisibility(),
                comment.getCreatedAt());
    }
}
