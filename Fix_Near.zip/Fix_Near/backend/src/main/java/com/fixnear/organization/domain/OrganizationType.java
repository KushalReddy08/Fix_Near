package com.fixnear.organization.domain;

public enum OrganizationType {
    COLLEGE,
    CORPORATE,
    RESIDENTIAL,
    CIVIC
}
