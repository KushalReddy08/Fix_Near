package com.fixnear.organization.service;

import java.util.Optional;
import java.util.UUID;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.fixnear.common.exception.ApiException;
import com.fixnear.organization.domain.MemberRole;
import com.fixnear.organization.domain.OrganizationMember;
import com.fixnear.organization.repository.OrganizationMemberRepository;
import com.fixnear.security.UserPrincipal;
import com.fixnear.user.domain.PlatformRole;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class OrganizationAccessServiceTest {

    @Mock
    private OrganizationMemberRepository memberRepository;

    @InjectMocks
    private OrganizationAccessService accessService;

    @Test
    void requireActiveMemberRejectsOutsiders() {
        UUID orgId = UUID.randomUUID();
        UUID userId = UUID.randomUUID();
        when(memberRepository.findByOrganizationIdAndUserIdAndRevokedAtIsNull(orgId, userId))
                .thenReturn(Optional.empty());

        ApiException ex = assertThrows(ApiException.class, () -> accessService.requireActiveMember(orgId, userId));
        assertEquals("ORG_ACCESS_DENIED", ex.getCode());
    }

    @Test
    void ensureCoAdminCapBlocksFifth() {
        UUID orgId = UUID.randomUUID();
        when(memberRepository.countByOrganizationIdAndMemberRoleAndRevokedAtIsNull(orgId, MemberRole.CO_ADMIN))
                .thenReturn(4L);

        ApiException ex = assertThrows(
                ApiException.class, () -> accessService.ensureCoAdminCap(orgId, MemberRole.CO_ADMIN));
        assertEquals("CO_ADMIN_LIMIT_REACHED", ex.getCode());
    }

    @Test
    void requirePlatformAdminRejectsNormalUser() {
        UserPrincipal principal = new UserPrincipal(
                UUID.randomUUID(), "u@example.com", "x", PlatformRole.USER, true);
        ApiException ex = assertThrows(ApiException.class, () -> accessService.requirePlatformAdmin(principal));
        assertEquals("PLATFORM_ADMIN_REQUIRED", ex.getCode());
    }

    @Test
    void requireLeadershipRejectsMember() {
        UUID orgId = UUID.randomUUID();
        UUID userId = UUID.randomUUID();
        OrganizationMember member = new OrganizationMember();
        member.setMemberRole(MemberRole.MEMBER);
        when(memberRepository.findByOrganizationIdAndUserIdAndRevokedAtIsNull(orgId, userId))
                .thenReturn(Optional.of(member));

        ApiException ex = assertThrows(ApiException.class, () -> accessService.requireLeadership(orgId, userId));
        assertEquals("ORG_LEADERSHIP_REQUIRED", ex.getCode());
    }
}
