package com.fixnear.location;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.condition.EnabledIfEnvironmentVariable;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.fixnear.location.service.LocationService;

@SpringBootTest
@EnabledIfEnvironmentVariable(named = "FIXNEAR_LIVE_LOCATION_IT", matches = "true")
class LocationServiceIT {

    @Autowired
    private LocationService locationService;

    @Test
    void cascadesCountryStateCity() {
        List<String> countries = locationService.listCountries();
        assertThat(countries).isNotEmpty().contains("India");

        List<String> states = locationService.listStates("India");
        assertThat(states).isNotEmpty().anyMatch(name -> name.contains("Karnataka"));

        List<String> cities = locationService.listCities("India", "Karnataka");
        assertThat(cities).isNotEmpty();
    }
}
