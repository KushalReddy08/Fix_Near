package com.fixnear.auth.util;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;

class TokenHasherTest {

    @Test
    void sha256IsDeterministicAndNotPlaintext() {
        String hash1 = TokenHasher.sha256("sample-token");
        String hash2 = TokenHasher.sha256("sample-token");

        assertEquals(hash1, hash2);
        assertEquals(64, hash1.length());
        assertNotEquals("sample-token", hash1);
    }
}
