package com.fixnear.auth.service;

import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

import com.fixnear.auth.domain.EmailVerificationToken;
import com.fixnear.auth.dto.LoginRequest;
import com.fixnear.auth.dto.RegisterRequest;
import com.fixnear.auth.repository.EmailVerificationTokenRepository;
import com.fixnear.auth.repository.RefreshTokenRepository;
import com.fixnear.common.exception.ApiException;
import com.fixnear.config.AuthProperties;
import com.fixnear.user.domain.AccountStatus;
import com.fixnear.user.domain.User;
import com.fixnear.user.repository.UserRepository;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class AuthServiceTest {

    @Mock
    private UserRepository userRepository;
    @Mock
    private EmailVerificationTokenRepository emailVerificationTokenRepository;
    @Mock
    private RefreshTokenRepository refreshTokenRepository;
    @Mock
    private JwtService jwtService;
    @Mock
    private AuthMailService authMailService;
    @Mock
    private LoginRateLimiter loginRateLimiter;

    private final PasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
    private AuthService authService;
    private AuthProperties authProperties;

    @BeforeEach
    void setUp() {
        authProperties = new AuthProperties();
        authService = new AuthService(
                userRepository,
                emailVerificationTokenRepository,
                refreshTokenRepository,
                passwordEncoder,
                jwtService,
                authMailService,
                authProperties,
                loginRateLimiter);
    }

    @Test
    void registerCreatesPendingUserAndSendsEmail() {
        when(userRepository.existsByEmailIgnoreCase("alex@example.com")).thenReturn(false);
        when(userRepository.save(any(User.class))).thenAnswer(invocation -> invocation.getArgument(0));
        when(emailVerificationTokenRepository.save(any(EmailVerificationToken.class)))
                .thenAnswer(invocation -> invocation.getArgument(0));

        authProperties.setExposeVerificationToken(true);
        var response = authService.register(new RegisterRequest("Alex@Example.com", "password123", "Alex User"));

        ArgumentCaptor<User> userCaptor = ArgumentCaptor.forClass(User.class);
        verify(userRepository).save(userCaptor.capture());
        User saved = userCaptor.getValue();
        assertEquals("alex@example.com", saved.getEmail());
        assertEquals(AccountStatus.PENDING_VERIFICATION, saved.getAccountStatus());
        assertTrue(passwordEncoder.matches("password123", saved.getPasswordHash()));
        assertTrue(response.verificationToken() != null && !response.verificationToken().isBlank());
        verify(authMailService).sendVerificationEmail(anyString(), anyString());
    }

    @Test
    void loginRejectsUnverifiedAccount() {
        User user = new User();
        user.setEmail("alex@example.com");
        user.setPasswordHash(passwordEncoder.encode("password123"));
        user.setAccountStatus(AccountStatus.PENDING_VERIFICATION);
        when(userRepository.findByEmailIgnoreCase("alex@example.com")).thenReturn(Optional.of(user));

        ApiException ex = assertThrows(ApiException.class,
                () -> authService.login(new LoginRequest("alex@example.com", "password123"), "127.0.0.1"));

        assertEquals("EMAIL_NOT_VERIFIED", ex.getCode());
        verify(refreshTokenRepository, never()).save(any());
    }
}
