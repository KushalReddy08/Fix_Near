# FixNear

Open-source multi-workspace accountability platform for colleges, workplaces, residential communities, and civic groups.

Stack: **React + TypeScript + Vite + Tailwind** · **Java 21 / Spring Boot 3** · **PostgreSQL + Flyway**.

## Features

- Email verification auth (JWT + refresh cookies)
- Organization requests with platform-admin approval
- Country → state → city address cascade
- Complaints with full workflow, SLA/overdue, attachments, comments, support votes
- Commitments, notifications, civic map listing

## Quick start (local)

```bash
cp .env.example .env
# edit .env — set a strong FIXNEAR_JWT_SECRET

bash scripts/start-local-postgres.sh
bash scripts/start-mailpit.sh   # optional; verification mail UI on :8025

export JAVA_HOME=${JAVA_HOME:-$HOME/tools/jdk-21.0.13.1+2}
export PATH=$JAVA_HOME/bin:${MAVEN_HOME:-$HOME/tools/apache-maven-3.10.1}/bin:$PATH
cd backend && mvn spring-boot:run

# other terminal
cd frontend && npm install && npm run dev
```

- App: http://localhost:5173  
- API health: http://localhost:8080/api/v1/health  
- Mailpit: http://127.0.0.1:8025  

## Configuration

See `.env.example`. Never commit a real `.env`.

## Docs

- `docs/architecture.md`
- `docs/api-documentation.md`
- `docs/development-guide.md`
- `docs/decisions.md`
- `docs/security.md`

## Contributing

PRs and issues welcome. Please keep secrets out of commits and follow `docs/security.md`.

## License

MIT — see `LICENSE` if present; otherwise contributions are welcome under MIT terms.
